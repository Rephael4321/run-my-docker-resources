import { Routes } from '@angular/router';


export const routes: Routes = [
  {
    path: 'login',
    loadComponent: () => import('./pages/login/login.component')
    .then(c => c.LoginComponent)
  },
  {
    path: 'sign-up',
    loadComponent: () => import('./pages/sign-up/sign-up.component')
    .then(c => c.SignUpComponent)
  },
  {
    path: 'dologin-github',
    loadComponent: () => import('./pages/complete-social-registration/complete-social-registration.component')
    .then(c => c.CompleteSocialRegistrationComponent)
  },
  {
    path: 'dologin-google',
    loadComponent: () => import('./pages/complete-social-registration/complete-social-registration.component')
    .then(c => c.CompleteSocialRegistrationComponent)
  },
  {
    path: 'forgot-password',
    loadComponent: () => import('./pages/forgot-password/forgot-password.component')
    .then(c => c.ForgotPasswordComponent)
  },
  {
    path: '',
    children: [
      { path: '',
        loadComponent: () => import('./pages/home/home.component')
        .then(c => c.HomeComponent)
      },
      {
        path: 'my-profile',
        loadComponent: () => import('./pages/profile/profile.component')
        .then(c => c.ProfileComponent)
      },
      {
        path: 'my-containers',
        children: [
          {
            path: '',
            loadComponent: () => import('./pages/my-containers/my-containers.component')
            .then(c => c.MyContainersComponent),
          },
          {
            path: 'new',
            loadComponent: () => import('./pages/add-container/add-container.component')
            .then(c => c.AddContainerComponent)
          },
          {
            path: ':appName',
            loadComponent: () => import('./pages/container-details/container-details.component')
            .then(c => c.ContainerDetailsComponent)
          },
        ]
      },
    ]
  },
  { path: '**', redirectTo:"login" },
];
