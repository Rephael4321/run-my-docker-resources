export type UserCredentials = {
  username: string,
  password: string
}
