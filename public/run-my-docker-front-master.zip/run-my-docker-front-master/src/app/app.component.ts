import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterOutlet } from '@angular/router';
import { AuthService } from './services/auth.service';
import { FooterComponent } from './components/footer/footer.component';
import { environment } from '../environments/environment';
import { NavbarComponent } from './components/navbar/navbar.component';
import { storageService } from './utils/localStorageHelper';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, NavbarComponent, RouterOutlet, FooterComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})
export class AppComponent implements OnInit{

  constructor(private authService: AuthService,
    private router:Router){}

  ngOnInit(): void {
    this.initLoginAndGetUser()
  }

  async initLoginAndGetUser(){
    try{

      console.log("getting user...");
      await this.authService.getUser();
      console.log("user is logged!");

      if(environment.production){ this.router.navigate(['/my-containers']) }
    }
    catch(err){
      console.log("ERROR:", err);
    }

  }


}
