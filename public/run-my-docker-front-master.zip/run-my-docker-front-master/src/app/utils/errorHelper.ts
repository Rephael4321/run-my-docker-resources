

export const errorHelper = (err:any) :string => {
  console.log("Error is: ", err);
  const { status, error } = err;
  if(status > 399 && status < 500){
    if(typeof(error) === 'string')  return error;
    else if(error.message)  return error.message;
    else return error.error;
  }
  else return "Oops... something went wrong, try again";
}
