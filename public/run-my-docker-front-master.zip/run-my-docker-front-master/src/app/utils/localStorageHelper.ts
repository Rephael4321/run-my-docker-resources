// import { decryptData, encryptData } from "./encriptionHelper";


type STORAGE_KEYS = "token" | "uuid" | 'exp' | "user" | "username" | "code" | "uuidToken";

const encodeData = (data:any) => btoa(data);
const decodeData = (data:any) => atob(data);

const expirationInHours = 4;
const expirationInMiliseconds = expirationInHours * 1000 * 60 * 60;

export const storageService = {

  get: (key:STORAGE_KEYS) => {
    const storageData = localStorage.getItem(key);
    if(!!storageData){
      const parsedData = JSON.parse(storageData)
      return decodeData(parsedData);
    }
    return '';
  },

  isTokenExpired: () => {
    const expToken = storageService.get('exp');
    if(!expToken) return true;
    const currentTime = new Date().getTime();
    return currentTime > +expToken;
  },

  set: (key:STORAGE_KEYS, data:any) => {
    if(key === 'token'){
      const tokenExpiration = new Date().getTime() + expirationInMiliseconds;
      storageService.set('exp', tokenExpiration)
    }
    const encodedData = encodeData(data);
    localStorage.setItem(key, JSON.stringify(encodedData));
  },

  delete: (key:STORAGE_KEYS) => {
    localStorage.removeItem(key);
  },

  deleteAll: () => {
    localStorage.clear();
  },

}
