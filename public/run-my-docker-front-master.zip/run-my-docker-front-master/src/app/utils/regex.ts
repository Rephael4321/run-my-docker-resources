

export const REGEX = {
  email: /^[\w-\.]+@([\w-]+\.)+[\w-]{2,}$/,
  phone: /^05\d{8}$/,
  israeliPhone: /^\+972-5\d{8}$/,
  verificationCode: /^\d{6}$/,
  onlyLettersAndNumbers: /^[a-zA-Z0-9][a-zA-Z0-9-]+$/
}
