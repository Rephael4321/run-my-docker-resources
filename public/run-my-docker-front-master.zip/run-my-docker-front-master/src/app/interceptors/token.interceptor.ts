import { HttpEvent, HttpRequest, HttpHandlerFn, HttpInterceptorFn } from '@angular/common/http';
import { Observable } from 'rxjs';
import { storageService } from '../utils/localStorageHelper';


export const tokenInterceptor: HttpInterceptorFn = (
  req: HttpRequest<any>,
  next: HttpHandlerFn
): Observable<HttpEvent<any>> => {

  const token = storageService.get('token');
  const isTokenExpired = storageService.isTokenExpired();

  if(token && !isTokenExpired){
    const authHeader = { authorization: `Bearer ${token}` };
    const cloned = req.clone({ setHeaders: authHeader });
    return next(cloned);
  }

  return next(req);

};
