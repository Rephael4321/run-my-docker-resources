import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom, map } from 'rxjs';
import { AppStausChangeRequest, IAppContainerRequest, IAppContainerResponse } from '../interfaces/AppContainer';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  serverURL = environment.serverURL;

  ENDPOINTS = {
    deleteApp: "/api/userApplication/deleteApp",
    getAllUserApps: "/api/userApplication/getUserApplications",
    // getApp: "/api/userApplication/getApp",
    getContainerLogs: "/api/userApplication/{appId}/getAppLogs",
    createNewContainer: "/api/userApplication/newApp",
    startApp: "/api/userApplication/startApp",
    stopApp: "/api/userApplication/stopApp",
    updateAppContainer: '/api/userApplication/{appId}/changeImage'
  }

  constructor(private httpClient:HttpClient) { }

  getAllUserApps = async () => {
    const URL = this.serverURL + this.ENDPOINTS.getAllUserApps;
    const apps = await firstValueFrom(
      this.httpClient.get<{ applications: IAppContainerResponse[]}>(URL)
      .pipe(map(res => res.applications))
      .pipe(map(app => app.sort((a, b) => a.id < b.id? 1: -1) ))
      )
    return apps;
  }

  getApp = async (appName:string) => {
    const apps = await this.getAllUserApps();
    const app  = apps.filter(a => a.appName === appName)
    return app.length > 0? app[0] : null;
  }

  getContainerLogs = async (appId:number) => {
    const URL = this.serverURL + this.ENDPOINTS.getContainerLogs.replace('{appId}', appId.toString());
    const logs = await firstValueFrom( this.httpClient.get(URL,{responseType: 'text'}) )
    return logs;
  }

  createNewAppContainer = async (newApp: IAppContainerRequest) => {
    const URL = this.serverURL + this.ENDPOINTS.createNewContainer;
    const res = await firstValueFrom( this.httpClient.post(URL, newApp) )
  }

  updateAppContainer = async (updatedApp: {appId: number, dockerImage: string, mappingPort: string }) => {
    const URL = this.serverURL + this.ENDPOINTS.updateAppContainer.replace('{appId}', updatedApp.appId.toString());
    const res = await firstValueFrom( this.httpClient.put<IAppContainerResponse>(URL, updatedApp) )
    return res;
  }

  startApp = async (app: AppStausChangeRequest) => {
    const URL = this.serverURL + this.ENDPOINTS.startApp;
    const res = await firstValueFrom( this.httpClient.post(URL, app) )
  }

  stopApp = async (app: AppStausChangeRequest) => {
    const URL = this.serverURL + this.ENDPOINTS.stopApp;
    const res = await firstValueFrom( this.httpClient.post(URL, app) )
  }

  deleteApp = async (appToDelete: { appName: string, appId: number }) => {
    const URL = this.serverURL + this.ENDPOINTS.deleteApp;
    await firstValueFrom( this.httpClient.delete(URL, { body: appToDelete }) )
  }


}
