import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { UserCredentials } from '../interfaces/UserCredentials';
import { BehaviorSubject, firstValueFrom, tap } from 'rxjs';
import { IForgotPasswordResponse, ISocialRegistration, IRegistrationResponse, IUserProfileRequest, IUserProfileResponse } from '../interfaces/UserProfile';
import { storageService } from '../utils/localStorageHelper';


@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private serverURL = environment.serverURL;

  private ENDPOINTS = {
    activateUser: "/api/auth/activate",
    login: "/api/auth/login",
    register: "/api/auth/register",
    completeGithubRegistration: "/api/auth/completeRegistration/",
    resendCode: "/api/auth/resendCode",
    forgotPassword: "/api/auth/forgotPassword",
    getUser: "/api/users/getUser",
    deleteUser: "/api/users/deleteUser/",
    resetPassword: "/api/users/resetPassword",

  }

  private unactivatedUser:IUserProfileResponse | null = null;

  private user = new BehaviorSubject<IUserProfileResponse | null>(null);

  get $user(){
    return this.user.asObservable();
  }

  constructor(private httpClient:HttpClient) { }

  logout = async () => {
    storageService.deleteAll();
    this.user.next(null);
  }

  login = async (userCredentials: UserCredentials) => {
    const URL = this.serverURL + this.ENDPOINTS.login;
    const res = await firstValueFrom( this.httpClient.post<{jwtToken:string}>(URL, userCredentials) );
    storageService.set("token", res.jwtToken);
    storageService.set("username", userCredentials.username);
    await this.getUser();
  }

  forgotPassword = async (username: string) => {
    const param = `?username=${username}`;
    const URL = this.serverURL + this.ENDPOINTS.forgotPassword + param;
    const res = await firstValueFrom( this.httpClient.get<IForgotPasswordResponse>(URL) );
    storageService.set("code", res.code);
    storageService.set("uuidToken", res.uuidToken);
    storageService.set("username", username);
  }

  setNewPassword = async (newPassword: string, code: string) => {
    const username = storageService.get('username');
    const uuidToken = storageService.get('uuidToken');
    const reqBody = { newPassword, code, username, uuidToken }
    const URL = this.serverURL + this.ENDPOINTS.forgotPassword;
    const res = await firstValueFrom( this.httpClient.put<IRegistrationResponse>(URL, reqBody) );
  }

  register = async (userRequest: IUserProfileRequest) => {
    const URL = this.serverURL + this.ENDPOINTS.register;
    const res = await firstValueFrom( this.httpClient.post<IRegistrationResponse>(URL, userRequest ) );

    storageService.set('uuid', res.uuid);
    storageService.set('username', res.user.username);
    this.unactivatedUser = res.user;
  }

  completeSocialRegistration = async (userRequest: ISocialRegistration) => {
    const URL = `${this.serverURL}${this.ENDPOINTS.completeGithubRegistration}${userRequest.id}`;
    const res = await firstValueFrom( this.httpClient.put<IRegistrationResponse>(URL, userRequest ) );

    storageService.set('uuid', res.uuid);
    storageService.set('username', res.user.username);
    this.unactivatedUser = res.user;
  }

  getUser = async () => {
    const URL = this.serverURL + this.ENDPOINTS.getUser;
    const user = await firstValueFrom( this.httpClient.get<IUserProfileResponse>(URL) )
    this.user.next(user);
  }

  deleteUser = async () => {
    const userId = this.user.value? this.user.value.id : 0;
    const URL = this.serverURL + this.ENDPOINTS.deleteUser + userId;
    await firstValueFrom( this.httpClient.delete(URL) )
  }

  activateUser = async (code:string) => {
    const uuid = storageService.get("uuid");
    const username = storageService.get("username");
    const param = `?username=${username}`;
    const URL = this.serverURL + this.ENDPOINTS.activateUser + param;
    const res = await firstValueFrom( this.httpClient.put<{jwtToken:string}>(URL, { code, uuid }) )
    storageService.deleteAll();
    storageService.set('token', res.jwtToken);
    this.user.next(this.unactivatedUser);
    this.unactivatedUser = null;
  }

  resendCode = async () => {
    const username = storageService.get('username');
    const sendMethod: 'EMAIL' | 'SMS' | 'BOTH' = 'SMS'
    const param = `?username=${username}&sendMethod=${sendMethod}`;
    const URL = this.serverURL + this.ENDPOINTS.resendCode;
    await firstValueFrom( this.httpClient.get(URL + param) )
  }

  resetPassword = async (password:string) => {
    const URL = this.serverURL + this.ENDPOINTS.resetPassword;
    await firstValueFrom( this.httpClient.put(URL, { password } ) )
  }


}
