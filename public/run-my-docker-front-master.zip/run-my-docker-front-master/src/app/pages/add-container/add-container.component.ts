import { Component, OnDestroy, OnInit } from '@angular/core';
import { IAppContainerRequest } from '../../interfaces/AppContainer';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { CommonModule, Location } from '@angular/common';
import { ApiService } from '../../services/api.service';
import { Subscription } from 'rxjs';
import { AuthService } from '../../services/auth.service';
import { ButtonComponent } from '../../components/button/button.component';
import { BackBtnComponent } from '../../components/back-btn/back-btn.component';
import { MatIconModule } from '@angular/material/icon';
import {MatInputModule} from '@angular/material/input';
import {MatFormFieldModule} from '@angular/material/form-field';
import { ErrorAlertComponent } from '../../components/error-alert/error-alert.component';
import { SuccessAlertComponent } from '../../components/success-alert/success-alert.component';
import {MatTooltipModule } from '@angular/material/tooltip';
import { errorHelper } from '../../utils/errorHelper';
import { REGEX } from '../../utils/regex';
import { IUserProfileResponse } from '../../interfaces/UserProfile';


@Component({
  selector: 'app-add-container',
  standalone: true,
  imports: [
    ReactiveFormsModule,
    ErrorAlertComponent,
    MatIconModule,
    MatInputModule,
    MatFormFieldModule,
    ButtonComponent,
    BackBtnComponent,
    SuccessAlertComponent,
    MatTooltipModule,
    CommonModule],
  templateUrl: './add-container.component.html',
  styleUrl: './add-container.component.scss'
})
export class AddContainerComponent implements OnInit, OnDestroy{

  containerSub!:Subscription;
  appForm!:FormGroup;
  username = "";
  userSub!:Subscription;
  errorMessage = "";
  successMessage = "";
  isSubmitting = false;

  constructor(private apiService:ApiService,
    private authService:AuthService,
    public fb:FormBuilder,
    private location:Location){}

  ngOnInit(): void {
    // get UserDetails for username
    this.userSub = this.authService.$user
      .subscribe((user: IUserProfileResponse | null) => {
        if(user) this.username = user.username
      })
    this.setInitForm();
  }

  setInitForm(){
    let nnfb = this.fb.nonNullable;
    this.appForm = nnfb.group({
      appName: ["", [
        Validators.required,
        Validators.pattern(REGEX.onlyLettersAndNumbers)
      ]],
      dockerImage: ["", [
        Validators.required,
      ]],
      portMap: ["", [
        Validators.required,
      ]],
    })
  }

  goBack(){ this.location.back(); }

  closeError(){ this.errorMessage = '' }

  async handleSubmit(){
    if(this.appForm.invalid) return;
    this.errorMessage = '';
    this.successMessage = '';
    this.isSubmitting = true;

    try{
      const newApp:IAppContainerRequest = {
        ...this.appForm.value,
        username: this.username
      }
      await this.apiService.createNewAppContainer(newApp);
      this.goBack()
      // this.successMessage = `Your container ${newApp.appName} was created successfully!`;
    }
    catch(err:any){
      const {status, error } = err;
      this.errorMessage = errorHelper(err);
    }
    finally{ this.isSubmitting = false }
  }

  ngOnDestroy(): void {
    this.userSub.unsubscribe();
  }


}
