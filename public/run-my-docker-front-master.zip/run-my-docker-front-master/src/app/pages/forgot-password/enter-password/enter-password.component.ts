import { Component, EventEmitter, Output } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { AuthService } from '../../../services/auth.service';
import { REGEX } from '../../../utils/regex';
import { errorHelper } from '../../../utils/errorHelper';
import { ButtonComponent } from '../../../components/button/button.component';
import { NgFor, NgIf } from '@angular/common';
import { storageService } from '../../../utils/localStorageHelper';
import { ErrorAlertComponent } from '../../../components/error-alert/error-alert.component';

@Component({
  selector: 'app-enter-password',
  standalone: true,
  imports: [ButtonComponent, ReactiveFormsModule, NgFor, NgIf, ErrorAlertComponent],
  templateUrl: './enter-password.component.html',
  styleUrl: './enter-password.component.scss'
})
export class EnterPasswordComponent {
  title = "Reset Password"
  subtitle = "We have sent the code verification to your phone / email"
  didntReceiveText = "Didn't receive it?"
  btnText = "continue";
  isResendingCode = false;
  @Output() onCompletion = new EventEmitter();
  hide = true;
  resetPasswordForm!:FormGroup;
  errorMessage = "";
  isLoading = false;

  constructor(public fb:FormBuilder,
    private authService:AuthService ){};

  ngOnInit(): void {
    this.setNewForm();
  }

  closeError(){ this.errorMessage = "" }

  setNewForm(){
    let nnfb = this.fb.nonNullable;
    this.resetPasswordForm = nnfb.group({
      code: ["", [
        Validators.required,
        Validators.pattern(REGEX.verificationCode)
      ]],
      password: ["", [
        Validators.required,
        Validators.minLength(5),
      ]],
      confirmPassword: ["", [
        Validators.required,
        Validators.minLength(5),
      ]],
    })
  }

  async onSubmit(){

    if(this.resetPasswordForm.invalid) return;

    const { password, confirmPassword, code } = this.resetPasswordForm.value;

    if(password !== confirmPassword){
      this.errorMessage = "Passwords does not match."
      return;
    }
    this.isLoading = true;
    this.errorMessage = "";

    try{

      await this.authService.setNewPassword(password, code);
      const username = storageService.get('username');
      await this.authService.login({username, password})
      this.onCompletion.emit();

    }
    catch(err:any){
      this.errorMessage = errorHelper(err);
    }
    finally{ this.isLoading = false }
  }

  async handleResendCode(){
    const username = storageService.get('username');
    try{
      this.isResendingCode = true;

      await this.authService.forgotPassword(username);
    }
    catch(err){
      this.errorMessage = errorHelper(err);
    }
    finally{ this.isResendingCode = false }
  }
}
