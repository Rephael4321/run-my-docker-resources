import { Component, ViewChild } from '@angular/core';
import { MatStepper, MatStepperModule } from '@angular/material/stepper';
import { EnterPasswordComponent } from './enter-password/enter-password.component';
import { EnterUsernameComponent } from './enter-username/enter-username.component';
import { SuccessStepComponent } from '../sign-up/success-step/success-step.component';

@Component({
  selector: 'app-forgot-password',
  standalone: true,
  imports: [
    MatStepperModule,
    EnterPasswordComponent,
    EnterUsernameComponent,
    SuccessStepComponent
  ],
  templateUrl: './forgot-password.component.html',
  styleUrl: './forgot-password.component.scss'
})
export class ForgotPasswordComponent {
  @ViewChild('stepper') stepper!: MatStepper;
  successStepSubtitle = "Your passsword reset successfully.";

  setNextStep = () => {
    if(this.stepper){
      this.stepper.selected!.completed = true;
      this.stepper.next();
    }
  }

}
