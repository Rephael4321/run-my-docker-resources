import { Component, EventEmitter, Output } from '@angular/core';
import { errorHelper } from '../../../utils/errorHelper';
import { AuthService } from '../../../services/auth.service';
import { FormControl, ReactiveFormsModule, Validators } from '@angular/forms';
import { REGEX } from '../../../utils/regex';
import { NgFor, NgIf } from '@angular/common';
import { ButtonComponent } from '../../../components/button/button.component';
import { ErrorAlertComponent } from '../../../components/error-alert/error-alert.component';

@Component({
  selector: 'app-enter-username',
  standalone: true,
  imports: [ButtonComponent, ReactiveFormsModule, NgFor, NgIf, ErrorAlertComponent],
  templateUrl: './enter-username.component.html',
  styleUrl: './enter-username.component.scss'
})
export class EnterUsernameComponent {
  title = "Forgot Password"
  subtitle = "Please enter your email address"
  didntReceiveText = "Didn't receive it?"
  btnText = "continue";
  errorMessage = "";
  emailInput!: FormControl;
  isResendingCode = false;
  isLoading = false;
  @Output() onCompletion = new EventEmitter();

  constructor(private authService:AuthService){}

  ngOnInit(): void {
    this.emailInput = new FormControl("", [
      Validators.pattern(REGEX.email),
      Validators.required
    ])
  }

  async handleSendCode(){
    if(this.emailInput.invalid) return;

    try{
      this.isLoading = true;
      this.errorMessage = "";
      const username = this.emailInput.value;
      await this.authService.forgotPassword(username);
      this.onCompletion.emit();
    }
    catch(err){
      this.errorMessage = errorHelper(err);
    }
    finally{ this.isLoading = false }
  }

  closeError(){ this.errorMessage = ''; }
}
