import { Component } from '@angular/core';
import { ButtonComponent } from '../../components/button/button.component';
import {MatIconModule} from '@angular/material/icon'
import { AuthService } from '../../services/auth.service';
import { Router, RouterLink } from '@angular/router';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [ ButtonComponent, MatIconModule, RouterLink],
  templateUrl: './home.component.html',
  styleUrl: './home.component.scss'
})
export class HomeComponent {

  constructor(private authService:AuthService,
    private router:Router){}

  logout(){
    this.authService.logout();
    this.router.navigate(['login'])
  }



}
