import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { ButtonComponent } from '../../../components/button/button.component';
import { NgIf } from '@angular/common';
import { ErrorAlertComponent } from '../../../components/error-alert/error-alert.component';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { AuthService } from '../../../services/auth.service';
import { ActivatedRoute, Router } from '@angular/router';
import { REGEX } from '../../../utils/regex';
import { ISocialRegistration } from '../../../interfaces/UserProfile';
import { errorHelper } from '../../../utils/errorHelper';

@Component({
  selector: 'app-social-auth-form',
  standalone: true,
  imports: [
    ButtonComponent,
    NgIf,
    ErrorAlertComponent,
    ReactiveFormsModule,
    MatButtonModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
  ],
  templateUrl: './social-auth-form.component.html',
  styleUrl: './social-auth-form.component.scss'
})
export class SocialAuthFormComponent implements OnInit{

  hide = true;
  @Input() userId!:string;
  registrationForm!:FormGroup;
  errorMessage = "";
  isLoading = false;
  submitBtnText = 'Continue'
  @Output() onCompletion = new EventEmitter()

  constructor(public fb:FormBuilder,
    private authService:AuthService){};

  ngOnInit(): void {
    this.setNewForm();
  }

  closeError(){ this.errorMessage = "" }

  setNewForm(){
    let nnfb = this.fb.nonNullable;
    this.registrationForm = nnfb.group({
      firstName: ["", [
        Validators.required
      ]],
      lastName: ["", [
        Validators.required
      ]],
      phone: ["", [
        Validators.required,
        Validators.pattern(REGEX.phone)
      ]],

    })
  }

  async onSubmit(){
    if(this.registrationForm.invalid) return;

    this.isLoading = true;
    this.errorMessage = "";
    const phone = '+972-' + this.registrationForm.value.phone.slice(1);

    const user: ISocialRegistration = {
      ...this.registrationForm.value,
      phone,
      id: this.userId
    };

    try{

      await this.authService.completeSocialRegistration(user)
      this.onCompletion.emit()

    }
    catch(err:any){
      this.errorMessage = errorHelper(err);
    }
    finally{ this.isLoading = false }
  }

}
