import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Params, Router, RouterLink } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { storageService } from '../../utils/localStorageHelper';
import { SocialAuthFormComponent } from './social-auth-form/social-auth-form.component';
import { SpinnerComponent } from '../../components/spinner/spinner.component';
import { VerificationStepComponent } from '../sign-up/verification-step/verification-step.component';
import { SuccessStepComponent } from '../sign-up/success-step/success-step.component';
import { MatStepper, MatStepperModule } from '@angular/material/stepper';
import { UserCredentials } from '../../interfaces/UserCredentials';
import { RegStepHeaderComponent } from '../sign-up/registration-step/reg-step-header/reg-step-header.component';

@Component({
  selector: 'app-complete-github-registration',
  standalone: true,
  imports: [
    RouterLink,
    SpinnerComponent,
    MatStepperModule,
    SocialAuthFormComponent,
    VerificationStepComponent,
    SuccessStepComponent,
    RegStepHeaderComponent
  ],
  templateUrl: './complete-social-registration.component.html',
  styleUrl: './complete-social-registration.component.scss'
})
export class CompleteSocialRegistrationComponent implements OnInit{

  title = 'Complete Registration'
  subtitle = 'Fill in the last details and get started!'
  userId!:string;
  isLoading = true;
  successStepSubtitle = "You have been successfully registered for 'Run My Docker'.";
  @ViewChild('stepper') stepper!: MatStepper;

  constructor(private authService:AuthService,
    private router:Router,
    private activatedRoute: ActivatedRoute){};

  ngOnInit(): void {
    this.activatedRoute.queryParams
      .subscribe((p) => { this.handleInitialLoad(p) });
  }

  handleInitialLoad = async(p: Params) => {
    this.isLoading = true;
    const id = p['id'];
    const token = p['token'];
    try{
      if(token){
        storageService.set('token', token)
        await this.authService.getUser()
        this.router.navigate(['/my-containers'])
      }
      else if(id){
        this.userId = id;
        this.isLoading = false;
      }
      else { this.router.navigate(['/']) }
    }
    catch(err){
      this.router.navigate(['/login'])
    }
  }

  setNextStep = () => {
    if(this.stepper){
      this.stepper.selected!.completed = true;
      this.stepper.next();
    }
  }


}
