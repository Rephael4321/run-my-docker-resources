import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CompleteSocialRegistrationComponent } from './complete-social-registration.component';

describe('CompleteSocialRegistrationComponent', () => {
  let component: CompleteSocialRegistrationComponent;
  let fixture: ComponentFixture<CompleteSocialRegistrationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CompleteSocialRegistrationComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CompleteSocialRegistrationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
