import { Component, OnDestroy, OnInit } from '@angular/core';
import {MatIconModule} from '@angular/material/icon'
import { ApiService } from '../../services/api.service';
import { IAppContainerResponse } from '../../interfaces/AppContainer';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { Subscription } from 'rxjs';
import { MatDialog } from '@angular/material/dialog';
import { DeleteDialogComponent } from './delete-dialog/delete-dialog.component';
import { SpinnerComponent } from '../../components/spinner/spinner.component';
import { MinutesToTimePipe } from '../../pipes/minutes-to-time.pipe';
import { MatTooltipModule} from '@angular/material/tooltip';
import { ContainersTableComponent } from './containers-table/containers-table.component';
import { ErrorAlertComponent } from '../../components/error-alert/error-alert.component';
import { errorHelper } from '../../utils/errorHelper';

@Component({
  selector: 'app-my-containers',
  standalone: true,
  imports: [
    SpinnerComponent,
    MatIconModule,
    CommonModule,
    RouterLink,
    MinutesToTimePipe,
    MatTooltipModule,
    ContainersTableComponent,
    ErrorAlertComponent,
  ],
  templateUrl: './my-containers.component.html',
  styleUrl: './my-containers.component.scss'
})
export class MyContainersComponent implements OnInit, OnDestroy{

  userContainers:IAppContainerResponse[] = [];
  title = "My Containers";
  subtitles = [
    '*The server takes about 30s to be available after activation.',
    '**There is a 6 containers limit per user.',
  ]
  addContainerBtnText = "Add Container";
  errorMessgae = "";
  userSub!:Subscription;
  isReloading = false;
  isStatusChangeLoading = false;


  constructor(private apiService: ApiService,
    private authService:AuthService,
    public dialog: MatDialog){}

  ngOnInit(): void {
    this.userSub = this.authService.$user.subscribe(async user => {
      this.isReloading = true;
      await this.getUserContainers()
      this.isReloading = false;
    })
  }

  async getUserContainers(){
    try{
      await this.apiService.getAllUserApps()
        .then(apps => this.userContainers = apps)
    }
    catch(err){}
  }

  openDialog(appToDelete:IAppContainerResponse): void {
    this.dialog.open(DeleteDialogComponent, {
      data: {
        app: appToDelete,
        deleteFnCallback: this.handleDeleteBtn
      },
    });
  }

  handleDeleteBtn = async(app: IAppContainerResponse) => {
    try{
      this.errorMessgae = '';
      const appToDelete = {
        appName: app.appName,
        appId: app.id
      }
      await this.apiService.deleteApp(appToDelete);
      await this.getUserContainers();
    }
    catch(err){
      this.errorMessgae = errorHelper(err);
    }
  }

  async changeAppStatus(app:IAppContainerResponse){
    this.isStatusChangeLoading = true;
    const appToUpadte = {
      appId: app.id,
      appName: app.appName
    }
    try{
      if(app.running){
        await this.apiService.stopApp(appToUpadte)
        .catch(() => {})
      }
      else{
        await this.apiService.startApp(appToUpadte)
        .catch(() => {})
      }

      await this.getUserContainers();
    }
    catch(err){ }
    finally{ this.isStatusChangeLoading = false; }
  }

  ngOnDestroy(): void {
    this.userSub.unsubscribe()
  }


}
