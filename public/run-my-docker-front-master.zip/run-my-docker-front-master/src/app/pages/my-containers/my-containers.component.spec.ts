import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MyContainersComponent } from './my-containers.component';

describe('MyContainersComponent', () => {
  let component: MyContainersComponent;
  let fixture: ComponentFixture<MyContainersComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MyContainersComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(MyContainersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
