import { Component, Inject, Input } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MAT_DIALOG_DATA,  MatDialog, MatDialogRef } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { IAppContainerResponse } from '../../../interfaces/AppContainer';
import { NgIf } from '@angular/common';

@Component({
  selector: 'app-delete-dialog',
  standalone: true,
  imports: [
    MatFormFieldModule,
    MatInputModule,
    FormsModule,
    MatButtonModule,
    NgIf,
  ],
  templateUrl: './delete-dialog.component.html',
  styleUrl: './delete-dialog.component.scss'
})
export class DeleteDialogComponent {

  isLoading = false;

  constructor(
    public dialogRef: MatDialogRef<DeleteDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: {
      app: IAppContainerResponse,
      deleteFnCallback: (app:IAppContainerResponse) => Promise<void>
    },
  ) {}

  onNoClick(): void { this.dialogRef.close(); }

  async onConfirmDeletion(){
    this.isLoading = true;
    await this.data.deleteFnCallback(this.data.app);
    setTimeout(() => { this.onNoClick(); }, 1000);
  }

}

