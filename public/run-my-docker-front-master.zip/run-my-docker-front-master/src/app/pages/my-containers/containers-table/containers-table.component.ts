import { Component, EventEmitter, Input, Output } from '@angular/core';
import { IAppContainerResponse } from '../../../interfaces/AppContainer';
import { MinutesToTimePipe } from '../../../pipes/minutes-to-time.pipe';
import { MatIconModule } from '@angular/material/icon';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { SpinnerComponent } from '../../../components/spinner/spinner.component';
import { MatTooltipModule } from '@angular/material/tooltip';

@Component({
  selector: 'app-containers-table',
  standalone: true,
  imports: [
    MinutesToTimePipe,
    MatIconModule,
    CommonModule,
    RouterLink,
    SpinnerComponent,
    MatTooltipModule,
  ],
  templateUrl: './containers-table.component.html',
  styleUrl: './containers-table.component.scss'
})
export class ContainersTableComponent {

  changingAppName: string = '';

  @Input() userContainers!:IAppContainerResponse[];
  @Input() isStatusChangeLoading!:boolean;
  @Output() statusChangeClicked = new EventEmitter<IAppContainerResponse>();
  @Output() deleteBtnClicked = new EventEmitter<IAppContainerResponse>();

  constructor(){}

  onDeleteBtnClick = (app:IAppContainerResponse) => {
    this.deleteBtnClicked.emit(app)
  }

  onStatusChangeClick = (app:IAppContainerResponse) => {
    this.changingAppName = app.appName;
    this.statusChangeClicked.emit(app)
  }

  tableRowTrackBy(index: number, app:IAppContainerResponse){
    return app.id
  }

}
