import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RegStepHeaderComponent } from './reg-step-header.component';

describe('RegStepHeaderComponent', () => {
  let component: RegStepHeaderComponent;
  let fixture: ComponentFixture<RegStepHeaderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RegStepHeaderComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(RegStepHeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
