import { Component } from '@angular/core';
import { ButtonComponent } from '../../../../components/button/button.component';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-reg-step-header',
  standalone: true,
  imports: [ButtonComponent, RouterLink],
  templateUrl: './reg-step-header.component.html',
  styleUrl: './reg-step-header.component.scss'
})
export class RegStepHeaderComponent {

  goToBtnLink = '/login';
  title = 'Create Account';
  subtitle = [
    'Or',
    'login',
    'If you already have an account'
  ]
}
