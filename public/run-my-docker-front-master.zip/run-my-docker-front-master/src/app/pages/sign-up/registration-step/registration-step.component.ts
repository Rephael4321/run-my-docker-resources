import { Component, EventEmitter, Output } from '@angular/core';
import { ButtonComponent } from '../../../components/button/button.component';
import { NgIf } from '@angular/common';
import { ErrorAlertComponent } from '../../../components/error-alert/error-alert.component';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { AuthService } from '../../../services/auth.service';
import { REGEX } from '../../../utils/regex';
import { RegStepHeaderComponent } from './reg-step-header/reg-step-header.component';
import { storageService } from '../../../utils/localStorageHelper';
import { IUserProfileRequest } from '../../../interfaces/UserProfile';
import { UserCredentials } from '../../../interfaces/UserCredentials';
import { errorHelper } from '../../../utils/errorHelper';
import { GoogleBtnComponent } from '../../../components/google-btn/google-btn.component';

@Component({
  selector: 'app-registration-step',
  standalone: true,
  imports: [
    ButtonComponent,
    NgIf,
    ErrorAlertComponent,
    ReactiveFormsModule,
    RouterLink,
    MatButtonModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    RegStepHeaderComponent,
    GoogleBtnComponent
  ],
  templateUrl: './registration-step.component.html',
  styleUrl: './registration-step.component.scss'
})
export class RegistrationStepComponent {

  hide = true;
  registrationForm!:FormGroup;
  errorMessage = "";
  isLoading = false;
  @Output() onCompletion = new EventEmitter<UserCredentials>();

  constructor(public fb:FormBuilder,
    private authService:AuthService,
    private router:Router){};

  ngOnInit(): void {
    this.setNewForm();
  }

  closeError(){ this.errorMessage = "" }

  setNewForm(){
    let nnfb = this.fb.nonNullable;
    this.registrationForm = nnfb.group({
      firstName: ["", [
        Validators.required
      ]],
      lastName: ["", [
        Validators.required
      ]],
      phone: ["", [
        Validators.required,
        Validators.pattern(REGEX.phone)
      ]],
      username: ["", [
        Validators.required,
        Validators.pattern(REGEX.email)
      ]],
      password: ["", [
        Validators.required,
        Validators.minLength(5),
      ]],
      confirmPassword: ["", [
        Validators.required,
        Validators.minLength(5),
      ]],
    })
  }

  async onSubmit(){
    if(this.registrationForm.invalid) return;
    const { password, confirmPassword } = this.registrationForm.value;
    if(password !== confirmPassword){
      this.errorMessage = "Passwords does not match."
      return;
    }

    this.isLoading = true;
    this.errorMessage = "";
    const phone = '+972-' + this.registrationForm.value.phone.slice(1);
    console.log(phone);

    const user:IUserProfileRequest = {
      ...this.registrationForm.value,
      phone
    };

    try{

      await this.authService.register(user)
      storageService.set('username', user.username);

      this.onCompletion.emit(user);

    }
    catch(err:any){
      this.errorMessage = errorHelper(err);
    }
    finally{ this.isLoading = false }
  }

}
