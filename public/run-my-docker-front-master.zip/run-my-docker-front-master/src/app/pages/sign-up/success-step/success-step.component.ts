import { Component, Input } from '@angular/core';
import { ButtonComponent } from '../../../components/button/button.component';
import { RouterLink } from '@angular/router';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-success-step',
  standalone: true,
  imports: [ButtonComponent, RouterLink, MatIconModule],
  templateUrl: './success-step.component.html',
  styleUrl: './success-step.component.scss'
})
export class SuccessStepComponent{

  title = "Congratulations!";
  @Input() subtitle!:string;
  btnText = 'Start';

}
