import { Component, ViewChild } from '@angular/core';
import {MatStepper, MatStepperModule} from '@angular/material/stepper';
import { VerificationStepComponent } from './verification-step/verification-step.component';
import { RegistrationStepComponent } from './registration-step/registration-step.component';
import { SuccessStepComponent } from './success-step/success-step.component';
import { UserCredentials } from '../../interfaces/UserCredentials';

@Component({
  selector: 'app-sign-up',
  standalone: true,
  imports: [
    MatStepperModule,
    VerificationStepComponent,
    RegistrationStepComponent,
    SuccessStepComponent
  ],
  templateUrl: './sign-up.component.html',
  styleUrl: './sign-up.component.scss'
})
export class SignUpComponent {

  @ViewChild('stepper') stepper!: MatStepper;
  successStepSubtitle = "You have been successfully registered for 'Run My Docker'.";

  setNextStep = () => {
    if(this.stepper){
      this.stepper.selected!.completed = true;
      this.stepper.next();
    }
  }

  handleRegistrationComplete = (credentials:UserCredentials) => {
    this.setNextStep();
  }

}
