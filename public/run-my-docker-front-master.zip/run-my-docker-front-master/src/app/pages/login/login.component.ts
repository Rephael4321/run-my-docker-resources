import { Component } from '@angular/core';
import { ButtonComponent } from '../../components/button/button.component';
import { LoginFormComponent } from './login-form/login-form.component';
import { GoogleBtnComponent } from '../../components/google-btn/google-btn.component';
import { LoginHeaderComponent } from './login-header/login-header.component';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [LoginHeaderComponent, LoginFormComponent, GoogleBtnComponent, ButtonComponent],
  templateUrl: './login.component.html',
  styleUrl: './login.component.scss'
})
export class LoginComponent {

  hide = true;
  signUpLink = "/sign-up";
  title = "Log In";
  subtitle = [
    "Or",
    "Sign Up",
    "If you dont have an account"
  ];
}
