import { Component, OnInit } from '@angular/core';

import {MatFormFieldModule} from '@angular/material/form-field';
import {MatInputModule} from '@angular/material/input';
import {MatIconModule} from '@angular/material/icon';
import {MatButtonModule} from '@angular/material/button';
import { ButtonComponent } from '../../../components/button/button.component';
import { Router, RouterLink } from '@angular/router';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { AuthService } from '../../../services/auth.service';
import { REGEX } from '../../../utils/regex';
import { ErrorAlertComponent } from '../../../components/error-alert/error-alert.component';
import { NgIf } from '@angular/common';
import { errorHelper } from '../../../utils/errorHelper';

@Component({
  selector: 'app-login-form',
  standalone: true,
  imports: [ButtonComponent, NgIf, ErrorAlertComponent, ReactiveFormsModule, RouterLink, MatButtonModule, MatFormFieldModule, MatIconModule, MatInputModule],
  templateUrl: './login-form.component.html',
  styleUrl: './login-form.component.scss'
})
export class LoginFormComponent implements OnInit{

  hide = true;
  forgotPasswordLink = "/forgot-password";
  loginForm!:FormGroup;
  errorMessage = "";

  loading = false;

  constructor(public fb:FormBuilder,
    private authService:AuthService,
    private router:Router){};

  ngOnInit(): void {
    this.setNewForm();
  }

  closeError(){ this.errorMessage = "" }

  setNewForm(){
    let nnfb = this.fb.nonNullable;
    this.loginForm = nnfb.group({
      username: ["", [
        Validators.required,
        Validators.pattern(REGEX.email)
      ]],
      password: ["", [
        Validators.required,
        Validators.minLength(5),
      ]],
    })
  }

  async onSubmit(){
    if(this.loginForm.invalid) return;

    this.loading = true;
    this.errorMessage = "";
    try{
      await this.authService.login(this.loginForm.value)
      this.router.navigate(['my-containers'])
    }
    catch(err:any){
      console.log("Error is: ", err);
      const { status, error } = err;
      if(status === 401){ this.errorMessage = "Invalid email or password" }
      else this.errorMessage = "Oops... something went wrong, try again";
    }
    finally{ this.loading = false }
  }

}
