import { Component, Input } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { ButtonComponent } from '../../../components/button/button.component';

@Component({
  selector: 'app-login-header',
  standalone: true,
  imports: [ButtonComponent, RouterLink],
  templateUrl: './login-header.component.html',
  styleUrl: './login-header.component.scss'
})
export class LoginHeaderComponent {

  @Input() goToBtnLink!: string;
  @Input() title!:string;
  @Input() subtitle!:string[];

  constructor(private router:Router){}

}
