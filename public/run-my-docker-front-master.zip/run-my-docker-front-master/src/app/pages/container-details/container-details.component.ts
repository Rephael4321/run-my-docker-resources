import { Component, OnInit, WritableSignal, signal } from '@angular/core';
import { ApiService } from '../../services/api.service';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { CommonModule } from '@angular/common';
import { SpinnerComponent } from '../../components/spinner/spinner.component';
import { BackBtnComponent } from '../../components/back-btn/back-btn.component';
import { MatTooltipModule } from '@angular/material/tooltip';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { ButtonComponent } from '../../components/button/button.component';
import { ErrorAlertComponent } from '../../components/error-alert/error-alert.component';
import { errorHelper } from '../../utils/errorHelper';

type ContainerDetails = {
  appName:string,
  mappingPort: string,
  dockerImage: string,
  assigndUrl: string,
  logs: string,
  id:number
}

@Component({
  selector: 'app-container-details',
  standalone: true,
  imports: [ MatTooltipModule, ReactiveFormsModule, ErrorAlertComponent, ButtonComponent, BackBtnComponent, CommonModule, SpinnerComponent],
  templateUrl: './container-details.component.html',
  styleUrl: './container-details.component.scss'
})
export class ContainerDetailsComponent implements OnInit{

  app:WritableSignal<ContainerDetails | null> = signal(null);
  title = "Container Details";
  isRefreshing = false;
  errorMessage = '';
  updateAppForm!: FormGroup;
  isSubmitting = false;
  isActiveChanges = signal(false);

  constructor(private apiService:ApiService,
    private route: ActivatedRoute,
    private fb: FormBuilder){}

  ngOnInit(): void {
    this.route.paramMap.subscribe((param: ParamMap) => {

      const appName = param.get("appName");
      if(appName){
        console.log('app name is:', appName);

        this.getContainerDetails(appName)
      }

    })

  }

  refreshLogs = async() => {
    if(this.isRefreshing) return;


    this.isRefreshing = true;
    try{
      const logs = await this.apiService.getContainerLogs(this.app()!.id);
      const app = this.app();
      if(app){ this.app.set({...app, logs}) }
    }
    catch(err){

    }
    finally{
      setTimeout(() => {this.isRefreshing = false;}, 300)
     }
  }

  async getContainerDetails(appName:string){
    try{
      const app = await this.apiService.getApp(appName);
      if(!app) return;
      const logs = await this.apiService.getContainerLogs(app.id);

      this.app.set({
        id: app.id,
        appName,
        logs,
        mappingPort: app.mappingPort,
        dockerImage: app.dockerImage,
        assigndUrl: `https://${appName}.runmydocker-app.com`
      })

      this.setInitForm(app.mappingPort, app.dockerImage, app.id);
    }
    catch(err){
      console.log("Error: ", err);
    }
  }

  setInitForm(port:string, image:string, appId: number){
    let nnfb = this.fb.nonNullable;
    this.updateAppForm = nnfb.group({
      dockerImage: [image, [
        Validators.required,
      ]],
      mappingPort: [port, [
        Validators.required,
      ]],
      appId: [appId, [
        Validators.required,
      ]],
    })
  }

  onEditButtonClick = () => {
    const app = this.app();
    if(app){
      this.setInitForm(app.mappingPort, app.dockerImage, app.id)
      this.isActiveChanges.set(true)
    }
  }

  onCancel = () => {
    this.errorMessage = '';
    this.isActiveChanges.set(false)
  }

  handleSubmit = async() => {
    if(this.updateAppForm.invalid) return;

    try{
      this.errorMessage = '';
      this.isSubmitting = true;
      const updatedApp = await this.apiService.updateAppContainer(this.updateAppForm.value)

      this.app.update(value => {
        if(value) return {...value, ...updatedApp} 
        else return null
      })

      this.isActiveChanges.set(false);
      this.isSubmitting = false;
    }
    catch(err){ 
      const error = errorHelper(err);
      this.errorMessage = error;
    }
    finally{ this.isSubmitting = false}
  }

}
