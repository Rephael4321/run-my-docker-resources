import { NgClass } from '@angular/common';
import { Component, Input } from '@angular/core';


@Component({
  selector: 'app-spinner',
  standalone: true,
  template: `<div
    [ngClass]="{'spinner-border-sm': sm}"
   class="spinner-border" role="status">
    <span class="visually-hidden">Loading...</span>
  </div>`,
  imports: [NgClass],
})
export class SpinnerComponent {
  @Input() sm?: boolean;
}
