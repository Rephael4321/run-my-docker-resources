import { NgIf } from '@angular/common';
import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-success-alert',
  standalone: true,
  imports: [ NgIf ],
  templateUrl: './success-alert.component.html',
})
export class SuccessAlertComponent {


  @Input() successMessage!:string;
  @Output() onClose = new EventEmitter();

  close(){ this.onClose.emit(); }
}
