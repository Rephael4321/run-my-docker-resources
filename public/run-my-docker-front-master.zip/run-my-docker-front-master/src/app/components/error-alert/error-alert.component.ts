import { NgIf } from '@angular/common';
import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-error-alert',
  standalone: true,
  imports: [NgIf],
  templateUrl: './error-alert.component.html',
  styleUrl: './error-alert.component.scss'
})
export class ErrorAlertComponent {

  @Input() errorMessage!:string;
  @Output() onClose = new EventEmitter();

  close(){ this.onClose.emit(); }
  
}
