export const environment = {
  production: false,
  serverURL: "https://backend.runmydocker.com",
  encryptionSecretKey: "life-is-a-#$%^@"
};
