# RunMyDockerFront


## Description
Deploy up to 5 apps, easy and free!.

You provide a docker image path from your Dockerhub account and we will run it on our servers, 
with access to the live app, logs and easy management on our site.



## Dev Links

### Swagger
  https://backend.runmydocker.com/swagger-ui.html

### Design
https://xd.adobe.com/view/18080147-aa1e-4fa6-a799-ba27031a1b56-4d5b/

### Former app
- [Repo](https://github.com/NatanGer97/runmydocker-front)


## Testing Data

### Create New App:

```
{
  dockerImage: 'natanger97/web-scraping-chatbot:001',
  portMap: '8080',
  appName: 'scraper'
}

{
  dockerImage: 'nivitzhaky/chatbot:002',
  portMap: '8081',
  appName: 'chatbot'
}

```

