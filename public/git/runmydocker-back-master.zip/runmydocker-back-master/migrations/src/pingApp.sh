#!/bin/bash

# List of app names
apps=(
  "1234" "shohamd-tinyurl" "eduard-spring" "test265241" "demo70726"
  "demo47370" "cartcrafter2" "nitsnats-chatbot" "Modern_Backend"
  "demo92610" "demo17294" "dvirh-chatbot" "demo75049" "calanittest1"
  "calanittest2" "calanittest3" "test278210" "calanittest4" "test228274"
  "demo86768" "myfxbook-parser" "Eureka-server" "calanittest" "demo74667"
  "noam-chatbot" "demo98955" "test260019" "searchengine" "basic-spring"
  "test279090" "barak-chatbot" "demo34020" "test212345678" "sara-basicspring"
  "telegram-bot" "demo76628" "demo16162" "testt" "demo3868" "dvirh-spring"
  "gali-sentiment" "demo95032" "demo95395" "test206" "demo55944" "test204"
  "test202" "test203" "test201" "demo26291" "eduard-chatbot"
  "talentplease-tablesapi" "test272027" "gali-tinyurl" "eran-chatbot"
  "demo80338" "triel" "NotesAppDocker" "test21234" "test28548" "demo38484"
  "test0" "demo62166" "demo6104" "demo58344" "test2" "chat" "demo87917"
  "runmydocker-back" "pl-racism" "brachalink" "gali-searchengine" "demo68033"
  "demo92015" "tinyurl" "demo953" "test220246" "test2123" "ModernBackend"
  "demo54454" "noaa-tinyurl" "test250081" "java-docker" "nitsnats-tinyurl"
  "tatiana-chatbot" "test286251" "test283781"
)

# Iterate over each app name and make a curl request
for app in "${apps[@]}"; do
  url="https://${app}.runmydocker-app.com"
  echo "Checking: $url"
  curl -s -o /dev/null -w "%{http_code}\n" "$url"
done