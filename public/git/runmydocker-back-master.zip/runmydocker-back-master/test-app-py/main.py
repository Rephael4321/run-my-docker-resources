from fastapi import FastAPI, UploadFile, File, Form, Body, Depends
from fastapi.responses import FileResponse
from typing import Optional
import shutil
import os

app = FastAPI()

UPLOAD_DIR = "uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)

db = []  # Mock database

@app.post("/items/")
def create_item(
    name: str = Form(...),
    description: Optional[str] = Form(None),
    file: Optional[UploadFile] = File(None)
):
    file_path = None
    if file:
        file_path = os.path.join(UPLOAD_DIR, file.filename)
        with open(file_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)

    item = {"id": len(db) + 1, "name": name, "description": description, "file_path": file_path}
    db.append(item)
    return item

@app.get("/items/")
def get_items():
    return db

@app.get("/items/{item_id}")
def get_item(item_id: int):
    item = next((item for item in db if item["id"] == item_id), None)
    if not item:
        return {"error": "Item not found"}
    return item

@app.put("/items/{item_id}")
def update_item(item_id: int, name: Optional[str] = Form(None), description: Optional[str] = Form(None)):
    item = next((item for item in db if item["id"] == item_id), None)
    if not item:
        return {"error": "Item not found"}

    if name:
        item["name"] = name
    if description:
        item["description"] = description
        print("item", item)
    return item

@app.delete("/items/{item_id}")
def delete_item(item_id: int):
    global db
    db = [item for item in db if item["id"] != item_id]
    return {"message": "Item deleted successfully"}

@app.post("/upload/")
def upload_file(file: UploadFile = File(...)):
    file_path = os.path.join(UPLOAD_DIR, file.filename)
    with open(file_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)
    return {"filename": file.filename, "path": file_path}

@app.get("/files/")
def list_files():
    files = os.listdir(UPLOAD_DIR)
    return {"files": files}

@app.get("/files/{filename}")
def get_file(filename: str):
    file_path = os.path.join(UPLOAD_DIR, filename)
    if not os.path.exists(file_path):
        return {"error": "File not found"}
    return FileResponse(file_path)


@app.post("/test-json-request/")
def test_json_request(data: dict = Body(...)):
    return data


