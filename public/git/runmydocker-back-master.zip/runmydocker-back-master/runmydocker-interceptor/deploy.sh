JAVA_PROCESS_BACK="java -jar /root/runmydocker/v3/runmydocker-back/runmydocker-interceptor/target/runmydocker-interceptor-v3.jar"

# Find the PID of the Java process
JAVA_PID_BACK=$(pgrep -f "$JAVA_PROCESS_BACK")

if [ -z "$JAVA_PID_BACK" ]; then
    echo "Java BACK process not found."
else
    # Terminate the Java process
    echo "Terminating runmydocker-interceptor Java process with PID: $JAVA_PID_BACK"
    kill $JAVA_PID_BACK
fi

cd /root/runmydocker/v3/runmydocker-back/runmydocker-interceptor/
git pull
git switch master
git pull

mvn clean install -Dmaven.test.skip=true
nohup java -jar /root/runmydocker/v3/runmydocker-back/runmydocker-interceptor/target/runmydocker-interceptor-v3.jar --spring.profiles.active=prod  > logs-interceptor.txt &