package com.codingbc.runmydocker.services;

import com.codingbc.runmydocker.models.UserApplication;
import com.codingbc.runmydocker.repositories.UserApplicationRepository;
import com.codingbc.runmydocker.util.Dates;
import org.joda.time.DateTime;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class BackgroundTaskServiceTest {

    @Mock
    private UserApplicationRepository userApplicationRepository;
    @Mock
    private DockerService dockerService;

    @InjectMocks
    private BackgroundTaskService backgroundTaskService;

    @Test
    @DisplayName("updateReamaningTime should update the remaining time of all running applications")
    void updateReamaningTime() {

        UserApplication userApplication1 = new UserApplication();
        userApplication1.setRemainingTime(10);
        UserApplication userApplication2 = new UserApplication();
        userApplication2.setRemainingTime(5);

        UserApplication userApplication3 = new UserApplication();
        userApplication3.setRemainingTime(1);
        when(userApplicationRepository.findRunningApplications()).thenReturn(List.of(userApplication1, userApplication2, userApplication3));

        backgroundTaskService.updateRemainingTime();

        assertEquals(9, userApplication1.getRemainingTime());
        assertEquals(4, userApplication2.getRemainingTime());
        assertEquals(0, userApplication3.getRemainingTime());

        verify(dockerService).stopContainer(userApplication3.getAppName());
        verify(userApplicationRepository).saveAll(List.of(userApplication1, userApplication2, userApplication3));
    }


    @Test
    @DisplayName("stopIdleApplications should stop applications that have been idle for more than 10 minutes")
    void stopIdleApplications() {
        System.out.println("needs to implements");
    }
}