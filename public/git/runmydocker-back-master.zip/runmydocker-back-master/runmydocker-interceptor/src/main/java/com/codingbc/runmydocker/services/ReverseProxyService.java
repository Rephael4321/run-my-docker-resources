package com.codingbc.runmydocker.services;

import com.codingbc.runmydocker.exceptions.ContainerNotFoundException;
import com.codingbc.runmydocker.exceptions.TimeExpiredException;
import com.codingbc.runmydocker.models.UserApplication;
import com.codingbc.runmydocker.repositories.UserApplicationRepository;
import java.io.IOException;
import java.util.Optional;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class ReverseProxyService {

  public static final String APP_NAME_PANTRY_PAL = "pantrypal";
  public static final int PANTRY_PAL_SLEEP_TIME = 15;
  public static final int DEFAULT_SLEEP_TIME = 6;

  private final UserApplicationRepository userApplicationRepository;

  private final RequestForwader requestForwarder;

  private final ContainerManager containerManager;

  public ReverseProxyService(UserApplicationRepository userApplicationRepository, RequestForwader requestForwarder,
      ContainerManager containerManager) {
    this.userApplicationRepository = userApplicationRepository;
    this.requestForwarder = requestForwarder;
    this.containerManager = containerManager;
  }

  public void hadleIncomingRequest(HttpServletRequest request, HttpServletResponse response)
      throws InterruptedException, IOException {
    String applicationName = extractApplictionNameFromRequest(request);
    log.info("Handling request for application: {}", applicationName);
    Optional<UserApplication> optionalUserApplication = findApplicationByName(applicationName);
    if (optionalUserApplication.isEmpty() || !containerManager.isContainerExist(applicationName)) {
      throw new ContainerNotFoundException(applicationName);
    }
    UserApplication userApplication = optionalUserApplication.get();
    if (!containerManager.isContainerRunning(applicationName)) {
      if (userApplication.getRemainingTime() <= 0) {
        throw new TimeExpiredException(applicationName);
      }
      containerManager.startContainerWithDelay(response, userApplication);
    } else {
      containerManager.updateLastUsed(userApplication);
    }

    requestForwarder.forwardRequestToContainer(request, response, userApplication.getPort());

  }

  private String extractApplictionNameFromRequest(HttpServletRequest request) {
    return request.getServerName().split("\\.")[0];
  }

  public Optional<UserApplication> findApplicationByName(String applicationName) {
    return userApplicationRepository.findByAppName(applicationName);
  }

}
