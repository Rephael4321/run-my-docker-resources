package com.codingbc.runmydocker.exceptions;

public class ContainerNotReadyException extends RuntimeException {
    public ContainerNotReadyException(String message) {
        super(message);
    }
}