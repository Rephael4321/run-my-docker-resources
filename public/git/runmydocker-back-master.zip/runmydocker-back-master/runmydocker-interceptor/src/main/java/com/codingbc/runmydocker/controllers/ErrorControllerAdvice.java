package com.codingbc.runmydocker.controllers;

import com.codingbc.runmydocker.exceptions.ContainerNotFoundException;
import com.codingbc.runmydocker.exceptions.ContainerNotReadyException;
import com.codingbc.runmydocker.exceptions.TimeExpiredException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;

@ControllerAdvice
@Slf4j
public class ErrorControllerAdvice {

    @ExceptionHandler(ContainerNotFoundException.class)
    public ModelAndView handleContainerNotFound(ContainerNotFoundException ex) {
        ModelAndView mav = new ModelAndView("error-404");  // refers to not-found.html in templates folder
        mav.addObject("errorMessage", ex.getMessage());
        return mav;
    }

    @ExceptionHandler(TimeExpiredException.class)
    public ModelAndView handleTimeExpired(TimeExpiredException ex) {
        ModelAndView mav = new ModelAndView("time-expired");
        mav.addObject("errorMessage", ex.getMessage());
        return mav;
    }

    @ExceptionHandler(ContainerNotReadyException.class)
    public ModelAndView handleContainerNotReady(ContainerNotReadyException ex, HttpServletRequest request) {
        ModelAndView mav = new ModelAndView("container-not-ready");
        log.error("Container not ready: " + request.getRequestURL());
        mav.addObject("errorMessage", ex.getMessage());
        mav.addObject("appUrl", request.getRequestURI());
        return mav;
    }

    @ExceptionHandler(Exception.class)
    public ModelAndView handleGeneralError(HttpServletRequest request, Exception ex) {
        ModelAndView mav = new ModelAndView("error");  // refers to the new error page in templates folder
        ex.printStackTrace();
        mav.addObject("errorMessage", "An unexpected error occurred: " + ex.getMessage());
        mav.addObject("statusCode", "Error " + getErrorStatusCode(request));
        return mav;
    }

    private int getErrorStatusCode(HttpServletRequest request) {
        Integer statusCode = (Integer) request.getAttribute(RequestDispatcher.ERROR_STATUS_CODE);
        return (statusCode != null) ? statusCode : 500; // default to 500 if status code is not available
    }


}
