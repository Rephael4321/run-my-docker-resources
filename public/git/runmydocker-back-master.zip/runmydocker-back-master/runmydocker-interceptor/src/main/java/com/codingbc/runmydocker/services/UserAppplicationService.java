package com.codingbc.runmydocker.services;

import org.springframework.stereotype.Service;

import com.codingbc.runmydocker.models.UserApplication;
import com.codingbc.runmydocker.repositories.UserApplicationRepository;

import java.util.Optional;

@Service
public class UserAppplicationService {

    private final UserApplicationRepository userApplicationRepository;

    public UserAppplicationService(UserApplicationRepository userApplicationRepository) {
        this.userApplicationRepository = userApplicationRepository;
    }

    public Optional<UserApplication> findByApplicationName(String applicationName) {
        return userApplicationRepository.findByAppName(applicationName);


    }

}
