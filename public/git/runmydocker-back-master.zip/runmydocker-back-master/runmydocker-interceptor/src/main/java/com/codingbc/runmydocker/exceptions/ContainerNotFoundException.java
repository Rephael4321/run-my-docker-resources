package com.codingbc.runmydocker.exceptions;

public class ContainerNotFoundException extends RuntimeException {
    public ContainerNotFoundException(String applicationName) {
        super("Application '" + applicationName + "' not found.");
    }
}
