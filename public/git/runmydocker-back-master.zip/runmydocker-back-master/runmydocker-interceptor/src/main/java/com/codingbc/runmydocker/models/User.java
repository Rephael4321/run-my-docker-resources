package com.codingbc.runmydocker.models;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import org.hibernate.validator.constraints.Length;

import javax.persistence.*;
import javax.validation.constraints.Email;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Entity
@Table(name = "users")
public class User extends BaseEntity {

  @Length(min = 1, max = 60)
  private String firstName;

  @Length(min = 1, max = 60)
  private String lastName;

  @Email
  @Column(unique = true)
  private String username;

  @Column(name = "is_activated")
  private boolean isActivated;

  private String password;
  private String phone;

  @Column(name = "provider_id")
  private String providerId;

  private String role;

  @Column(name = "registration_completed")
  private boolean registrationCompleted;

  @JsonManagedReference
  @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = true)
  private List<ActivationCode> activationCodes = new ArrayList<>();

  public Set<UserApplication> getUserApplications() {
    return userApplications;
  }

  public void setUserApplications(Set<UserApplication> userApplications) {
    this.userApplications = userApplications;
  }

  @OneToMany(
      mappedBy = "user",
      cascade = {CascadeType.PERSIST, CascadeType.REMOVE})
  private Set<UserApplication> userApplications = new HashSet<>();

  public List<ActivationCode> getActivationCodes() {
    return activationCodes;
  }

  public ActivationCode getLastActivationCode() {
    return this.activationCodes.get(this.activationCodes.size() - 1);
  }

  public void setActivationCodes(List<ActivationCode> activationCodes) {
    this.activationCodes = activationCodes;
  }

  public void addActivationCode(ActivationCode activationCode) {
    activationCode.setUser(this);
    activationCodes.add(activationCode);
  }

  public void removeActicationCode(ActivationCode activationCode) {
    activationCode.setUser(null);
    activationCodes.remove(activationCode);
  }

  public User() {
    isActivated = false;
    registrationCompleted = false;
  }

  @Override
  public String toString() {
    return "User{"
        + "firstName='"
        + firstName
        + '\''
        + ", lastName='"
        + lastName
        + '\''
        + ", username='"
        + username
        + '\''
        + ", isActivated="
        + isActivated
        + ", password='"
        + password
        + '\''
        + ", phone='"
        + phone
        + '\''
        + ", providerId='"
        + providerId
        + '\''
        + ", role='"
        + role
        + '\''
        + ", registrationCompleted="
        + registrationCompleted
        + ", activationCodes="
        + activationCodes
        + '}';
  }

  public String getFirstName() {
    return firstName;
  }

  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }

  public String getLastName() {
    return lastName;
  }

  public void setLastName(String lastName) {
    this.lastName = lastName;
  }

  public String getUsername() {
    return username;
  }

  public void setUsername(String username) {
    this.username = username;
  }

  public boolean isActivated() {
    return isActivated;
  }

  public void setActivated(boolean activated) {
    isActivated = activated;
  }

  public String getPassword() {
    return password;
  }

  public void setPassword(String password) {
    this.password = password;
  }

  public String getPhone() {
    return phone;
  }

  public void setPhone(String phone) {
    this.phone = phone;
  }

  public String getProviderId() {
    return providerId;
  }

  public void setProviderId(String providerId) {
    this.providerId = providerId;
  }

  public boolean isRegistrationCompleted() {
    return registrationCompleted;
  }

  public void setRegistrationCompleted(boolean registrationCompleted) {
    this.registrationCompleted = registrationCompleted;
  }

  public int getApplicationCount() {
    return userApplications.size();
  }
}
