package com.codingbc.runmydocker.controllers;

import com.codingbc.runmydocker.services.DockerService;
import com.codingbc.runmydocker.services.ProxyService;
import com.codingbc.runmydocker.services.ReverseProxyService;
import com.github.dockerjava.api.model.Container;
import com.sun.tools.jconsole.JConsoleContext;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

@RestController
@Slf4j
public class ProxyController {

  @Autowired
  private ProxyService proxyService;
  @Autowired
  private ReverseProxyService reverseProxyService;

  @Autowired
  private DockerService dockerService;

  @RequestMapping(method = {
      RequestMethod.GET,
      RequestMethod.POST,
      RequestMethod.DELETE,
      RequestMethod.PUT,
      RequestMethod.PATCH,
      RequestMethod.OPTIONS,
      RequestMethod.TRACE
  }, value = "/**")
  public void interceptRequest(HttpServletRequest request, HttpServletResponse response)
      throws IOException, InterruptedException {
    log.info("Intercepting request to {}", request.getRequestURI());

    reverseProxyService.hadleIncomingRequest(request, response);
  }

  @GetMapping("/test")
  public void test() {
    dockerService
        .getRunningContainers()
        .forEach(
            container -> {
              String[] names = container.getNames();
              names[0] = names[0].substring(1);
              log.info("Container name: {}", Arrays.toString(names));
            });
  }
}
