/*
 * Copyright (c) 2024.
 */

package com.codingbc.runmydocker.enums;

public enum AppActions {
  START,
  STOP,
  DELETE,
  KILL,
  CREATE
}
