package com.codingbc.runmydocker.services;

import com.codingbc.runmydocker.exceptions.ContainerNotReadyException;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Collection;
import java.util.Enumeration;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.TimeUnit;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import lombok.extern.slf4j.Slf4j;
import okhttp3.*;
import org.springframework.stereotype.Service;
import org.springframework.util.PathMatcher;
import org.springframework.web.servlet.HandlerMapping;

@Service
@Slf4j
public class RequestForwader {

  private final OkHttpClient httpClient;
  private PathMatcher pathMatcher;

  public RequestForwader(PathMatcher pathMatcher) {
    this.pathMatcher = pathMatcher;
    this.httpClient = new OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .writeTimeout(20, TimeUnit.SECONDS)
        .callTimeout(20, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build();


  }

  public void forwardRequestToContainer(HttpServletRequest request, HttpServletResponse response, int containerPort)
      throws IOException {
    forwardRequestToContainer("localhost", request, response, containerPort);
  }

  public void forwardRequestToContainer(String host, HttpServletRequest request, HttpServletResponse response,
      int containerPort) {
    Request forwardToContainerRequest = buildContainerRequest(host, request, containerPort);
    Call call = httpClient.newCall(forwardToContainerRequest);
    try (Response containerResponse = call.execute()) {
      handleRedirect(containerResponse.priorResponse(), response);
      writeContainerResponse(response, containerResponse);
    } catch (IOException e) {
      throw new ContainerNotReadyException("Application is not ready");
    }
  }


  private void handleRedirect(Response priorResponse, HttpServletResponse response) throws IOException {
    if (priorResponse != null && priorResponse.isRedirect()) {
      response.sendRedirect(priorResponse.header("Location"));
    }
  }

  private Request buildContainerRequest(String host, HttpServletRequest request, int containerPort) {
    String url = buildContainerUrl(host, request, containerPort);
    RequestBody requestBody = request.getMethod().equals("GET") ? null : createRequestBody(request);
    Request.Builder requestBuilder = new Request.Builder().url(url);

    if (requestBody != null) {
      requestBuilder.method(request.getMethod(), requestBody);
    }
    setHeadersToContainerRequest(request, requestBuilder);

    return requestBuilder.build();

  }

  private void setHeadersToContainerRequest(HttpServletRequest request, Request.Builder requestBuilder) {
    Enumeration<String> headerNames = request.getHeaderNames();
    while (headerNames.hasMoreElements()) {
      String headerName = headerNames.nextElement();
      requestBuilder.addHeader(headerName, request.getHeader(headerName));
    }
  }


  private RequestBody createRequestBody(HttpServletRequest request) {
    try {
      String contentType = request.getContentType();
      byte[] bodyAsBytes = request.getInputStream().readAllBytes();
      if (contentType == null) {
        return RequestBody.create(bodyAsBytes, null);
      }
      if (contentType.startsWith("multipart/form-data")) {
        return createMultipartRequestBody(request);
      }
      else if (contentType.startsWith("application/json")) {
        return RequestBody.create(bodyAsBytes, MediaType.parse(contentType));
      }
      else if (contentType.startsWith("application/x-www-form-urlencoded")) {
        return createApplicationXWwwFormUrlencodedRequestBody(request);
      }
      else {
        return RequestBody.create(bodyAsBytes, MediaType.parse(contentType));
      }
    } catch (IOException e) {
      log.error("Error while reading request body: {}", e.getMessage());
      return null;
    } catch (ServletException e) {
        throw new RuntimeException(e);
    }
  }

  private RequestBody createApplicationXWwwFormUrlencodedRequestBody(HttpServletRequest request) throws IOException {
    FormBody.Builder builder = new FormBody.Builder();
    Enumeration<String> parameterNames = request.getParameterNames();
    while (parameterNames.hasMoreElements()) {
      String parameterName = parameterNames.nextElement();
      builder.add(parameterName, request.getParameter(parameterName));
    }
    return builder.build();
  }

  private RequestBody createMultipartRequestBody(HttpServletRequest request) throws ServletException, IOException {
    MultipartBody.Builder builder = new MultipartBody.Builder();
    builder.setType(MultipartBody.FORM);

    // Add file and text parts
    Collection<Part> parts = request.getParts();
    for (Part part : parts) {
      if (part.getSubmittedFileName() != null) { // File
        builder.addFormDataPart(part.getName(), part.getSubmittedFileName(),
                RequestBody.create(part.getInputStream().readAllBytes(), MediaType.parse(part.getContentType())));
      } else { // Text
        builder.addFormDataPart(part.getName(), new String(part.getInputStream().readAllBytes()));
      }
    }
    return builder.build();
  }

  private String buildContainerUrl(String host, HttpServletRequest request, int containerPort) {
    String wildCardParam = getWildCardParam(request);
    String queryString = request.getQueryString();
    String baseUrl = buildBaseUrl(host, containerPort, wildCardParam);
    return appendQueryString(baseUrl, queryString);
  }

  private String buildBaseUrl(String host, int containerPort, String wildCardParam) {
    String url = String.format("http://%s:%d/%s", host, containerPort, wildCardParam);
    return url.endsWith("//") ? url.substring(0, url.length() - 1) : url;
  }

  private String appendQueryString(String url, String queryString) {
    return queryString != null ? url + "?" + queryString : url;
  }

  private String getWildCardParam(HttpServletRequest request) {
    String pattern = (String) request.getAttribute(HandlerMapping.BEST_MATCHING_PATTERN_ATTRIBUTE);
    String path = (String) request.getAttribute(HandlerMapping.PATH_WITHIN_HANDLER_MAPPING_ATTRIBUTE);
    String wildCardParam = pathMatcher.extractPathWithinPattern(pattern, path);

    if (request.getRequestURI().endsWith("/") && !wildCardParam.endsWith("/")) {
      wildCardParam += "/";
    }
    return wildCardParam;
  }

  private void writeContainerResponse(HttpServletResponse response, Response containerResponse) throws IOException {
    ResponseBody containerResponseBody = containerResponse.body();
    if (containerResponseBody != null) {
      response.setContentType(Optional.ofNullable(containerResponseBody.contentType())
          .map(MediaType::toString)
          .orElse(""));
      response.setContentLength((int) containerResponseBody.contentLength());

      try (OutputStream outputStream = response.getOutputStream()) {
        byte[] buffer = new byte[1024];
        int length;
        while ((length = containerResponseBody.byteStream().read(buffer)) != -1) {
          outputStream.write(buffer, 0, length);
        }
      }
    } else {
      log.error("Response body is null");

    }
  }


}
