package com.codingbc.runmydocker.exceptions;

public class TimeExpiredException extends RuntimeException {
    public TimeExpiredException(String applicationName) {
        super("The application '" + applicationName + "' has reached its running time.");
    }
}
