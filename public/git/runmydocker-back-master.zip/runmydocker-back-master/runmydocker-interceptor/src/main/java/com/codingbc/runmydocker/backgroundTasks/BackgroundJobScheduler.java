package com.codingbc.runmydocker.backgroundTasks;

import com.codingbc.runmydocker.services.BackgroundTaskService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class BackgroundJobScheduler {

    private final BackgroundTaskService backgroundTaskService;

    @Autowired
    public BackgroundJobScheduler(BackgroundTaskService backgroundTaskService) {
        this.backgroundTaskService = backgroundTaskService;
    }

    // Run every 1 minute
    @Scheduled(fixedRate = 60 * 1000)
    public void updateRemainingTime() {
        backgroundTaskService.updateRemainingTime();
    }

    // Run every 10 minutes
    @Scheduled(fixedRate =  10 * 60 * 1000)
    public void stopIdleApplications() {
        backgroundTaskService.stopIdleApplications();
    }
}
