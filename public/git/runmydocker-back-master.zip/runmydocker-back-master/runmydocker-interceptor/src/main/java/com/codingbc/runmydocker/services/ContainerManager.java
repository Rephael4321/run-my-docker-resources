package com.codingbc.runmydocker.services;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Service;

import com.codingbc.runmydocker.models.UserApplication;
import com.codingbc.runmydocker.repositories.UserApplicationRepository;
import com.codingbc.runmydocker.util.Dates;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ContainerManager {
    private final DockerService dockerService;
    private final UserApplicationRepository userApplicationRepository;

    public ContainerManager(DockerService dockerService, UserApplicationRepository userApplicationRepository) {
        this.dockerService = dockerService;
        this.userApplicationRepository = userApplicationRepository;
    }

    public boolean isContainerExist(String appName) {
        return dockerService.isContainerExist(appName);
    }

    public boolean isContainerRunning(String appName) {
        return isContainerExist(appName) && dockerService.isContainerRunning(appName);
    }

    public void startContainerWithDelay(HttpServletResponse response, UserApplication userApplication)
            throws IOException, InterruptedException {
        boolean isContainerStarted = dockerService.startContainer(userApplication.getAppName());
        if (!isContainerStarted) {
            log.error("Error while starting container: {}", userApplication.getAppName());
            response.sendError(500, "Error while starting container");
            return;
        }

        updateLastUsed(userApplication);

        int sleepTime = userApplication.getAppName().equals(ReverseProxyService.APP_NAME_PANTRY_PAL)
                ? ReverseProxyService.PANTRY_PAL_SLEEP_TIME
                : ReverseProxyService.DEFAULT_SLEEP_TIME;

        TimeUnit.SECONDS.sleep(sleepTime);

    }

    public void updateLastUsed(UserApplication userApplication) {
        userApplication.setLastUsed(Dates.nowUTC());
        userApplication.setRunning(true);
        userApplicationRepository.saveAndFlush(userApplication);
    }

}
