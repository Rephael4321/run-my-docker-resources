package com.codingbc.runmydocker.services;

import com.github.dockerjava.api.DockerClient;
import com.github.dockerjava.api.command.InspectContainerResponse;
import com.github.dockerjava.api.command.StartContainerCmd;
import com.github.dockerjava.api.exception.DockerException;
import com.github.dockerjava.api.exception.NotFoundException;

import com.github.dockerjava.api.model.Container;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Slf4j
public class DockerService {
    private final DockerClient dockerClient;

    public DockerService(DockerClient dockerClient) {
        this.dockerClient = dockerClient;
    }

    public boolean isContainerRunning(String containerName) {
        try {
            InspectContainerResponse inspectContainerResponse = inspectContainer(containerName);
            return Boolean.TRUE.equals(inspectContainerResponse.getState().getRunning());
        } catch (Exception e) {
            log.error(e.getMessage());
            log.error("Container {} not found.", containerName);
            return false;
        }

    }

    private InspectContainerResponse inspectContainer(String containerName) throws NotFoundException {
        return dockerClient.inspectContainerCmd(containerName)
                .exec();
    }

    public boolean isContainerExist(String containerName) {
        try {
            InspectContainerResponse inspectContainer = inspectContainer(containerName);
            return inspectContainer != null;
        } catch (NotFoundException exception) {
            log.error(exception.getMessage());
            log.error("Container {} not found", containerName);
            return false;
        }

    }

    public List<Container> getRunningContainers() {
       return dockerClient.listContainersCmd().exec();
    }

    public boolean startContainer(String containerName) {
        try {
            StartContainerCmd startContainerCmd = dockerClient.startContainerCmd(containerName);
            startContainerCmd.exec();
            return true;
        } catch (DockerException e) {
            log.error("Error starting container: " + containerName);
            log.error(e.toString());
            return false;

        }
    }

    public void stopContainer(String containerName) {
        try {
            dockerClient.stopContainerCmd(containerName).exec();
        } catch (DockerException e) {
            log.error("Error stopping container: " + containerName);
            log.error(e.toString());
        }
    }
}
