package com.codingbc.runmydocker.services;

import com.codingbc.runmydocker.models.UserApplication;
import com.codingbc.runmydocker.repositories.UserApplicationRepository;
import com.codingbc.runmydocker.util.Dates;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import okhttp3.*;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Service;
import org.springframework.util.PathMatcher;
import org.springframework.web.servlet.HandlerMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

@Service
@Slf4j
public class ProxyService {

    private static final String APP_NAME_PANTRY_PAL = "pantrypal";
    private static final int PANTRY_PAL_SLEEP_TIME = 15;
    private static final int DEFAULT_SLEEP_TIME = 6;
    private static final String CONTENT_TYPE_JSON = "application/json";

    private final UserApplicationRepository userApplicationRepository;
    private final DockerService dockerService;
    private final List<String> IGNORE_APPLICATION_NAMES;
    private final OkHttpClient client;

    @Autowired
    private PathMatcher pathMatcher;

    @Autowired
    private ResourceLoader resourceLoader;

    public ProxyService(UserApplicationRepository userApplicationRepository,
            DockerService dockerService) {
        this.userApplicationRepository = userApplicationRepository;
        this.dockerService = dockerService;
        this.IGNORE_APPLICATION_NAMES = Arrays.asList("runmydocker-app", "www");
        this.client = new OkHttpClient();
    }

    // Extracted method for request body creation
    @NotNull
    private static RequestBody getRequestBody(HttpServletRequest request) throws IOException {
        return RequestBody.create(MediaType.parse(CONTENT_TYPE_JSON),
                request.getReader().lines().collect(Collectors.joining(System.lineSeparator())));
    }

    private RequestBody createRequestBody(HttpServletRequest request) {
        try {
            byte[] bodyBytes = bodyBytes = request.getInputStream().readAllBytes();
            return RequestBody.create(bodyBytes, MediaType.parse(request.getContentType()));

        } catch (IOException e) {
            log.info("Error while reading request body: {}", e.getMessage());
            return null;
        }
    }

    public void handleIncomingRequest(HttpServletRequest request, HttpServletResponse response)
            throws IOException, InterruptedException {

        String applicationName = extractApplicationNameFromRequest(request);

        Optional<UserApplication> optionalUserApplication = getApplicationByName(applicationName);
        if (optionalUserApplication.isEmpty()) {
            handleApplicationNotFound(response);
            return;
        }

        UserApplication userApplication = optionalUserApplication.get();
        if (!dockerService.isContainerExist(applicationName)) {
            log.error("Container not exist for application: {}", applicationName);
            // dockerService.handleContainerNotExist(applicationName); // Uncomment if
            // needed
            return;
        }

        if (userApplication.getRemainingTime() <= 0) {
            handleNegativeRemainingTime(response, applicationName);
            return;
        }

        manageContainerLifecycle(request, response, userApplication);
    }

    private void handleApplicationNotFound(HttpServletResponse response) throws IOException {
        log.error("Application not found");

        response.setStatus(HttpServletResponse.SC_NOT_FOUND);

        Resource resource = resourceLoader.getResource("classpath:/static/error-404.html");

        response.setContentType(org.springframework.http.MediaType.TEXT_HTML_VALUE);
        resource.getInputStream().transferTo(response.getOutputStream());

        response.flushBuffer();
    }

    private void manageContainerLifecycle(HttpServletRequest request, HttpServletResponse response,
            UserApplication userApplication)
            throws IOException, InterruptedException {

        if (!dockerService.isContainerRunning(userApplication.getAppName())) {
            startContainerWithDelay(response, userApplication);
        } else {
            updateLastUsed(userApplication, false);
        }
        forwardRequestToContainer(request, response, userApplication.getPort());
    }

    private void startContainerWithDelay(HttpServletResponse response, UserApplication userApplication)
            throws IOException, InterruptedException {

        boolean isContainerStarted = dockerService.startContainer(userApplication.getAppName());
        if (!isContainerStarted) {
            log.error("Error while starting container: {}", userApplication.getAppName());
            response.sendError(500, "Error while starting container");
            return;
        }

        updateLastUsed(userApplication, true);

        int sleepTime = userApplication.getAppName().equals(APP_NAME_PANTRY_PAL) ? PANTRY_PAL_SLEEP_TIME
                : DEFAULT_SLEEP_TIME;
        TimeUnit.SECONDS.sleep(sleepTime); // waits for container to start

    }

    private void updateLastUsed(UserApplication userApplication, boolean setRunning) {
        if (setRunning) {
            userApplication.setRunning(true);
        }
        userApplication.setLastUsed(Dates.nowUTC());
        userApplicationRepository.saveAndFlush(userApplication);
    }

    private void handleNegativeRemainingTime(HttpServletResponse response, String applicationName)
            throws IOException {
        log.info("Application time expired: {}", applicationName);

        response.setStatus(HttpServletResponse.SC_NOT_FOUND);

        Resource resource = resourceLoader.getResource("classpath:/static/time-expired.html");

        response.setContentType(org.springframework.http.MediaType.TEXT_HTML_VALUE);
        resource.getInputStream().transferTo(response.getOutputStream());

        response.flushBuffer();
    }

    public String extractApplicationNameFromRequest(HttpServletRequest request) {
        return request.getServerName().split("\\.")[0];
    }

    public Optional<UserApplication> getApplicationByName(String applicationName) {
        return userApplicationRepository.findByAppName(applicationName);
    }

    public void forwardRequestToContainer(HttpServletRequest request, HttpServletResponse response, int containerPort)
            throws IOException {
        forwardRequestToContainer("localhost", request, response, containerPort);
    }

    private void forwardRequestToContainer(String host, HttpServletRequest request, HttpServletResponse response,
            int containerPort) throws IOException {
        Request forwardToContainerRequest = buildContainerRequest(host, request, containerPort);
        try (Response containerResponse = client.newCall(forwardToContainerRequest).execute()) {
            handleRedirect(containerResponse.priorResponse(), response);
            writeContainerResponse(response, containerResponse);
        }
    }

    private Request buildContainerRequest(String host, HttpServletRequest request, int containerPort)
            throws IOException {
        String url = buildContainerUrl(host, request, containerPort);
        RequestBody requestBody = request.getMethod().equals("GET") ? null : createRequestBody(request);

        Request.Builder requestBuilder = new Request.Builder().url(url);
        if (requestBody != null) {
            requestBuilder.method(request.getMethod(), requestBody);
        }
        setHeadersToContainerRequest(request, requestBuilder);
        return requestBuilder.build();
    }

    private String buildContainerUrl(String host, HttpServletRequest request, int containerPort) throws IOException {
        String wildCardParam = getWildCardParam(request);
        String url = String.format("http://%s:%d/%s", host, containerPort, wildCardParam);
        return url.endsWith("//") ? url.substring(0, url.length() - 1) : url;
    }

    private void writeContainerResponse(HttpServletResponse response, Response containerResponse) throws IOException {
        ResponseBody containerResponseBody = containerResponse.body();
        if (containerResponseBody == null) {
            log.error("Response body is null");
            return;
        }
        response.setContentType(Optional.ofNullable(containerResponseBody.contentType())
                .map(MediaType::toString)
                .orElse(""));
        response.setContentLength((int) containerResponseBody.contentLength());

        try (OutputStream outputStream = response.getOutputStream()) {
            byte[] buffer = new byte[1024];
            int length;
            while ((length = containerResponseBody.byteStream().read(buffer)) != -1) {
                outputStream.write(buffer, 0, length);
            }
        }
    }

    private void handleRedirect(Response priorResponse, HttpServletResponse response) throws IOException {
        log.info("Handling redirect", priorResponse);
        if (priorResponse != null && priorResponse.isRedirect()) {
            log.info("Redirecting to: {}", priorResponse.header("Location"));
            response.sendRedirect(priorResponse.header("Location"));
        }
    }

    private void setHeadersToContainerRequest(HttpServletRequest request, Request.Builder requestBuilder) {
        Enumeration<String> headerNames = request.getHeaderNames();
        while (headerNames.hasMoreElements()) {
            String headerName = headerNames.nextElement();
            requestBuilder.addHeader(headerName, request.getHeader(headerName));
        }
    }

    private String getWildCardParam(HttpServletRequest request) {
        String pattern = (String) request.getAttribute(HandlerMapping.BEST_MATCHING_PATTERN_ATTRIBUTE);
        String path = (String) request.getAttribute(HandlerMapping.PATH_WITHIN_HANDLER_MAPPING_ATTRIBUTE);
        String wildCardParam = pathMatcher.extractPathWithinPattern(pattern, path);

        if (request.getRequestURI().endsWith("/") && !wildCardParam.endsWith("/")) {
            wildCardParam += "/";
        }
        return wildCardParam;
    }
}
