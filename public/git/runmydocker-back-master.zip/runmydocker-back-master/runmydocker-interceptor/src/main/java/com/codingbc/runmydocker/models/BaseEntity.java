package com.codingbc.runmydocker.models;

import com.codingbc.runmydocker.util.Dates;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.jetbrains.annotations.NotNull;
import org.joda.time.LocalDateTime;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import java.util.Date;

@MappedSuperclass
@Getter @Setter
@AllArgsConstructor
@NoArgsConstructor
public abstract class BaseEntity {

  @Id @GeneratedValue(strategy = GenerationType.SEQUENCE)
  private long id;

  @NotNull private final Date createdAt = Dates.nowUTC();

  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
  @JsonProperty("createdAt")
  public LocalDateTime calcCreatedAt() {
    return Dates.atLocalTime(createdAt);
  }
}
