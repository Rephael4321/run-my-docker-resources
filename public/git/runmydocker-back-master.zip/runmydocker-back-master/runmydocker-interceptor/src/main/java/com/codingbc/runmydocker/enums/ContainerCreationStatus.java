/*
 * Copyright (c) 2024.
 */

package com.codingbc.runmydocker.enums;

public enum ContainerCreationStatus {
  PENDING,
  PULLING,
  CREATING,
  CREATED,
  FAILED
}
