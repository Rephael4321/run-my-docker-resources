package com.codingbc.runmydocker.services;

import com.codingbc.runmydocker.models.UserApplication;
import com.codingbc.runmydocker.repositories.UserApplicationRepository;
import com.codingbc.runmydocker.util.Dates;
import com.github.dockerjava.api.model.Container;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class BackgroundTaskService {

    @Autowired
    private UserApplicationRepository userApplicationRepository;
    @Autowired
    private DockerService dockerService;


    public void updateRemainingTime() {
        List<UserApplication> runningApplications = userApplicationRepository.findRunningApplications();
        runningApplications.forEach(this::updateApplicationTime);
        userApplicationRepository.saveAll(runningApplications);
    }

    private void updateApplicationTime(UserApplication userApplication) {
        userApplication.setRemainingTime(userApplication.getRemainingTime() - 1);
        if (userApplication.getRemainingTime() <= 0) {
            log.info("Container needs to be stopped due to time expiration: {}", userApplication.getAppName());
            dockerService.stopContainer(userApplication.getAppName());
            userApplication.setRunning(false);
        }
    }

    public void stopIdleApplications() {
        dockerService.getRunningContainers().parallelStream()
                .filter(container -> container.getNames().length > 0)
            .filter(container -> {
                boolean hasNames = container.getNames().length > 0;
                Map<String, String> labels = container.getLabels();
                boolean isRunMyDocker = labels.containsKey("created_by") && labels.get("created_by").equals("runmydocker");
                return hasNames && isRunMyDocker;
            }).forEach(this::processRunningContainer);
    }

    private void processRunningContainer(Container container) {
        String containerName = extractContainerName(container);
        String containerId = container.getId();
        Optional<UserApplication> userApplication = userApplicationRepository.findUserApplicationByContainerIdOrAppName(containerId, containerName);
        userApplication.ifPresent(this::stopIfIdle);
    }

    private String extractContainerName(Container container) {
        return container.getNames()[0].substring(1); // Skip the '/' in the container name
    }

    private void stopIfIdle(UserApplication userApplication) {
        log.info("Checking idle application: {}", userApplication.getAppName());
        DateTime tenMinutesAgo = Dates.atLocalTime(Dates.nowUTC()).toDateTime().minusMinutes(10);
        if (userApplication.getLastUsed().before(tenMinutesAgo.toDate())) {
            log.info("Stopping idle application: {}", userApplication.getAppName());
            userApplication.setRunning(false);
            userApplicationRepository.save(userApplication);
            dockerService.stopContainer(userApplication.getAppName());
        }
    }
}
