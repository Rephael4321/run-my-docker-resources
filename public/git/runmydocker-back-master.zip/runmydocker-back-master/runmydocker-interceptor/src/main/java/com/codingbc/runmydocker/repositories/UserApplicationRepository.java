/*
 * Copyright (c) 2024.
 */

package com.codingbc.runmydocker.repositories;

import com.codingbc.runmydocker.enums.ContainerCreationStatus;
import com.codingbc.runmydocker.models.UserApplication;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;
import java.util.Optional;

public interface UserApplicationRepository extends JpaRepository<UserApplication, Long> {

    Optional<UserApplication> findByAppName(String appName);

    @Query("select (count(u) > 0) from UserApplication u where u.appName = ?1")
    boolean existsByAppName(String appName);


    @Query("select (count(u) > 0) from UserApplication u where u.port = ?1")
    boolean isHostPortTaken(int port);

    @Transactional
    @Modifying
    @Query("update UserApplication u set u.status = ?1 where u.id = ?2")
    void updateStatusById(ContainerCreationStatus status, long id);

    @Transactional
    @Modifying
    @Query("update UserApplication u set u.creationError = ?1,  u.status = ?2 where u.id = ?3")
    void updateCreationErrorById(String creationError, ContainerCreationStatus status, long id);

    @Transactional
    @Modifying
    @Query(
            "update UserApplication u set u.status = ?1, u.containerId = ?2, u.creationError = NULL where u.id = ?3")
    void updateStatusAndContainerIdAndCreationErrorById(
            ContainerCreationStatus status, String containerId, long id);

    @Transactional
    @Modifying
    @Query("update UserApplication u set u.creationError = ?1, u.status = ?2 where u.id = ?3")
    int updateCreationErrorAndStatusById(
            String creationError, ContainerCreationStatus status, long id);

    @Query("select u from UserApplication u where u.id = ?1 and u.appName = ?2")
    Optional<UserApplication> findByIdAndAppName(long id, String appName);

    @Query("select ua from UserApplication  ua where ua.isRunning = true ")
    List<UserApplication> findRunningApplications();

    @Query("select u from UserApplication u where u.lastUsed <= ?1")
    List<UserApplication> findByLastUsedLessThanEqual(Date lastUsed);
    Optional<UserApplication> findUserApplicationByContainerIdOrAppName(String containerId, String appName);
}
