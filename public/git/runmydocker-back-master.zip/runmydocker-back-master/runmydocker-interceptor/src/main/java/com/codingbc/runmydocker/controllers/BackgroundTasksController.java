package com.codingbc.runmydocker.controllers;

import com.codingbc.runmydocker.services.BackgroundTaskService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/background-tasks")
public class BackgroundTasksController {

  @Autowired
  private BackgroundTaskService backgroundTaskService;

  @RequestMapping("/update-remaining-time")
  public void updateRemainingTime() {
    backgroundTaskService.updateRemainingTime();
  }

  @RequestMapping("/stop-idle-applications")
  public void stopIdleApplications() {
    backgroundTaskService.stopIdleApplications();
  }

}
