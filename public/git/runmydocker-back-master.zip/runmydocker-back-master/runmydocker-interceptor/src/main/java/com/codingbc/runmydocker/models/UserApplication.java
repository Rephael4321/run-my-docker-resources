/*
 * Copyright (c) 2024.
 */

package com.codingbc.runmydocker.models;

import com.codingbc.runmydocker.enums.ContainerCreationStatus;
import com.codingbc.runmydocker.util.Dates;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;
import org.joda.time.LocalDateTime;
import org.springframework.beans.factory.annotation.Value;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "user_applications")
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class UserApplication extends BaseEntity {

  public static final String APP_STARTED_MESSAGE = "Application started successfully";
  public static final String APP_STOPPED_MESSAFE = "Application stopped successfully";
  public static final String APP_DELETED_MESSAGE = "Application deleted successfully";

  @Column(unique = true)
  private int port;

  @Column(name = "container_port") // mapping port
  private int containerPort;

  @Column(name = "docker_image")
  private String dockerImage;

  private String containerId;

  @Column(name = "application_name", unique = true)
  private String appName;

  private boolean isRunning = false;
  private Boolean minikubeApp = false;
  private String username;

  @Value("${totalRunningMinutes}")
  private int remainingTime = 6000; // 100 hours = 6000 minutes

  @Enumerated(EnumType.STRING)
  private ContainerCreationStatus status;

  @Column(name = "last_used")
  private Date lastUsed = Dates.nowUTC();

  @JsonFormat(shape = Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
  @JsonProperty("lastUsed")
  public LocalDateTime calcLastUsed() {
    return Dates.atLocalTime(lastUsed);
  }

  @Column(name = "creation_error")
  private String creationError;

  @JsonIgnore
  @ManyToOne
  @JoinColumn(name = "user_id")
  private User user;

  @Transient
  private boolean canBeStarted;

  public boolean isCanBeStarted() {
    return this.remainingTime > 0 && !this.isRunning;
  }

  public void setRunning(boolean running) {
    isRunning = running;
  }
}
