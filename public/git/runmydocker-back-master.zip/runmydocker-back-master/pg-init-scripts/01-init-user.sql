INSERT INTO public.users (
        id,
        created_at,
        first_name,
        is_activated,
        last_name,
        old_created_at,
        password,
        phone,
        provider_id,
        registration_completed,
        role,
        username
    )
VALUES (
        1,
        '2025-05-23 13:27:26.172000',
        'admin',
        true,
        'admin',
        null,
        '$2a$10$nkjUsChBjOcy5IpKuCuRe.aJ8VdeuDDZpis/0Z31mqhUvaRRuUWxy',
        '+972-546594945',
        null,
        true,
        null,
        'admin@admin.com'
    );