flowchart TD
A["User request to create new app"] --> B["CRUD Service"]
B --> C["Validate Request"]
C -->|Validation passed| D["Create container resource - initial state"]
D --> E["Pull image from Docker Hub"]
E -->|Success| F["Create container on host (local or prod)"]
E -->|Fail| Z1["Set status to FAILED\nReason: image pull error"]

    F -->|Success| G["Validate container is running properly"]
    F -->|Fail| Z2["Set status to FAILED\nReason: container creation error"]

    G -->|Validation passed| H["Update DB status to RUNNING\nComplete process"]
    G -->|Fail| Z3["Set status to FAILED\nReason: validation error"]

    Z1 --> END["Process Stopped"]
    Z2 --> END
    Z3 --> END
