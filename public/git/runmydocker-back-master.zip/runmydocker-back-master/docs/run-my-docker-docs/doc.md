# Run-My-Docker Backend Technical Documentation

## 📋 Project Overview

**Run-My-Docker** is a backend system that provides users with the ability to deploy projects based on Docker containers. Users provide Docker images and port configurations, while the system handles the deployment, management, and routing of containerized applications.

---

## 🏗️ System Architecture

The backend consists of **two main Spring Boot services** that work together to provide a complete Docker deployment platform:

```
[Client] → [Interceptor Service] → [Docker Containers]
    ↓                    ↓
[CRUD Service] -> [PostgreSQL Database]
    ↓
[RabbitMQ]
```

---

## 🔧 Technology Stack

| Component                | Technology               |
| ------------------------ | ------------------------ |
| **Framework**            | Spring Boot 2.5.2        |
| **Java Version**         | Java 8                   |
| **Database**             | PostgreSQL               |
| **Message Queue**        | RabbitMQ                 |
| **Container Management** | Docker SDK               |
| **Deployment**           | Single server deployment |

---

## 🚀 Service Architecture

### 1. CRUD Service (Main Backend API)

> **Purpose:** Handles user management, authentication, and application lifecycle management.

#### Controllers:

- **AuthController:** Manages user authentication, JWT tokens, registration, and account activation
- **UserApplicationController:** Handles CRUD operations for user applications (create containers, start/stop, logs management and etc.)
- **OAuth2Controller** _(out of scope):_ Manages Google authentication

#### Key Responsibilities:

- User registration and authentication with JWT
- Direct Docker container creation via Docker SDK
- Application lifecycle management (create, start, stop, delete)
- Event publishing through RabbitMQ
- Database operations for users and applications

#### Database Entities:

| Entity              | Purpose                                               |
| ------------------- | ----------------------------------------------------- |
| **Users**           | User account information and authentication data      |
| **UserApplication** | Container/application deployment configurations       |
| **ActivationCode**  | User account activation tokens                        |
| Additional tables   | logs, event-tracker, feature-flags _(in development)_ |

#### RabbitMQ Events:

The service publishes the following events:

- `USER_REGISTERED` - When a new user registers
- `USER_LOGGED_IN` - User login events
- `LOGOUT` - User logout events
- `DELETE` - Application deletion events
- `CREATE_CONTAINER` - Container creation requests
- `CONTAINER_CREATED` - Container creation confirmation

> **⚠️ Note:** Start/stop events are currently in development

---

### 2. Interceptor Service (Proxy)

> **Purpose:** Acts as a proxy to route incoming HTTP traffic to appropriate Docker containers.

#### Key Responsibilities:

- **Traffic Interception:** Monitors HTTP requests to `*.runmydocker-app.com` domains
- **URL Parsing:** Extracts application names from subdomain patterns
- **Application Validation:** Checks if requested applications exist in the database
- **Container Management:** Starts containers if needed before forwarding requests
- **Request Forwarding:** Routes validated requests to appropriate Docker containers
- **Response Handling:** Returns container responses back to clients

#### Background Jobs:

- Monitors application usage
- Stops unused applications after specified time
- Synchronizes data between database and Docker host

#### Traffic Flow Process:

```
1. Intercepts requests matching *.runmydocker-app.com pattern
2. Extracts application name from subdomain
3. Queries database to verify application exists
4. Checks container status and starts if necessary
5. Forwards request to running container
6. Returns response to original client
```

#### Technical Details:

- **No User Interaction:** Operates transparently without direct user interface
- **Database Access:** Direct PostgreSQL connection (shared with CRUD service)
- **Docker Integration:** Uses Docker SDK for container management
- **Standalone Operation:** Independent service with background job scheduling

---

## Components

![CRUD Service](./components.png)

## 🔄 Data Flow Diagrams

![create-flow](./create.png)
![start-stop-flow](./stopstart.png)
![interceptor-flow](./interceptor.png)

### Authentication Flow:

```
[Login Request] → [AuthController] → [Database Validation] → [JWT Generation] → [Response with JWT]
```

---

## 🔗 Service Communication

### Database Sharing:

- Both services connect to the same PostgreSQL database
- CRUD service handles write operations
- Interceptor service primarily performs read operations for validation

### Message Queue Usage:

- Only CRUD service uses RabbitMQ for event publishing
- Interceptor service operates independently without message queue dependency

### Container Management:

- CRUD service creates and manages container lifecycle
- Interceptor service starts containers on-demand for request routing
- Both services use Docker SDK for container operations

---

## Entities

<!-- photo -->

![Entities](./db.png)

## 🌐 Deployment Architecture

### Single Server Deployment:

- Both Spring Boot services run on the same server
- Shared PostgreSQL database instance
- Shared RabbitMQ instance
- Docker containers deployed on the same host
- Docker SDK used for container management

### Network Configuration:

- Interceptor service handles incoming traffic on `*.runmydocker-app.com`
- CRUD service provides REST API endpoints
- Internal communication via shared database

---

## 🔌 Key Integration Points

### External Dependencies:

| Component               | Purpose                                    |
| ----------------------- | ------------------------------------------ |
| **PostgreSQL Database** | Shared data store for both services        |
| **RabbitMQ**            | Event messaging system (CRUD service only) |
| **Docker Engine**       | Container runtime and management           |
| **DNS Configuration**   | For \*.runmydocker-app.com domain routing  |

### Internal Dependencies:

- Shared database schema between services
- Docker SDK integration for container management

---

## 🚧 Current Development Areas

> **In Progress:**
>
> - **Enhanced Events:** Start/stop events for containers
> - **Activation System:** New user activation workflow
> - **Telegram Logging:** Sentry-like logging integration
> - **Feature Flags:** Dynamic feature management system

---

```

```
