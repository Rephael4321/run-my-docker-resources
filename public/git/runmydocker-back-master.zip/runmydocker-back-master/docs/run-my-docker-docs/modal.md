classDiagram
direction BT
class activation_codes {
   timestamp created_at
   varchar(255) code
   timestamp expiration_time
   boolean used
   varchar(255) uuid_token
   bigint user_id
   bigint id
}
class global_feature_flags {
   timestamp created_at
   varchar(255) flag_name
   boolean is_enabled
   bigint id
}
class messages {
   varchar(255) action
   timestamp created_at
   boolean is_read
   uuid message_id
   jsonb payload
   varchar(255) type
   varchar(255) username
   uuid id
}
class request_logs {
   timestamp created_at
   varchar(255) client_ip
   varchar(255) method
   jsonb query_params
   jsonb request_body
   uuid request_id
   varchar(255) request_url
   jsonb response_body
   integer status_code
   boolean success
   timestamp timestamp
   varchar(255) username
   bigint id
}
class user_application_migration {
   varchar(255) application_name
   varchar(255) container_id
   integer container_port
   varchar(255) creation_error
   varchar(255) docker_image
   boolean is_running
   timestamp last_used
   boolean minikube_app
   integer port
   integer remaining_time
   varchar(255) status
   varchar(255) username
   timestamp created_at
   uuid id
}
class user_application_to_migrate {
   varchar(255) app_name
   varchar(255) docker_image
   integer mapping_port
   varchar(255) username
   boolean is_migrated
   varchar(255) failure_reason
   uuid id
}
class user_applications {
   timestamp created_at
   varchar(255) application_name
   varchar(255) container_id
   integer container_port
   varchar(255) creation_error
   varchar(255) docker_image
   boolean is_running
   timestamp last_used
   boolean minikube_app
   integer port
   integer remaining_time
   varchar(255) status
   varchar(255) username
   bigint user_id
   timestamp old_created_at
   bigint id
}
class user_feature_flags {
   timestamp created_at
   varchar(255) flag_name
   boolean is_enabled
   bigint user_id
   bigint id
}
class users {
   timestamp created_at
   varchar(60) first_name
   boolean is_activated
   varchar(60) last_name
   varchar(255) password
   varchar(255) phone
   varchar(255) provider_id
   boolean registration_completed
   varchar(255) role
   varchar(255) username
   varchar(255) old_created_at
   bigint id
}

activation_codes  -->  users : user_id:id
messages  -->  messages : message_id:id
user_applications  -->  users : user_id:id
user_feature_flags  -->  users : user_id:id
