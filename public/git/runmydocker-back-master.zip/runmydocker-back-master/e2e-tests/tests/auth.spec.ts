import {beforeAll, describe, expect, it} from "vitest";

// @ts-ignore
import {api} from "../utils/auth.util";
// @ts-ignore
import {ApiResponse, LoginDto} from "../types";

import AxiosXHR = Axios.AxiosXHR;
// @ts-ignore
import {getFixture} from "../utils/fixture.util";
// @ts-ignore
import {clearDB, seedDB} from "../utils/seed";


describe("Tests for Auth requests", () => {
    beforeAll(async () => {
        await seedDB();
    });

    beforeAll(async () => {
        await clearDB();
    });
    describe('Tests For Login', () => {
        let successLoginResponse: AxiosXHR<ApiResponse<{ jwtToken: string }>>;

        beforeAll(async () => {
            const loginDto: LoginDto = {username: 'natanger97@gmail.com', password: 'password'};
            const fixture: { 'login': LoginDto } = await getFixture('user.json');
            const loginData= fixture.login

            successLoginResponse = await api.post<ApiResponse<{ jwtToken: string }>>('auth/login', loginData);
        });

        it('should return 200 success for login', () => {
            expect(successLoginResponse.status).toBeGreaterThanOrEqual(200);
            expect(successLoginResponse.data.success).toBe(true);
        });

        it('should return jwt token', () => expect(successLoginResponse.data.data?.jwtToken).toBeDefined());

        it('should return 401', () => {
            const failedLoginDto: LoginDto = {username: 'test@gmail.com', password: 'password'};
            api.post<ApiResponse<{ jwtToken: string }>>('auth/login', failedLoginDto).catch((error) => {
                expect(error.response.status).toBe(401);
            });

        });

    });

});