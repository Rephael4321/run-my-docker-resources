import {beforeAll, describe, it, expect} from "vitest";
import {api, loginAndGetToken, ApiResponse} from "../utils/auth.util";
import {UserOutDto} from "../types";
import AxiosXHR = Axios.AxiosXHR;



describe("Tests for Users requests", () => {
    let token: string;
    beforeAll(async () => {
        token = await loginAndGetToken();
    });


    describe('Test for /getUser', () => {
        let response: AxiosXHR<ApiResponse<UserOutDto>>;
        beforeAll(async () => {
            const headers = {headers: {Authorization: `Bearer ${token}`}};
            response = await api.get<ApiResponse<UserOutDto>>('users/getUser', headers);
        })

        it('should return 200', () => expect(response.status).toBeGreaterThanOrEqual(200));

        it('should return success true', () => expect(response.data.success).toBe(true));

        it('should return user data', () => {
            const data = response.data.data as UserOutDto;
            expect(data).toBeDefined();
            const responseUserKeys = Object.keys(data as UserOutDto);
            responseUserKeys.forEach(key => {
                expect(key in data).toBe(true);
            })
        });
    });

});