import {describe, it, expect, beforeAll} from "vitest";
import {api, getToken} from "../utils/auth.util";
// @ts-ignore
import {getFixture} from "../utils/fixture.util";
import {LoginDto} from "../types";

describe('Tests for User-Applications requests', () => {
    const token = getToken()
    beforeAll(async () => {
        const fixture: { 'login': LoginDto } = await getFixture('user.json');

    });
    describe('Tests for get user applications by token', () => {
        it('should return 200', () => {
            expect(true).toBe(true);
        });
        it('should return success true', () => {
            expect(true).toBe(true);
        });
        it('should return user application data', () => {
            expect(true).toBe(true);
        });
    });

});