export type LoginDto = {
    username: string,
    password: string
}

export type ApiResponse<T> = {
    code?: number,
    data?: T,
    extraInfo?: Record<string, any>
    message?: string
    success?: boolean
}

export type UserOutDto = {
    id: number,
    firstName: string,
    lastName: string,
    phone: string,
    username: string,
    isActivated: boolean,
}