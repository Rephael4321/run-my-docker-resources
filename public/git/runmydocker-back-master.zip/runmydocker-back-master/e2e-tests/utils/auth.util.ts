import axios from "axios";


export const api = axios.create({
    baseURL: 'http://localhost:8081/api',
    timeout: 70000,
    headers: {
        'Content-Type': 'application/json',
    }
});

api.interceptors.response.use(response => response, error => {
    console.error("API error", error.response?.data || error.message)
    return Promise.reject(error)
})
export type LoginDto = {
    username: string,
    password: string
};

export type ApiResponse<T> = {
    code?: number,
    data?: T,
    extraInfo?: Record<string, any>,
    message?: string,
    success?: boolean
};

let jwtToken: string;

export const loginAndGetToken = async (): Promise<string> => {
    const loginDto: LoginDto = { username: 'natanger97@gmail.com', password: 'password' };
    const { data } = await api.post<ApiResponse<{ jwtToken: string }>>('/auth/login', loginDto);
    jwtToken = data.data?.jwtToken || '';
    return jwtToken;
};

export const getToken = (): string => jwtToken;