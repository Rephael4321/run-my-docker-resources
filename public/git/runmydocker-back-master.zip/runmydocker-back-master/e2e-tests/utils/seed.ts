import {api} from "./auth.util";

export async function seedDB() {
    console.log('Seeding DB')
    await api.post('seed/tests/users')
}

export async function clearDB() {
    console.log('Clearing DB')
    await api.delete('seed/tests/users')
}