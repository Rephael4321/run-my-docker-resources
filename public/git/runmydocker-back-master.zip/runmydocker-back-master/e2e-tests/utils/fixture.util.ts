import {resolve} from 'path';
import {readFile} from 'fs/promises';

const path = resolve(__dirname, '../fixture');



export const getFixture = async (fileName: string) => {
    console.log(path + `/${fileName}`);
    const fileContent = await readFile(path + `/${fileName}`, 'utf-8');
    return JSON.parse(fileContent);
};

