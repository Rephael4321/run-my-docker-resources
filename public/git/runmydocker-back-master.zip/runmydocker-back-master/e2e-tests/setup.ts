import {afterAll, beforeAll} from "vitest";
import {clearDB, seedDB} from "./utils/seed";
import {a} from "vitest/dist/chunks/suite.BJU7kdY9";

beforeAll(async () => {
    await clearDB();
    await seedDB();
});

afterAll(async () => await clearDB());