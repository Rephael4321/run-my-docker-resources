//package com.codingbc.runmydocker.services;
//
//import com.codingbc.runmydocker.RunmydockerApplication;
//import com.codingbc.runmydocker.integrations.DatabaseUtil;
//import org.junit.After;
//import org.junit.Before;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.test.context.ActiveProfiles;
//import org.springframework.test.context.junit.jupiter.SpringJUnitConfig;
//import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
//import org.springframework.test.context.web.WebAppConfiguration;
//
//@SpringBootTest(classes = {RunmydockerApplication.class})
//@ActiveProfiles({"test"})
//@WebAppConfiguration
//@RunWith(SpringJUnit4ClassRunner.class)
//@SpringJUnitConfig
//
//public class UserApplicationServiceIntegrationTest {
//
//  @Autowired
//  private DatabaseUtil databaseSeederUtil;
//
//  @Before
//  public void setUp() throws Exception {
//    System.out.println("Before class");
//    databaseSeederUtil.seedData();
//  }
//
//  @After
//  public void tearDown() throws Exception {
//  }
//
//  @Test
//  public void testCreate() {
//    System.out.println("Test create");
//  }
//}