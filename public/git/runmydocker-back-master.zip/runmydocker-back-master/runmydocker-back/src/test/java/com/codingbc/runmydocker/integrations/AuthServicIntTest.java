package com.codingbc.runmydocker.integrations;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mockStatic;

import com.codingbc.runmydocker.builders.AuthenticationRequestBuilder;
import com.codingbc.runmydocker.builders.RegularUserCreateDTOBuilder;
import com.codingbc.runmydocker.dto.AppUser.RegularUserCreateDTO;
import com.codingbc.runmydocker.dto.AppUser.UserOutDTO;
import com.codingbc.runmydocker.dto.auth.AuthenticationRequest;
import com.codingbc.runmydocker.dto.auth.CompleteRegistrationRequest;
import com.codingbc.runmydocker.dto.auth.RegistrationResponse;
import com.codingbc.runmydocker.events.EventPublisher;
import com.codingbc.runmydocker.exceptions.ConflictError;
import com.codingbc.runmydocker.exceptions.GeneralError;
import com.codingbc.runmydocker.models.ActivationCode;
import com.codingbc.runmydocker.models.User;
import com.codingbc.runmydocker.repositories.ActivationCodeRepository;
import com.codingbc.runmydocker.services.ActivationCodeService;
import com.codingbc.runmydocker.services.AuthService;
import com.codingbc.runmydocker.services.sms.SmsService;
import java.util.List;
import java.util.UUID;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.transaction.annotation.Transactional;

@SpringBootTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@ActiveProfiles({"test"})
@Transactional
public class AuthServicIntTest {

  public static final String TEST_ID = UUID.randomUUID().toString();

  @Autowired
  private ActivationCodeRepository activationCodeRepository;

  @Autowired
  private DatabaseUtil databaseSeederUtil;

  @Mock
  private ActivationCodeService activationCodeService;
  @Mock
  private SmsService smsService;

  @Autowired
  private AuthService underTest;
  private MockedStatic<EventPublisher> eventPublisherMockedStatic;

  @BeforeEach
  void setUp() {
    databaseSeederUtil.cleanDatabase();
    eventPublisherMockedStatic = mockStatic(EventPublisher.class);
    databaseSeederUtil.seedData(TEST_ID);
  }

  @AfterEach
  void tearDown() {
    eventPublisherMockedStatic.close();
    databaseSeederUtil.cleanDatabase();
  }

  @DisplayName("Register a new user should return a created")
  @Test
  void registerUser_withValidData_ShouldSuccess() {
    // Arrange
    RegularUserCreateDTO dto =
        RegularUserCreateDTOBuilder.aRegularUserCreateDTO().withUsername("user@gmail.com")
            .withPassword("password")
            .withLastName("last")
            .withFirstName("first")
            .withPhone("1234567890")
            .build();

    RegistrationResponse registerResponse = underTest.register(dto);
    User createdUserFromDB = databaseSeederUtil.getUser("user");

    // Assert
    eventPublisherMockedStatic.verify(
        () -> EventPublisher.publishUserRegisteredEvent(any(User.class)));
    assertEquals("user@gmail.com", createdUserFromDB.getUsername());
    assertEquals(createdUserFromDB.getLastActivationCode().getUuidToken(),
        registerResponse.getUuid());
    assertTrue(createdUserFromDB.isRegistrationCompleted());
    assertNotNull(createdUserFromDB.getLastActivationCode());

  }

  @DisplayName("Register a new user with existing username should throw EntityConflicError")
  @Test
  void registerUser_withExistingUsername_ShouldThrowEntityConflicError() {
    // Arrange
    RegularUserCreateDTO dto =
        RegularUserCreateDTOBuilder.aRegularUserCreateDTO().withUsername(TEST_ID + "@gmail.com")
            .withPassword("password")
            .withLastName("last")
            .withFirstName("first")
            .withPhone("1234567890")
            .build();

    // Act
    assertThrows(ConflictError.class, () -> underTest.register(dto));

  }

  @Test
  @DisplayName("Login with activated user should return a token")
  void authenticate_activatedUser_ShouldSuccess() {
    RegularUserCreateDTO dto =
        RegularUserCreateDTOBuilder.aRegularUserCreateDTO().withUsername("user@gmail.com")
            .withPassword("password")
            .withLastName("last")
            .withFirstName("first")
            .withPhone("1234567890")
            .build();
    underTest.register(dto);
    User user = databaseSeederUtil.getUser("user");
    user.setActivated(true);
    AuthenticationRequest request =
        AuthenticationRequestBuilder.anAuthenticationRequest()
            .withUsername("user@gmail.com")
            .withPassword("password")
            .build();

    String token = underTest.authenticate(request);
    assertNotNull(token);
  }

  @Test
  @DisplayName("Login with unactivated user should throw NotAnActivateUserError")
  void authenticate_UnactivatedUser_shouldThrowNotAnActivateUserError() {
    RegularUserCreateDTO dto =
        RegularUserCreateDTOBuilder.aRegularUserCreateDTO().withUsername("user@gmail.com")
            .withPassword("password")
            .withLastName("last")
            .withFirstName("first")
            .withPhone("1234567890")
            .build();
    underTest.register(dto);

    AuthenticationRequest request =
        AuthenticationRequestBuilder.anAuthenticationRequest()
            .withUsername("user@gmail.com")
            .withPassword("password")
            .build();

    Exception exception = assertThrows(Exception.class, () -> underTest.authenticate(request));
    assertEquals("User is not activate", exception.getMessage());
  }

  @Test
  @DisplayName("Login with bad credentials should throw BadCredentialsError")
  void authenticate_BadCredentials_shouldThrowBadCredentialsError() {
    RegularUserCreateDTO dto =
        RegularUserCreateDTOBuilder.aRegularUserCreateDTO().withUsername("user@gmail.com")
            .withPassword("password")
            .withLastName("last")
            .withFirstName("first")
            .withPhone("1234567890")
            .build();
    underTest.register(dto);
    User user = databaseSeederUtil.getUser("user");
    user.setActivated(true);
    AuthenticationRequest request =
        AuthenticationRequestBuilder.anAuthenticationRequest()
            .withUsername("user@gmail.com").withPassword("wrongpassword").build();

    BadCredentialsException exception = assertThrows(BadCredentialsException.class,
        () -> underTest.authenticate(request));
    assertEquals("Bad credentials", exception.getMessage());
  }


  @Test
  @DisplayName("Resend activation with valid username should return ok response")
  void resendActicationCode_withValidUsername_ShouldSuccess() {
    List<ActivationCode> currentActivationCode =
        databaseSeederUtil.getUser(TEST_ID).getActivationCodes();

    RegistrationResponse registrationResponse = underTest.resendActicationCode(
        TEST_ID + "@gmail.com");

    ActivationCode createdActivationCode = activationCodeRepository.findByUuidToken(
        registrationResponse.getUuid());

    assertEquals(createdActivationCode.getUuidToken(), registrationResponse.getUuid());

  }

  @Test
  @DisplayName("Resend activation with invalid username should throw EntityNotFoundError")
  void resendActicationCode_withInvalidUsername_ShouldThrowEntityNotFoundError() {
    assertThrows(Exception.class, () -> underTest.resendActicationCode("invalid-username"));
  }

  @Test
  @DisplayName("Complate registration with valid data should return a user and uuid")
  void completeRegistration_withValidData_ShouldSuccess() {
    UserOutDTO userOutDTO = underTest.register(
        RegularUserCreateDTOBuilder.aRegularUserCreateDTO().withUsername("user" + "@gmail.com")
            .withPassword("password")
            .withLastName("last")
            .withFirstName("first")
            .withPhone("1234567890")
            .build()).getUser();
    User user = databaseSeederUtil.getUser("user");

    CompleteRegistrationRequest request = new CompleteRegistrationRequest();
    request.setId(userOutDTO.getId());
    request.setPhone("1234567890");
    request.setFirstName("first");
    request.setLastName("last");

    RegistrationResponse registrationResponse = underTest.completeUserRegistration(user.getId(),
        request);

    ActivationCode activationCode = activationCodeRepository.findByUuidToken(
        registrationResponse.getUuid());
    User updatedUser = databaseSeederUtil.getUser("user");
    assertEquals(user.getId(), registrationResponse.getUser().getId());
    assertEquals(activationCode.getUuidToken(), registrationResponse.getUuid());
    assertTrue(updatedUser.isRegistrationCompleted());
    assertEquals(request.getPhone(), updatedUser.getPhone());
    assertEquals(request.getFirstName(), updatedUser.getFirstName());
    assertEquals(request.getLastName(), updatedUser.getLastName());
    eventPublisherMockedStatic.verify(
        () -> EventPublisher.publishUserRegisteredEvent(any(User.class)));
  }


  @Test
  @DisplayName("Complate registration with unexisting user should throw EntityNotFoundError")
  void completeRegistration_withUnexistingUser_ShouldThrowEntityNotFoundError() {
    CompleteRegistrationRequest request = new CompleteRegistrationRequest();
    request.setId(100L);
    request.setPhone("1234567890");
    request.setFirstName("first");
    request.setLastName("last");

    assertThrows(Exception.class, () -> underTest.completeUserRegistration(100L, request));
  }


  @Test
  @DisplayName("Complate registration with invalid user id should throw GeneralError")
  void completeRegistration_withInvalidUserId_ShouldThrowGeneralError() {
    CompleteRegistrationRequest request = new CompleteRegistrationRequest();
    request.setId(100L);
    request.setPhone("1234567890");
    request.setFirstName("first");
    request.setLastName("last");

    assertThrows(GeneralError.class, () -> underTest.completeUserRegistration(1002L, request));
  }

}
