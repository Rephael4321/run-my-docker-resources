package com.codingbc.runmydocker.integrations;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.codingbc.runmydocker.dto.UserApplication.ApplicationActionRequest;
import com.codingbc.runmydocker.dto.UserApplication.ExecutionResponse;
import com.codingbc.runmydocker.dto.UserApplication.UserApplicationCreateDTO;
import com.codingbc.runmydocker.enums.AppStatus;
import com.codingbc.runmydocker.enums.ContainerCreationStatus;
import com.codingbc.runmydocker.events.EventPublisher;
import com.codingbc.runmydocker.exceptions.BadRequest;
import com.codingbc.runmydocker.exceptions.ConflictError;
import com.codingbc.runmydocker.exceptions.NotFoundError;
import com.codingbc.runmydocker.models.User;
import com.codingbc.runmydocker.models.UserApplication;
import com.codingbc.runmydocker.services.DockerService;
import com.codingbc.runmydocker.services.UserApplicationService;
import com.github.dockerjava.api.command.InspectContainerResponse;
import com.github.dockerjava.api.exception.NotFoundException;
import java.util.Date;
import java.util.Optional;
import java.util.UUID;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.transaction.annotation.Transactional;

@SpringBootTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@ActiveProfiles({"test"})
@Transactional
class UserApplicationServiceIntTest {

  public static final String TEST_ID = UUID.randomUUID().toString();

  @Autowired
  private DatabaseUtil databaseSeederUtil;

  @Autowired
  private UserApplicationService underTest;
  MockedStatic<EventPublisher> eventPublisherMockedStatic;
  @MockBean
  private DockerService dockerService;

  @BeforeEach
  void setUp() {
    databaseSeederUtil.cleanDatabase();
    eventPublisherMockedStatic = mockStatic(EventPublisher.class);
    databaseSeederUtil.seedData(TEST_ID);
  }

  @AfterEach
  void tearDown() {
    eventPublisherMockedStatic.close();
    databaseSeederUtil.cleanDatabase();
  }

  @Test
  // @Transactional
  @DisplayName("Create app with valid input should success")
  void createApp_withValidInput_shouldSuccess() {
    User user = databaseSeederUtil.getUser(TEST_ID);
    UserApplicationCreateDTO createAppDTO = new UserApplicationCreateDTO();
    createAppDTO.setDockerImage("natanger97/web-scraping-chatbot");
    createAppDTO.setAppName("test-app" + UUID.randomUUID().toString().substring(0, 5));
    createAppDTO.setContainerPort(8080);
    createAppDTO.setUsername(user.getUsername());

    when(dockerService.isImgOnDockerHub(createAppDTO.getDockerImage())).thenReturn(true);
    UserApplication userApplication = underTest.create(createAppDTO);

    eventPublisherMockedStatic.verify(
        () -> EventPublisher.publishCreateContainerEvent(userApplication));

    assertNotNull(userApplication);
    assertEquals(createAppDTO.getAppName(), userApplication.getAppName());
    assertEquals(createAppDTO.getDockerImage(), userApplication.getDockerImage());
    assertEquals(createAppDTO.getContainerPort(), userApplication.getContainerPort());
  }

  @Test
  // @Transactional
  @DisplayName("Create app with exists name should throw ConflictError")
  void createApp_WithExistsName_shouldThrowConflictError() {
    User user = databaseSeederUtil.getUser(TEST_ID);
    UserApplicationCreateDTO createAppDTO = new UserApplicationCreateDTO();
    createAppDTO.setDockerImage("natanger97/web-scraping-chatbot");
    createAppDTO.setAppName(TEST_ID);
    createAppDTO.setContainerPort(8080);
    createAppDTO.setUsername(user.getUsername());

    assertThrows(ConflictError.class, () -> underTest.create(createAppDTO));

  }

  @DisplayName("Create app with invalid app name should throw BadRequest")
  @ParameterizedTest(name = "Create app with invalid app name {0} should throw BadRequest")
  @ValueSource(strings = {"app_name**", "app_name**2", "app_name**3"})
    // @Transactional
  void createApp_WithInvliadAppName_shouldThrowBadRequest(String appName) {
    User user = databaseSeederUtil.getUser(TEST_ID);
    UserApplicationCreateDTO createAppDTO = new UserApplicationCreateDTO();
    createAppDTO.setDockerImage("natanger97/web-scraping-chatbot3");
    createAppDTO.setAppName(appName);
    createAppDTO.setContainerPort(8080);
    createAppDTO.setUsername(user.getUsername());

    assertThrows(BadRequest.class, () -> underTest.create(createAppDTO));

  }

  @DisplayName("Create app with unknown docker image should throw NotFoundError")
  @ParameterizedTest(name = "Create app with unknown docker image {0} should throw NotFoundError")
  @ValueSource(strings = {"natanger97/web-scraping-chatbot3", "natanger97/web-scraping-chatbot4",
      "natanger97/web-scraping-chatbot5"})
  void createApp_WithUnknownDockerImage_shouldThrowNotFoundError(String dockerImage) {
    User user = databaseSeederUtil.getUser(TEST_ID);
    UserApplicationCreateDTO createAppDTO = new UserApplicationCreateDTO();
    createAppDTO.setDockerImage(dockerImage);
    createAppDTO.setAppName("valid-name");
    createAppDTO.setContainerPort(8080);
    createAppDTO.setUsername(user.getUsername());

    assertThrows(NotFoundError.class, () -> underTest.create(createAppDTO));

  }

  @DisplayName("Start app with valid input should success")
  @Test
  void startApp_withValidInput_shouldSuccess() {
    // arrange
    UserApplication application = databaseSeederUtil.getApplication(TEST_ID);
    Date prevLastUsed = application.getLastUsed();
    User user = databaseSeederUtil.getUser(TEST_ID);
    ApplicationActionRequest actionRequest = new ApplicationActionRequest();
    actionRequest.setUsername(user.getUsername());
    actionRequest.setAppName(application.getAppName());
    actionRequest.setAppId(application.getId());

    application.setStatus(ContainerCreationStatus.CREATED);

    InspectContainerResponse inspectContainerResponse = Mockito.mock(
        InspectContainerResponse.class);
    InspectContainerResponse.ContainerState containerState = mock(
        InspectContainerResponse.ContainerState.class);

    // when
    when(dockerService.isContainerExists(application.getAppName())).thenReturn(Optional.of(true));
    when(dockerService.inspectDocker(application.getAppName())).thenReturn(
        inspectContainerResponse);
    when(inspectContainerResponse.getState()).thenReturn(containerState);
    when(containerState.getStatus()).thenReturn("exited");

    ExecutionResponse executionResponse = underTest.startApp(actionRequest);

    var statedAppRecord = databaseSeederUtil.getApplication(TEST_ID);
    assertEquals(AppStatus.STARTED, executionResponse.getAppStatus());
    assertNotEquals(statedAppRecord.getLastUsed(), prevLastUsed);

  }

  @DisplayName("Start app with correct id but wrong app name should throw NotFound")
  @ParameterizedTest(name = "Start app with correct id but wrong app name {0} should throw NotFound")
  @ValueSource(strings = {"app-name"})
  void startApp_WithCorrectIdAndWrongAppNam_shouldThrowNotFound(String appName) {
    UserApplication application = databaseSeederUtil.getApplication(TEST_ID);
    User user = databaseSeederUtil.getUser(TEST_ID);
    ApplicationActionRequest actionRequest = new ApplicationActionRequest();
    actionRequest.setAppName(appName);
    actionRequest.setAppId(application.getId());
    actionRequest.setUsername(user.getUsername());

    assertThrows(NotFoundError.class, () -> underTest.startApp(actionRequest));

  }

  @DisplayName("Start app with wrong id  but correct app name  should throw NotFound")
  @ParameterizedTest(name = "Start app with wrong id {0} but correct app name  should throw NotFound")
  @ValueSource(longs = {457894, 954, 32479435})
  void startApp_WithCorrectNameAndWrongId_shouldThrowNotFound(long appId) {
    UserApplication application = databaseSeederUtil.getApplication(TEST_ID);
    User user = databaseSeederUtil.getUser(TEST_ID);
    ApplicationActionRequest actionRequest = new ApplicationActionRequest();
    actionRequest.setAppId(appId);
    actionRequest.setAppName(application.getAppName());
    actionRequest.setUsername(user.getUsername());

    assertThrows(NotFoundError.class, () -> underTest.startApp(actionRequest));
  }

  @DisplayName("Start app with valid data but with no reamining time should throw BadRequest")
  @ParameterizedTest(name = "App with reaming time {0} should throw BadRequest")
  @ValueSource(ints = {0, -1, -2, -3, -20})
  void startApp_withValidDataButWithNoReaminingTime_shouldThrowBadRequest(int remainingTime) {
    // arrange
    UserApplication application = databaseSeederUtil.getApplication(TEST_ID);
    User user = databaseSeederUtil.getUser(TEST_ID);
    application.setRemainingTime(remainingTime);
    databaseSeederUtil.update(application);
    ApplicationActionRequest actionRequest = new ApplicationActionRequest();
    actionRequest.setAppId(application.getId());
    actionRequest.setAppName(application.getAppName());
    actionRequest.setUsername(user.getUsername());

    assertThrows(BadRequest.class, () -> underTest.startApp(actionRequest));

  }

  @Test
  @DisplayName("Start app when app marked as running and contaier is running should throw BadRequest")
  void startApp_AlreadyRunning_shouldThrowBadRequest() {
    // arrange
    UserApplication application = databaseSeederUtil.getApplication(TEST_ID);
    application.setRunning(true);
    application.setStatus(ContainerCreationStatus.CREATED);
    databaseSeederUtil.update(application);
    User user = databaseSeederUtil.getUser(TEST_ID);
    ApplicationActionRequest actionRequest = new ApplicationActionRequest();
    actionRequest.setAppId(application.getId());
    actionRequest.setAppName(application.getAppName());
    actionRequest.setUsername(user.getUsername());

    // act and assert
    BadRequest badRequest = assertThrows(BadRequest.class, () -> underTest.startApp(actionRequest));
    assertEquals("Application is already running", badRequest.getMessage());

  }

  @Test
  @DisplayName("Start app when app marked as not running but container is running should throw BadRequest")
  void startApp_appMarkedNotRunningButContainerRunning_shouldThrowBadRequest() {
    // arrange
    UserApplication application = databaseSeederUtil.getApplication(TEST_ID);
    application.setStatus(ContainerCreationStatus.CREATED);
    User user = databaseSeederUtil.getUser(TEST_ID);
    ApplicationActionRequest actionRequest = new ApplicationActionRequest();
    actionRequest.setAppId(application.getId());
    actionRequest.setAppName(application.getAppName());
    actionRequest.setUsername(user.getUsername());

    InspectContainerResponse inspectContainerResponse = Mockito.mock(
        InspectContainerResponse.class);
    InspectContainerResponse.ContainerState containerState = mock(
        InspectContainerResponse.ContainerState.class);

    // when
    when(dockerService.isContainerExists(application.getAppName())).thenReturn(Optional.of(true));
    when(dockerService.inspectDocker(application.getAppName())).thenReturn(
        inspectContainerResponse);
    when(inspectContainerResponse.getState()).thenReturn(containerState);
    when(containerState.getStatus()).thenReturn("running");

    // act and assert
    BadRequest badRequest = assertThrows(BadRequest.class, () -> underTest.startApp(actionRequest));
    assertEquals("Container success is not exited", badRequest.getMessage());
  }

  @DisplayName("Start app when app with success not created should throw BadRequest")
  @Test
  void startApp_appWithStatusNotCreated_shouldThrowBadRequest() {
    // arrange
    UserApplication application = databaseSeederUtil.getApplication(TEST_ID);
    application.setStatus(ContainerCreationStatus.FAILED);
    User user = databaseSeederUtil.getUser(TEST_ID);
    ApplicationActionRequest actionRequest = new ApplicationActionRequest();
    actionRequest.setAppId(application.getId());
    actionRequest.setAppName(application.getAppName());
    actionRequest.setUsername(user.getUsername());

    // act and assert
    BadRequest badRequest = assertThrows(BadRequest.class, () -> underTest.startApp(actionRequest));
    assertEquals("Application success is not created", badRequest.getMessage());
  }

  @DisplayName("Stop app with valid input should success")
  @Test
  void stopApp_withValidInput_shouldSuccess() {
    // arrange
    UserApplication application = databaseSeederUtil.getApplication(TEST_ID);
    Date prevLastUsed = application.getLastUsed();
    User user = databaseSeederUtil.getUser(TEST_ID);
    ApplicationActionRequest actionRequest = new ApplicationActionRequest();
    actionRequest.setUsername(user.getUsername());
    actionRequest.setAppName(application.getAppName());
    actionRequest.setAppId(application.getId());
    application.setStatus(ContainerCreationStatus.CREATED);
    application.setRunning(true);
    InspectContainerResponse inspectContainerResponse = Mockito.mock(
        InspectContainerResponse.class);
    InspectContainerResponse.ContainerState containerState = mock(
        InspectContainerResponse.ContainerState.class);

    // when
    when(dockerService.isContainerExists(application.getAppName())).thenReturn(Optional.of(true));
    when(dockerService.inspectDocker(application.getAppName())).thenReturn(
        inspectContainerResponse);
    when(inspectContainerResponse.getState()).thenReturn(containerState);
    when(containerState.getStatus()).thenReturn("running");

    ExecutionResponse executionResponse = underTest.stopApp(actionRequest);

    var statedAppRecord = databaseSeederUtil.getApplication(TEST_ID);
    assertEquals(AppStatus.STOPPED, executionResponse.getAppStatus());
    assertNotEquals(statedAppRecord.getLastUsed(), prevLastUsed);
    assertFalse(statedAppRecord.isRunning());

  }

  @DisplayName("Stop app with correct id but wrong app name should throw NotFound")
  @ParameterizedTest(name = "Start app with correct id but wrong app name {0} should throw NotFound")
  @ValueSource(strings = {"app-name"})
  void stopApp_WithCorrectIdAndWrongAppName_shouldThrowNotFound(String appName) {
    UserApplication application = databaseSeederUtil.getApplication(TEST_ID);
    User user = databaseSeederUtil.getUser(TEST_ID);
    ApplicationActionRequest actionRequest = new ApplicationActionRequest();
    actionRequest.setAppName(appName);
    actionRequest.setAppId(application.getId());
    actionRequest.setUsername(user.getUsername());

    assertThrows(NotFoundError.class, () -> underTest.stopApp(actionRequest));

  }


  @DisplayName("Stop app with wrong id  but correct app name  should throw NotFound")
  @ParameterizedTest(name = "Stop app with wrong id {0} but correct app name  should throw NotFound")
  @ValueSource(longs = {457894, 954, 32479435})
  void stopApp_WithCorrectNameAndWrongId_shouldThrowNotFound(long appId) {
    UserApplication application = databaseSeederUtil.getApplication(TEST_ID);
    User user = databaseSeederUtil.getUser(TEST_ID);
    ApplicationActionRequest actionRequest = new ApplicationActionRequest();
    actionRequest.setAppId(appId);
    actionRequest.setAppName(application.getAppName());
    actionRequest.setUsername(user.getUsername());

    assertThrows(NotFoundError.class, () -> underTest.startApp(actionRequest));
  }


  @Test
  @DisplayName("Stop app when app marked as stopped should throw BadRequest")
  void stopApp_AlreadyStopped_shouldThrowBadRequest() {
    // arrange
    UserApplication application = databaseSeederUtil.getApplication(TEST_ID);
    application.setRunning(false);
    application.setStatus(ContainerCreationStatus.CREATED);
    databaseSeederUtil.update(application);
    User user = databaseSeederUtil.getUser(TEST_ID);

    ApplicationActionRequest actionRequest = new ApplicationActionRequest();
    actionRequest.setAppId(application.getId());
    actionRequest.setAppName(application.getAppName());
    actionRequest.setUsername(user.getUsername());

    // act and assert
    BadRequest badRequest = assertThrows(BadRequest.class, () -> underTest.stopApp(actionRequest));
    assertEquals("Application is not running", badRequest.getMessage());

  }

  @Test
  @DisplayName("Stop app when app marked as running but container is stopped should throw BadRequest")
  void stopApp_appMarkedRunningButContainerNotRunning_shouldThrowBadRequest() {
    // arrange
    UserApplication application = databaseSeederUtil.getApplication(TEST_ID);
    application.setStatus(ContainerCreationStatus.CREATED);
    application.setRunning(true);
    databaseSeederUtil.update(application);
    User user = databaseSeederUtil.getUser(TEST_ID);
    ApplicationActionRequest actionRequest = new ApplicationActionRequest();
    actionRequest.setAppId(application.getId());
    actionRequest.setAppName(application.getAppName());
    actionRequest.setUsername(user.getUsername());

    InspectContainerResponse inspectContainerResponse = Mockito.mock(
        InspectContainerResponse.class);
    InspectContainerResponse.ContainerState containerState = mock(
        InspectContainerResponse.ContainerState.class);

    // when
    when(dockerService.isContainerExists(application.getAppName())).thenReturn(Optional.of(true));
    when(dockerService.inspectDocker(application.getAppName())).thenReturn(
        inspectContainerResponse);
    when(inspectContainerResponse.getState()).thenReturn(containerState);
    when(containerState.getStatus()).thenReturn("exited");

    // act and assert
    BadRequest badRequest = assertThrows(BadRequest.class, () -> underTest.stopApp(actionRequest));
    assertEquals("Container success is not running", badRequest.getMessage());
  }


  @DisplayName("Start and Stop app when app with success not created should throw BadRequest")
  @Test
  void startStopApp_appWithStatusNotCreated_shouldThrowBadRequest() {
    // arrange
    UserApplication application = databaseSeederUtil.getApplication(TEST_ID);
    application.setStatus(ContainerCreationStatus.FAILED);
    User user = databaseSeederUtil.getUser(TEST_ID);
    ApplicationActionRequest actionRequest = new ApplicationActionRequest();
    actionRequest.setAppId(application.getId());
    actionRequest.setAppName(application.getAppName());
    actionRequest.setUsername(user.getUsername());

    assertBadRequestForAction(() -> underTest.startApp(actionRequest),
        "Application success is not created");

    assertBadRequestForAction(() -> underTest.stopApp(actionRequest),
        "Application success is not created");
  }

  private void assertBadRequestForAction(Runnable action, String expectedMessage) {
    BadRequest badRequest = assertThrows(BadRequest.class, action::run);
    assertEquals(expectedMessage, badRequest.getMessage());
  }


  @Test
  @DisplayName("Delete app with valid input and failed success should success")
  void deleteApp_AppWithStatusOfFailed_ShouldSuccess() {
    // arrange
    UserApplication application = databaseSeederUtil.getApplication(TEST_ID);
    application.setStatus(ContainerCreationStatus.FAILED);
    User user = databaseSeederUtil.getUser(TEST_ID);
    ApplicationActionRequest actionRequest = new ApplicationActionRequest();
    actionRequest.setUsername(user.getUsername());
    actionRequest.setAppName(application.getAppName());
    actionRequest.setAppId(application.getId());

    // act
    ExecutionResponse executionResponse = underTest.deleteUserApplication(actionRequest);

    // assert
    assertEquals(AppStatus.DELETED, executionResponse.getAppStatus());
    assertEquals("Application deleted successfully", executionResponse.getMessage());
  }

  @Test
  @DisplayName("Delete app with valid input and created success should success")
  void deleteApp_AppWithStatusOfCreated_ShouldSuccess() {
    // arrange
    UserApplication application = databaseSeederUtil.getApplication(TEST_ID);
    application.setStatus(ContainerCreationStatus.CREATED);
    User user = databaseSeederUtil.getUser(TEST_ID);
    ApplicationActionRequest actionRequest = new ApplicationActionRequest();
    actionRequest.setUsername(user.getUsername());
    actionRequest.setAppName(application.getAppName());
    actionRequest.setAppId(application.getId());

    InspectContainerResponse inspectContainerResponse = Mockito.mock(
        InspectContainerResponse.class);
    InspectContainerResponse.ContainerState containerState = mock(
        InspectContainerResponse.ContainerState.class);

    // when
    when(dockerService.isContainerExists(application.getAppName())).thenReturn(Optional.of(true));
    when(dockerService.inspectDocker(application.getAppName())).thenReturn(
        inspectContainerResponse);
    when(inspectContainerResponse.getState()).thenReturn(containerState);
    when(containerState.getStatus()).thenReturn("exited");

    // act
    ExecutionResponse executionResponse = underTest.deleteUserApplication(actionRequest);

    // assert
    verify(dockerService).removeContainer(application.getAppName());
    assertEquals(AppStatus.DELETED, executionResponse.getAppStatus());
    assertEquals("Application deleted successfully", executionResponse.getMessage());
  }

  @Test
  @DisplayName("Delete app with running success should throw BadRequest")
  void deleteApp_withRunningStatus_shouldThrowBadRequest() {
    // arrange
    UserApplication application = databaseSeederUtil.getApplication(TEST_ID);
    application.setStatus(ContainerCreationStatus.CREATED);
    application.setRunning(true);
    User user = databaseSeederUtil.getUser(TEST_ID);
    ApplicationActionRequest actionRequest = new ApplicationActionRequest();
    actionRequest.setUsername(user.getUsername());
    actionRequest.setAppName(application.getAppName());
    actionRequest.setAppId(application.getId());

    // act and assert
    BadRequest badRequest = assertThrows(BadRequest.class,
        () -> underTest.deleteUserApplication(actionRequest));
    assertEquals("Application is running. Stop it first", badRequest.getMessage());
  }

  @Test
  @DisplayName("Delete app stop app with no mapped container should throw NotFoundError")
  void deleteApp_withNoMappedContainer_shouldThrowNotFoundError() {
    // arrange
    UserApplication application = databaseSeederUtil.getApplication(TEST_ID);
    application.setStatus(ContainerCreationStatus.CREATED);
    User user = databaseSeederUtil.getUser(TEST_ID);
    ApplicationActionRequest actionRequest = new ApplicationActionRequest();
    actionRequest.setUsername(user.getUsername());
    actionRequest.setAppName(application.getAppName());
    actionRequest.setAppId(application.getId());

    // when
    when(dockerService.isContainerExists(application.getAppName())).thenReturn(Optional.empty());

    // act and assert
    NotFoundException notFoundError = assertThrows(NotFoundException.class,
        () -> underTest.deleteUserApplication(actionRequest));
    assertTrue(notFoundError.getMessage().contains("Container not found"));
  }

  @Test
  @DisplayName("Delete app with mapped running container should throw BadRequest")
  void deleteApp_withMappedRunningContainer_shouldThrowBadRequest() {
    // arrange
    UserApplication application = databaseSeederUtil.getApplication(TEST_ID);
    application.setStatus(ContainerCreationStatus.CREATED);
    application.setRunning(true);
    User user = databaseSeederUtil.getUser(TEST_ID);
    ApplicationActionRequest actionRequest = new ApplicationActionRequest();
    actionRequest.setUsername(user.getUsername());
    actionRequest.setAppName(application.getAppName());
    actionRequest.setAppId(application.getId());

    // when
    when(dockerService.isContainerExists(application.getAppName())).thenReturn(Optional.of(true));
    InspectContainerResponse inspectContainerResponse = Mockito.mock(
        InspectContainerResponse.class);
    InspectContainerResponse.ContainerState containerState = mock(
        InspectContainerResponse.ContainerState.class);
    when(dockerService.inspectDocker(application.getAppName())).thenReturn(
        inspectContainerResponse);
    when(inspectContainerResponse.getState()).thenReturn(containerState);
    when(containerState.getStatus()).thenReturn("running");

    // act and assert
    BadRequest badRequest = assertThrows(BadRequest.class,
        () -> underTest.deleteUserApplication(actionRequest));
    assertEquals("Application is running. Stop it first", badRequest.getMessage());
  }
}