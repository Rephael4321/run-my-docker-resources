package com.codingbc.runmydocker.integrations;

import com.codingbc.runmydocker.TestUtil;
import com.codingbc.runmydocker.models.User;
import com.codingbc.runmydocker.models.UserApplication;
import com.codingbc.runmydocker.repositories.UserApplicationRepository;
import com.codingbc.runmydocker.repositories.UserRepository;
import java.util.ArrayList;
import java.util.HashSet;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class DatabaseUtil {

  private final UserRepository userRepository;
  private final UserApplicationRepository userApplicationRepository;

  @Autowired
  public DatabaseUtil(UserRepository userRepository,
      UserApplicationRepository userApplicationRepository) {
    this.userRepository = userRepository;

    this.userApplicationRepository = userApplicationRepository;
  }

  public void cleanDatabase() {
    userRepository.deleteAll();
  }

  public void seedData(String testId) {
    log.info("seeding db");
    User user = createUser(testId);
    log.info("User seeded, {}", user);
  }

  private User createUser(String testId) {
    User user = TestUtil.getUser(testId);
    user.setUserApplications(new HashSet<>(2));
    user.setActivationCodes(new ArrayList<>(1));
    UserApplication application = TestUtil.getApplication(testId);
    user.getUserApplications().add(application);
    // userApplicationRepository.save(application);
    return userRepository.save(user);
  }

  private UserApplication createApplication(String testId) {
    UserApplication application = TestUtil.getApplication(testId);
    return userApplicationRepository.save(application);

  }

  public UserApplication update(UserApplication application) {
    return userApplicationRepository.save(application);
  }

  public User getUser(String testId) {
    String userName = testId + "@gmail.com";
    return userRepository.findByUsername(userName).orElse(null);
  }

  public UserApplication getApplication(String testId) {
    return userApplicationRepository.findByAppName(testId).orElse(null);
  }

}
