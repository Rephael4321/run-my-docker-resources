package com.codingbc.runmydocker;

import com.codingbc.runmydocker.models.User;
import com.codingbc.runmydocker.models.UserApplication;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.Map;

public class TestUtil {

  public static User getUser(String testId) {
    try {
      Map<String, String> params = Map.of("{{test-id}}", testId);
      String jsonContent = JsonTestUtil.readJsonFileAsString(
          ClassLoader.getSystemResource("data/users.json").toURI());
      return JsonTestUtil.replacePlaceholders(jsonContent, params, User.class);
    } catch (IOException | URISyntaxException e) {
      throw new RuntimeException(e);
    }

  }

  public static UserApplication getApplication(String testId) {
    try {
      Map<String, String> params = Map.of("{{test-id}}", testId);
      String jsonContent = JsonTestUtil.readJsonFileAsString(
          ClassLoader.getSystemResource("data/applications.json").toURI());
      return JsonTestUtil.replacePlaceholders(jsonContent, params, UserApplication.class);
    } catch (IOException | URISyntaxException e) {
      throw new RuntimeException(e);
    }
  }


}
