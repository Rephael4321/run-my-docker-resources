package com.codingbc.runmydocker;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Map;
import java.util.Map.Entry;

public class JsonTestUtil {

  private static final ObjectMapper objectMapper = new ObjectMapper();

  public static String readJsonFileAsString(URI pathFile) throws IOException {
    return new String(Files.readAllBytes(Paths.get(pathFile)));
  }

  public static <T> T replacePlaceholders(String jsonContent,
      Map<String, String> placeholders, Class<T> tClass)
      throws IOException {

    for (Entry<String, String> entry : placeholders.entrySet()) {
      jsonContent = jsonContent.replace(entry.getKey(), entry.getValue());

    }
    return objectMapper.readValue(jsonContent, tClass);
  }


  public static <T> T readJsonFixture(String filePath, Class<T> tClass) throws IOException {
    return objectMapper.readValue(new File(filePath), tClass);

  }

}
