package com.codingbc.runmydocker.controllers;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import com.codingbc.runmydocker.dto.ApiResponse;
import com.codingbc.runmydocker.dto.UserApplication.NewApplicationResponse;
import com.codingbc.runmydocker.dto.UserApplication.UserApplicationCreateDTO;
import com.codingbc.runmydocker.events.EventPublisher;
import com.codingbc.runmydocker.exceptions.ConflictError;
import com.codingbc.runmydocker.exceptions.NotFoundError;
import com.codingbc.runmydocker.integrations.DatabaseUtil;
import com.codingbc.runmydocker.models.User;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.Objects;
import java.util.UUID;
import javax.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;

@SpringBootTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@ActiveProfiles({"test"})
@AutoConfigureMockMvc
class UserApplicationControllerTest {

  public static final String TEST_ID = UUID.randomUUID().toString();

  @Autowired
  private DatabaseUtil databaseSeederUtil;

  @Autowired
  private UserApplicationController underTest;
  @MockBean
  EventPublisher eventPublisher;
//  @MockBean
//  private DockerService dockerService;

  @Autowired
  private MockMvc mockMvc;

  private final ObjectMapper objectMapper = new ObjectMapper();


  private final HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);

  @BeforeEach
  void setUp() {
    databaseSeederUtil.seedData(TEST_ID);

  }

  @AfterEach
  void tearDown() {
    databaseSeederUtil.cleanDatabase();
  }

  @Test
  @DisplayName("Create app with valid input should return 201")
  @Transactional
  void createApp_withValidInput_shouldReturn201() {
    User user = databaseSeederUtil.getUser(TEST_ID);
    UserApplicationCreateDTO createAppDTO = new UserApplicationCreateDTO();
    createAppDTO.setDockerImage("natanger97/web-scraping-chatbot");
    createAppDTO.setAppName("test-app");
    createAppDTO.setContainerPort(8080);
    createAppDTO.setUsername(user.getUsername());

    when(httpServletRequest.getAttribute("username")).thenReturn(user.getUsername());
//    when(dockerService.isImgOnDockerHub(createAppDTO.getDockerImage())).thenReturn(true);

    httpServletRequest.setAttribute("username", user.getUsername());
    ResponseEntity<ApiResponse<NewApplicationResponse>> response = underTest.createApplication(createAppDTO,
        httpServletRequest);

    assertTrue(response.getStatusCode().is2xxSuccessful());
    assertEquals(Objects.requireNonNull(response.getBody()).getData().getName(),
        createAppDTO.getAppName());


  }

  @DisplayName("Create app with exists name should return 409")
  @Test
  @Transactional
  void createApp_withExistsName_shouldReturn409() {
    User user = databaseSeederUtil.getUser(TEST_ID);
    UserApplicationCreateDTO createAppDTO = new UserApplicationCreateDTO();
    createAppDTO.setDockerImage("natanger97/web-scraping-chatbot");
    createAppDTO.setAppName(TEST_ID);
    createAppDTO.setContainerPort(8080);
    createAppDTO.setUsername(user.getUsername());

    when(httpServletRequest.getAttribute("username")).thenReturn(user.getUsername());

    httpServletRequest.setAttribute("username", user.getUsername());
    ConflictError entityConflicError = assertThrows(ConflictError.class,
        () -> underTest.createApplication(createAppDTO, httpServletRequest));

    assertEquals("UserApplication already exists with {appName=" + TEST_ID + "}",
        entityConflicError.getMessage());
  }

  @Test
  @Transactional
  void createApp_whenDockerImageIsNotOnDockerHub_shouldReturn404() {
    User user = databaseSeederUtil.getUser(TEST_ID);
    UserApplicationCreateDTO createAppDTO = new UserApplicationCreateDTO();
    createAppDTO.setDockerImage("natanger97/web-scraping-chatbot-bla");
    createAppDTO.setAppName("test-app");
    createAppDTO.setContainerPort(8080);
    createAppDTO.setUsername(user.getUsername());

    when(httpServletRequest.getAttribute("username")).thenReturn(user.getUsername());

    httpServletRequest.setAttribute("username", user.getUsername());

    assertThrows(NotFoundError.class,
        () -> underTest.createApplication(createAppDTO, httpServletRequest));
  }

}