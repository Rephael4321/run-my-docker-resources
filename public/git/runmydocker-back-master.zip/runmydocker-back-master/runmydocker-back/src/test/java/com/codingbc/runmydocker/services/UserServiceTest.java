/*
 * Copyright (c) 2024.
 */

package com.codingbc.runmydocker.services;

import static org.junit.jupiter.api.Assertions.*;

import com.codingbc.runmydocker.builders.ActivationCodeBuilder;
import com.codingbc.runmydocker.builders.CompleteRegistrationRequestBuilder;
import com.codingbc.runmydocker.builders.RegularUserCreateDTOBuilder;
import com.codingbc.runmydocker.builders.UserBuilder;
import com.codingbc.runmydocker.dto.AppUser.RegularUserCreateDTO;
import com.codingbc.runmydocker.dto.auth.CompleteRegistrationRequest;
import com.codingbc.runmydocker.exceptions.ConflictError;
import com.codingbc.runmydocker.exceptions.NotFoundError;
import com.codingbc.runmydocker.mappers.User.IUserMapper;
import com.codingbc.runmydocker.models.ActivationCode;
import com.codingbc.runmydocker.models.User;
import com.codingbc.runmydocker.repositories.UserRepository;
import java.time.LocalDateTime;
import java.util.Optional;
import java.util.UUID;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class UserServiceTest {

  @Mock private UserRepository userRepository;
  @Mock private IUserMapper userMapper;

  @Mock private ActivationCodeService activationCodeService;

  @InjectMocks private UserService userService;

  @Test
  void findByUsernameOr404_UserExist() {
    // arrange
    String username = "test-user";
    User user = UserBuilder.builder().username(username).build();
    Mockito.when(userRepository.findByUsername(username)).thenReturn(Optional.of(user));

    // act
    User findResult = userService.findByUsernameOr404(username);

    // assert
    assertEquals(user, findResult);
    assertEquals(user.getUsername(), findResult.getUsername());
  }

  @Test
  void findByUsernameOr404_UserNotFound() {
    // arrange
    String username = "not-found";
    Mockito.when(userRepository.findByUsername(username)).thenReturn(Optional.empty());

    // act

    // assert
    NotFoundError entityNotFoundError =
        assertThrows(NotFoundError.class, () -> userService.findByUsernameOr404(username));

    assertNotNull(entityNotFoundError.getMessage());
    assertEquals(
        "User was not found for params {username=not-found}", entityNotFoundError.getMessage());
  }

  @Test
  void findByIdOr404_UserExist() {
    // arrange
    long id = 1L;
    User user = new User();
    user.setId(id);
    Mockito.when(userRepository.findById(id)).thenReturn(Optional.of(user));

    // act
    User findResult = userService.findByIdOr404(id);

    // assert
    assertEquals(user, findResult);
    assertEquals(user.getId(), findResult.getId());
  }

  @Test
  void findByIdOr404_UserNotFound() {
    // arrange
    long id = 2L;
    Mockito.when(userRepository.findById(id)).thenReturn(Optional.empty());

    NotFoundError entityNotFoundError =
        assertThrows(NotFoundError.class, () -> userService.findByIdOr404(id));

    assertNotNull(entityNotFoundError.getMessage());
    assertEquals("User was not found for params {userId=2}", entityNotFoundError.getMessage());
  }

  @Test
  void create_UserCreatedSuccessfully() {
    RegularUserCreateDTO dto =
        RegularUserCreateDTOBuilder.aRegularUserCreateDTO().withUsername("test@gmail.com").build();
    User user = UserBuilder.builder().username(dto.getUsername()).build();
    ActivationCode activationCode =
        ActivationCodeBuilder.anActivationCode()
            .withUuidToken(UUID.randomUUID().toString())
            .withUser(user)
            .withExpirationTime(LocalDateTime.now().plusMinutes(10))
            .withCode("1111")
            .build();

    Mockito.when(userRepository.existsByUsernameIgnoreCase(dto.getUsername())).thenReturn(false);
    Mockito.when(userMapper.regularUserCreateDtoToUser(dto)).thenReturn(user);
    Mockito.when(activationCodeService.generateActivationCode(user)).thenReturn(activationCode);
    Mockito.when(userRepository.save(user)).thenReturn(user);
    Mockito.when(userRepository.saveAndFlush(user)).thenReturn(user);

    User createdUser = userService.create(dto);

    Mockito.verify(userRepository).save(user);
    Mockito.verify(userRepository).saveAndFlush(user);
    Assertions.assertEquals(user, createdUser);
  }

  @Test
  void testCreate_UserAlreadyExists() {
    String username = "exists@gmail.com";
    RegularUserCreateDTO dto =
        RegularUserCreateDTOBuilder.aRegularUserCreateDTO().withUsername(username).build();

    Mockito.when(userRepository.existsByUsernameIgnoreCase(username)).thenReturn(true);

    ConflictError error =
        assertThrows(ConflictError.class, () -> userService.create(dto));

    assertTrue(error.getMessage().contains("User already exists with {username=exists@gmail.com}"));
  }

  @Test
  @DisplayName("test-associateUserWithActivationCode")
  void associateUserWithActivationCode() {
    User user = UserBuilder.builder().build();
    ActivationCode activationCode = ActivationCodeBuilder.anActivationCode().build();

    Mockito.when(activationCodeService.generateActivationCode(user)).thenReturn(activationCode);

    userService.associateUserWithActivationCode(user);

    assertEquals(user.getLastActivationCode(), activationCode);
    assertEquals(user.getActivationCodes().size(), 1);
  }

  @Test
  void completeRegistration_Success() {
    long userId = 1L;
    CompleteRegistrationRequest request =
        CompleteRegistrationRequestBuilder.aCompleteRegistrationRequest()
            .withId(userId)
            .withFirstName("firstName")
            .withLastName("lastName")
            .withPhone("+972-546667799")
            .build();

    User user = new User();
    user.setId(userId);

    Mockito.when(userRepository.findById(userId)).thenReturn(Optional.of(user));
    Mockito.when(userRepository.saveAndFlush(user)).thenReturn(user);

    User results = userService.completeRegistration(userId, request);
    Mockito.verify(userRepository).saveAndFlush(user);

    assertTrue(user.isRegistrationCompleted());
    assertEquals(results.getFirstName(), request.getFirstName());
    assertEquals(results.getLastName(), request.getLastName());
    assertEquals(results.getPhone(), request.getPhone());
  }

  @Test
  void completeRegistration_UserNotFound() {
    long userId = 1L;
    CompleteRegistrationRequest request =
        CompleteRegistrationRequestBuilder.aCompleteRegistrationRequest().build();

    Mockito.when(userRepository.findById(userId)).thenReturn(Optional.empty());

    NotFoundError error =
        assertThrows(
            NotFoundError.class, () -> userService.completeRegistration(userId, request));

    assertEquals(error.getMessage(), "User was not found for params {userId=1}");
  }
}
