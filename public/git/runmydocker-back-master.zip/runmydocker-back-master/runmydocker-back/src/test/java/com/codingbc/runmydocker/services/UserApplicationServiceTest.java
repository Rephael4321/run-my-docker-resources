/*
 * Copyright (c) 2024.
 */

package com.codingbc.runmydocker.services;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.codingbc.runmydocker.builders.UserBuilder;
import com.codingbc.runmydocker.dto.UserApplication.ApplicationActionRequest;
import com.codingbc.runmydocker.dto.UserApplication.NewApplicationResponse;
import com.codingbc.runmydocker.dto.UserApplication.UserApplicationCreateDTO;
import com.codingbc.runmydocker.events.EventPublisher;
import com.codingbc.runmydocker.exceptions.BadRequest;
import com.codingbc.runmydocker.exceptions.ConflictError;
import com.codingbc.runmydocker.exceptions.NotFoundError;
import com.codingbc.runmydocker.models.User;
import com.codingbc.runmydocker.models.UserApplication;
import com.codingbc.runmydocker.repositories.UserApplicationRepository;
import com.github.dockerjava.api.command.InspectContainerResponse;
import java.util.Collections;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
@Slf4j
class UserApplicationServiceTest {

  @Mock
  private UserApplicationRepository userApplicationRepository;
  @Mock
  private UserService userService;
  @Mock
  private DockerService dockerService;

  @Mock
  private EventPublisher eventPublisher;

  @InjectMocks
  private UserApplicationService underTest;

  @Test
  void create_shouldreateNewApplication() {
    // given
    User user = new UserBuilder().username("user@gmail.com").build();
    UserApplicationCreateDTO dto = new UserApplicationCreateDTO();
    dto.setAppName("new-app");
    dto.setContainerPort(8080);
    dto.setUsername("user@gmail.com");
    dto.setDockerImage("test-img");

    // when
    when(userService.findByUsernameOr404(any())).thenReturn(user);
    when(dockerService.isImgOnDockerHub("test-img")).thenReturn(true);
    when(userApplicationRepository.existsByAppName("new-app")).thenReturn(false);
    when(userApplicationRepository.save(any())).thenReturn(new UserApplication());

    var results = underTest.create(dto);

    // then
    assertNotNull(results);
  }

  @Test
  @DisplayName("createNewApplication should fail due conflict with container name")
  void createNewApplication_WhenContainerNameIsTaken() {
    UserApplicationCreateDTO dto = new UserApplicationCreateDTO();
    dto.setAppName("taken-name");
    dto.setContainerPort(8080);
    dto.setUsername("natan@gmail.com");
    dto.setDockerImage("test-img");

    when(userApplicationRepository.existsByAppName(dto.getAppName())).thenReturn(true);

    assertThrows(ConflictError.class, () -> underTest.createNewApplication(dto));

  }

  @Test
  @DisplayName("createNewApplication should fail with notFoundError due unknow docker img")
  void createNewApplication_WhenDockerImageNotFound() {
    UserApplicationCreateDTO dto = new UserApplicationCreateDTO();
    dto.setAppName("taken-name");
    dto.setContainerPort(8080);
    dto.setUsername("user@gmail.com");
    dto.setDockerImage("test-img");

    when(userApplicationRepository.existsByAppName(dto.getAppName())).thenReturn(false);
    when(dockerService.findIfDockerImageExists(dto.getDockerImage())).thenReturn(false);

    assertThrows(NotFoundError.class, () -> underTest.createNewApplication(dto));

  }

  @Test
  @DisplayName("createNewApplication should fail with EntityNotFoundError due unknow user")
  void createNewApplication_WhenUserNotFound() {
    UserApplicationCreateDTO dto = new UserApplicationCreateDTO();
    dto.setAppName("taken-name");
    dto.setContainerPort(8080);
    dto.setUsername("natan@gmail.com");
    dto.setDockerImage("test-img");

    when(userApplicationRepository.existsByAppName(dto.getAppName())).thenReturn(false);
    when(dockerService.findIfDockerImageExists(dto.getDockerImage())).thenReturn(true);
    when(userService.findByUsernameOr404(dto.getUsername())).thenThrow(NotFoundError.class);

    assertThrows(NotFoundError.class, () -> underTest.createNewApplication(dto));
    verify(userService).findByUsernameOr404(dto.getUsername());
  }

  @Test
  @DisplayName("createNewApplication should fail with Bad Request due reach limit of apps")
  void createNewApplication_WhenUserReachAppLimit() {
    UserApplicationCreateDTO dto = new UserApplicationCreateDTO();
    dto.setAppName("taken-name");
    dto.setContainerPort(8080);
    dto.setUsername("natan@gmail.com");
    dto.setDockerImage("test-img");

    User mockedUser = Mockito.mock(User.class);
    mockedUser.setUserApplications(Collections.emptySet());

    when(userApplicationRepository.existsByAppName(dto.getAppName())).thenReturn(false);
    when(dockerService.findIfDockerImageExists(dto.getDockerImage())).thenReturn(true);
    when(userService.findByUsernameOr404(dto.getUsername())).thenReturn(mockedUser);
    when(mockedUser.getUsername()).thenReturn(dto.getUsername());
    when(mockedUser.getApplicationCount()).thenReturn(10);

    assertThrows(BadRequest.class, () -> underTest.createNewApplication(dto));

  }

  @Test
  @DisplayName("createNewApplication should succeed")
  void createNewApplication() {
    UserApplicationCreateDTO dto = new UserApplicationCreateDTO();
    dto.setAppName("taken-name");
    dto.setContainerPort(8080);
    dto.setUsername("natan@gmail.com");
    dto.setDockerImage("mysql:latest");

    User mockedUser = Mockito.mock(User.class);

    when(dockerService.findIfDockerImageExists(dto.getDockerImage())).thenReturn(true);
    when(dockerService.isImageAvailableLocally(dto.getDockerImage())).thenReturn(true);
    when(userApplicationRepository.existsByAppName(dto.getAppName())).thenReturn(false);
    when(userService.findByUsernameOr404(dto.getUsername())).thenReturn(mockedUser);
    when(mockedUser.getUsername()).thenReturn(dto.getUsername());
    when(userApplicationRepository.save(any(UserApplication.class))).thenReturn(
        new UserApplication());

    NewApplicationResponse userApplication = underTest.createNewApplication(dto);
    log.info("{}", userApplication);

  }

  @Test
  @DisplayName("startApp should start the application when it is not running")
  void startApp_WhenAppIsNotRunning() {
    ApplicationActionRequest request = new ApplicationActionRequest();
    request.setAppName("test-app");
    request.setAppId(1L);

    InspectContainerResponse inspectContainerResponse = mock(InspectContainerResponse.class);

    UserApplication userApplication = new UserApplication();
    userApplication.setAppName("test-app");
    userApplication.setRunning(false);
    when(dockerService.isContainerExists(request.getAppName())).thenReturn(Optional.of(true));
    when(userApplicationRepository.findByIdAndAppName(request.getAppId(),
        request.getAppName())).thenReturn(
            Optional.of(userApplication));
    when(dockerService.inspectDocker(request.getAppName())).thenReturn(inspectContainerResponse);
    when(inspectContainerResponse.getState()).thenReturn(
        mock(InspectContainerResponse.ContainerState.class));
    when(inspectContainerResponse.getState().getStatus()).thenReturn("exited");
    when(userApplicationRepository.findByAppName(request.getAppName())).thenReturn(any());

    verify(dockerService, times(1)).startContainer(userApplication.getAppName());
    assertTrue(userApplication.isRunning());
  }

  @Test
  void startApp() {
  }

  @Test
  void stopApp() {
  }

  @Test
  void deleteApp() {
  }
}