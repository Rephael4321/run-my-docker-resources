/*
 * Copyright (c) 2024.
 */

package com.codingbc.runmydocker.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.codingbc.runmydocker.builders.ActivationCodeBuilder;
import com.codingbc.runmydocker.builders.AuthenticationRequestBuilder;
import com.codingbc.runmydocker.builders.CompleteRegistrationRequestBuilder;
import com.codingbc.runmydocker.builders.RegularUserCreateDTOBuilder;
import com.codingbc.runmydocker.builders.UserBuilder;
import com.codingbc.runmydocker.builders.UserOutDtoBuilder;
import com.codingbc.runmydocker.dto.AppUser.RegularUserCreateDTO;
import com.codingbc.runmydocker.dto.AppUser.UserOutDTO;
import com.codingbc.runmydocker.dto.auth.ActivationRequest;
import com.codingbc.runmydocker.dto.auth.ActivationResponse;
import com.codingbc.runmydocker.dto.auth.AuthenticationRequest;
import com.codingbc.runmydocker.dto.auth.CompleteRegistrationRequest;
import com.codingbc.runmydocker.dto.auth.RegistrationResponse;
import com.codingbc.runmydocker.events.User.UserRegisteredEvent;
import com.codingbc.runmydocker.exceptions.GeneralError;
import com.codingbc.runmydocker.mappers.User.IUserMapper;
import com.codingbc.runmydocker.models.ActivationCode;
import com.codingbc.runmydocker.models.User;
import com.codingbc.runmydocker.repositories.ActivationCodeRepository;
import com.codingbc.runmydocker.repositories.UserRepository;
import com.codingbc.runmydocker.security.CustomUserDetailsService;
import com.codingbc.runmydocker.util.JwtTokenUtil;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.core.userdetails.UserDetails;

@ExtendWith(MockitoExtension.class)
class AuthServiceTest {
  @Mock private ActivationCodeRepository activationCodeRepository;
  @Mock private UserRepository userRepository;
  @Mock private AuthenticationManager authenticationManager;
  @Mock private CustomUserDetailsService customUserDetailsService;
  @Mock private JwtTokenUtil jwtTokenUtil;
  @Mock private UserService userService;
  @Mock private ApplicationEventPublisher eventPublisher;
  @Mock private IUserMapper userMapper;
  @Mock private ActivationCodeService activationCodeService;

  @InjectMocks private AuthService authService;

  @Test
  void authenticate() {
    AuthenticationRequest request =
        AuthenticationRequestBuilder.anAuthenticationRequest()
            .withUsername("user@gmail.com")
            .withPassword("password")
            .build();
    UserDetails userDetails = mock(UserDetails.class);

    when(authenticationManager.authenticate(any())).thenReturn(any());
    when(customUserDetailsService.loadUserByUsername("user@gmail.com")).thenReturn(userDetails);
    when(jwtTokenUtil.generateToken(userDetails)).thenReturn("token");

    String token = authService.authenticate(request);

    assertEquals("token", token);
    verify(authenticationManager).authenticate(any());
    verify(customUserDetailsService).loadUserByUsername(request.getUsername());
    verify(jwtTokenUtil).generateToken(userDetails);
  }

  @Test
  void register() {
    RegularUserCreateDTO dto =
        RegularUserCreateDTOBuilder.aRegularUserCreateDTO().withUsername("user@gmail.com").build();
    User user = UserBuilder.builder().build();
    UserOutDTO outDTO = new UserOutDTO();
    ActivationCode activationCode =
        ActivationCodeBuilder.anActivationCode().withUuidToken("uuid").withCode("1234").build();
    user.setActivationCodes(Collections.singletonList(activationCode));

    when(userService.create(dto)).thenReturn(user);
    when(userMapper.fromUserToUserOutDTO(user)).thenReturn(outDTO);

    RegistrationResponse registrationResponse = authService.register(dto);

    verify(userMapper).fromUserToUserOutDTO(user);
    verify(userService).create(dto);
    verify(eventPublisher).publishEvent(any(UserRegisteredEvent.class));

    assertEquals(outDTO, registrationResponse.getUser());
    assertEquals(activationCode.getUuidToken(), registrationResponse.getUuid());
  }

  @Test
  void activateUser_Success() {
    ActivationRequest request = new ActivationRequest("12345", "uuid", "username@gmail.com");
    User user = UserBuilder.builder().username(request.getUsername()).build();
    user.setActivated(false);
    ActivationCode activationCode =
        ActivationCodeBuilder.anActivationCode()
            .withExpirationTime(LocalDateTime.now().plusWeeks(1))
            .withUsed(false)
            .build();
    UserDetails userDetails = mock(UserDetails.class);

    when(userService.findByUsernameOr404("username@gmail.com")).thenReturn(user);
    when(activationCodeRepository.findByCodeAndUserIdAndUuidToken(
            request.getCode(), user.getId(), request.getUuid()))
        .thenReturn(Optional.of(activationCode));
    when(userRepository.save(user)).thenReturn(user);
    when(customUserDetailsService.loadUserByUsername(user.getUsername())).thenReturn(userDetails);
    when(jwtTokenUtil.generateToken(userDetails)).thenReturn("token");

    ActivationResponse activationResponse = authService.activateUser(request);

    assertTrue(user.isActivated());
    assertTrue(activationCode.isUsed());
    assertEquals("User activated", activationResponse.getMessage());
    assertEquals("username@gmail.com", activationResponse.getUsername());
    assertEquals("token", activationResponse.getJwtToken());

    verify(userRepository).save(user);
  }

  @Test
  void activateUser_UserAlreadyActivated() {
    ActivationRequest request = new ActivationRequest("12345", "uuid", "username@gmail.com");
    User user = UserBuilder.builder().username(request.getUsername()).build();
    user.setActivated(true);

    when(userService.findByUsernameOr404(request.getUsername())).thenReturn(user);

    GeneralError error = assertThrows(GeneralError.class, () -> authService.activateUser(request));

    assertEquals("User already activated", error.getMessage());
  }

  @Test
  void resendActicationCode() {
    String username = "username@gmail.com";
    User user = UserBuilder.builder().username(username).build();
    ActivationCode activationCode =
        ActivationCodeBuilder.anActivationCode()
            .withCode("code")
            .withUuidToken("uuid")
            .withUser(user)
            .build();
    user.setActivationCodes(Collections.singletonList(activationCode));
    UserOutDTO outDTO = UserOutDtoBuilder.builder().withUsername(username).build();

    when(userService.findByUsernameOr404(username)).thenReturn(user);
    when(userRepository.saveAndFlush(user)).thenReturn(user);
    when(userMapper.fromUserToUserOutDTO(activationCode.getUser())).thenReturn(outDTO);
    RegistrationResponse registrationResponse = authService.resendActicationCode(username);

    verify(activationCodeService).sendActivationCode(activationCode);
    assertEquals(activationCode.getUuidToken(), registrationResponse.getUuid());
    assertEquals(outDTO, registrationResponse.getUser());

  }

  @Test
  void completeUserRegistration() {
    long userId = 1L;
    CompleteRegistrationRequest request =
        CompleteRegistrationRequestBuilder.aCompleteRegistrationRequest().withId(userId).build();

    User user = new User();
    user.setId(userId);
    UserOutDTO outDTO = UserOutDtoBuilder.builder().build();
    ActivationCode activationCode =
        ActivationCodeBuilder.anActivationCode().withCode("1234").withUuidToken("uuid").build();
    user.setActivationCodes(Collections.singletonList(activationCode));

    when(userService.completeRegistration(userId, request)).thenReturn(user);
    when(userMapper.fromUserToUserOutDTO(user)).thenReturn(outDTO);

    RegistrationResponse registrationResponse =
        authService.completeUserRegistration(userId, request);

    verify(eventPublisher).publishEvent(any(UserRegisteredEvent.class));
    assertEquals("uuid", registrationResponse.getUuid());
  }

  @Test
  void completeUserRegistration_ThrowGeneralError() {
    long userId = 1L;
    CompleteRegistrationRequest request =
        CompleteRegistrationRequestBuilder.aCompleteRegistrationRequest().withId(2L).build();

    GeneralError error =
        assertThrows(
            GeneralError.class, () -> authService.completeUserRegistration(userId, request));

    assertEquals("You can't complete registration for other user", error.getMessage());
  }
}
