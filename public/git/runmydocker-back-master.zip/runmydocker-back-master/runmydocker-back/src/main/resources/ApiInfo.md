# Run-My-Docker API

**API Base URL:** `https://backend.runmydocker.com`  
**Version:** 3.0

**Description:**  
Run-My-Docker is a free platform powered and sponsored by [CodingBC](https://codingbc.com) that provides a hosting and deployment solution for Docker containers. The platform is designed to be simple and easy to use, targeting developers and small teams who wish to deploy their applications in a cost-effective manner.

**Main Features:**
- **Simple and Easy to Use:** Intuitive design for user-friendly experiences.
- **Free Hosting:** No costs associated with using the platform.
- **Docker Support:** Facilitates deployment in a containerized environment.
- **Subdomains:** Each deployed application gets a unique subdomain for easy access.

---

### Developed By:

- **Natan Gershbein** - [LinkedIn](https://www.linkedin.com/in/natangerhsbein/)
    - Responsibilities:
        - Created and maintained the REST API, ensuring stability, scalability, and security.
        - Designed backend architecture and managed infrastructure, focusing on performance and growth.
        - Monitored system usage and optimized backend efficiency.

- **Amit Licht** - [LinkedIn](https://www.linkedin.com/in/amit-licht/)
  - Responsibilities:
      - Developed the frontend, crafting responsive and intuitive user interfaces.
      - Handled UI/UX design and frontend deployment to ensure a seamless user experience.
      - Ensured smooth integration with the backend and optimized frontend performance.

---

For more information, visit [CodingBC](https://codingbc.com).
