package com.codingbc.runmydocker.models.migrations;

import com.codingbc.runmydocker.dto.UserApplication.UserApplicationCreateDTO;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.UUID;

@Entity
@Table(name = "user_application_to_migrate")
@Data
public class UserApplicationToMigrate {

  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  private UUID id;

  @JsonProperty("docker_image")
  private String dockerImage;
  @JsonProperty("app_name")
  private String appName;
  @JsonProperty("username")
  private String username;
  @JsonProperty("mapping_port")
  private int mappingPort;
  @JsonProperty("is_migrated")
  private boolean isMigrated = false;
    @JsonProperty("failure_reason")
  private String failureReason;


  public static UserApplicationToMigrate toUserApplicationToMigrate(UserApplicationCreateDTO dto) {
    UserApplicationToMigrate userApplicationToMigrate = new UserApplicationToMigrate();
    userApplicationToMigrate.setUsername(dto.getUsername());
    userApplicationToMigrate.setAppName(dto.getAppName());
    userApplicationToMigrate.setDockerImage(dto.getDockerImage());
    userApplicationToMigrate.setMappingPort(dto.getContainerPort());

    return userApplicationToMigrate;

  }

}
