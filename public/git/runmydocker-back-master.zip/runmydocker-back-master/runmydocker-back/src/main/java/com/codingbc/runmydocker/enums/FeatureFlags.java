package com.codingbc.runmydocker.enums;

import lombok.Getter;

@Getter
public enum FeatureFlags {
    SKIP_CAPACITY_VALIDATION("skip_apps_capacity_validation"),
    ALLOW_MORE_THAN_FIVE_APPS("allow_more_than_five_apps");

    private final String flagName;

    FeatureFlags(String flagName) {
        this.flagName = flagName;
    }

    }
