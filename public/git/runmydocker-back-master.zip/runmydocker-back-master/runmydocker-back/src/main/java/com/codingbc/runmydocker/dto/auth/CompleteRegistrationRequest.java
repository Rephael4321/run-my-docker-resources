/*
 * Copyright (c) 2024.
 */

package com.codingbc.runmydocker.dto.auth;

import lombok.Data;

@Data
public class CompleteRegistrationRequest {

  private Long id;
  private String firstName;
  private String lastName;
  private String phone;

}