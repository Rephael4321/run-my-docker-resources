/*
 * Copyright (c) 2024.
 */

package com.codingbc.runmydocker.util;

import java.util.Base64;
import java.util.Optional;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.SerializationUtils;

@Slf4j
public class CookieUtils {
  public static Optional<Cookie> getCookieFromRequest(
      HttpServletRequest request, String targetCookieName) {
    log.info("Searching for cookie: {} ", targetCookieName);
    Cookie[] cookies = request.getCookies();
    if (cookies != null && cookies.length > 0) {
      for (Cookie cookie : cookies) {
        String currentCookieName = cookie.getName();
        if (currentCookieName.equals(targetCookieName)) {
          return Optional.of(cookie);
        }
      }
    }

    return Optional.empty();
  }

  public static void addCookieToResponse(
      HttpServletResponse response, String cookieName, String cookieValue, int makeAge) {
    log.info("adding cookie: {}, {}", cookieName, cookieValue);
    Cookie cookie = new Cookie(cookieName, cookieValue);
    cookie.setPath("/");
    cookie.setHttpOnly(true);
    cookie.setMaxAge(makeAge);

    response.addCookie(cookie);
  }

  public static void removeCookie(
      HttpServletRequest request, HttpServletResponse response, String cookieName) {
    Cookie[] cookies = request.getCookies();
    if (cookies != null && cookies.length > 0) {
      for (Cookie currentCookie : cookies) {
        String currentCookieName = currentCookie.getName();
        if (currentCookieName.equals(cookieName)) {
          currentCookie.setPath("/");
          currentCookie.setMaxAge(0);
          currentCookie.setValue("");

          response.addCookie(currentCookie);
        }
      }
    }
  }

  public static String serialize(Object object) {
    return Base64.getUrlEncoder().encodeToString(SerializationUtils.serialize(object));
  }

  public static <T> T deserialize(Cookie cookie, Class<T> tClass) {
    return tClass.cast(
        SerializationUtils.deserialize(Base64.getUrlDecoder().decode(cookie.getValue())));
  }
}
