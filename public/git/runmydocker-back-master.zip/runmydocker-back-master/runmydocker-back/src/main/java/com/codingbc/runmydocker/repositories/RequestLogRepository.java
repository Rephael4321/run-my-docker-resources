package com.codingbc.runmydocker.repositories;

import com.codingbc.runmydocker.models.RequestLog;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RequestLogRepository extends JpaRepository<RequestLog, Long> {
  RequestLog findByRequestId(UUID requestId);
}
