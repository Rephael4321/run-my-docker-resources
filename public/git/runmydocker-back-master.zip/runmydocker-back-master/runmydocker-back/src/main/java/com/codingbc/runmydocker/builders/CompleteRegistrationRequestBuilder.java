/*
 * Copyright (c) 2024.
 */

package com.codingbc.runmydocker.builders;

import com.codingbc.runmydocker.dto.auth.CompleteRegistrationRequest;

public final class CompleteRegistrationRequestBuilder {

  private CompleteRegistrationRequest completeRegistrationRequest;

  public CompleteRegistrationRequestBuilder() {
    completeRegistrationRequest = new CompleteRegistrationRequest();
  }

  public CompleteRegistrationRequestBuilder(CompleteRegistrationRequest other) {
    this.completeRegistrationRequest = other;
  }

  public static CompleteRegistrationRequestBuilder aCompleteRegistrationRequest() {
    return new CompleteRegistrationRequestBuilder();
  }

  public CompleteRegistrationRequestBuilder withId(Long id) {
    completeRegistrationRequest.setId(id);
    return this;
  }

  public CompleteRegistrationRequestBuilder withFirstName(String firstName) {
    completeRegistrationRequest.setFirstName(firstName);
    return this;
  }

  public CompleteRegistrationRequestBuilder withLastName(String lastName) {
    completeRegistrationRequest.setLastName(lastName);
    return this;
  }

  public CompleteRegistrationRequestBuilder withPhone(String phone) {
    completeRegistrationRequest.setPhone(phone);
    return this;
  }

  public CompleteRegistrationRequest build() {
    return completeRegistrationRequest;
  }
}
