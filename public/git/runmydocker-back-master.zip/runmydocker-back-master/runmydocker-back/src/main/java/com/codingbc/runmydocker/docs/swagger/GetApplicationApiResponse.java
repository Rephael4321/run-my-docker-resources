package com.codingbc.runmydocker.docs.swagger;

import com.codingbc.runmydocker.models.UserApplication;
import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = true)
@Data
public class GetApplicationApiResponse extends BaseResponseModal {
  private UserApplication data;
}
