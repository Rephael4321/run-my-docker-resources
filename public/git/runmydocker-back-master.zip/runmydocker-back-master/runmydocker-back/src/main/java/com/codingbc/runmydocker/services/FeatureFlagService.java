package com.codingbc.runmydocker.services;

import com.codingbc.runmydocker.enums.FeatureFlags;
import com.codingbc.runmydocker.models.GlobalFeatureFlag;
import com.codingbc.runmydocker.models.UserFeatureFlag;
import com.codingbc.runmydocker.repositories.GlobalFeatureFlagRepository;
import com.codingbc.runmydocker.repositories.UserFeatureFlagRepository;
import org.springframework.stereotype.Service;


import java.util.Optional;

@Service
public class FeatureFlagService {
  private final GlobalFeatureFlagRepository globalFeatureFlagRepository;
  private final UserFeatureFlagRepository userFeatureFlagRepository;

  public FeatureFlagService(
      GlobalFeatureFlagRepository globalFeatureFlagRepository,
      UserFeatureFlagRepository userFeatureFlagRepository) {
    this.globalFeatureFlagRepository = globalFeatureFlagRepository;
    this.userFeatureFlagRepository = userFeatureFlagRepository;
  }

  public boolean isFeatureFlagEnabled(FeatureFlags featureFlag, Long userId) {
    if (userId == null) {
      Optional<GlobalFeatureFlag> globalFeatureFlag =
          globalFeatureFlagRepository.findByFlagName(featureFlag.getFlagName());
      return globalFeatureFlag.map(GlobalFeatureFlag::getIsEnabled).orElse(false);
    }

    return userFeatureFlagRepository.findByUserIdAndFlagName( userId, featureFlag.getFlagName())
            .map(UserFeatureFlag::getIsEnabled).orElse(false);
  }


  public GlobalFeatureFlag setGlobalFeatureFlag(FeatureFlags featureFlag, boolean isEnabled) {
    GlobalFeatureFlag globalFeatureFlag = globalFeatureFlagRepository.findByFlagName(featureFlag.getFlagName())
            .orElse(new GlobalFeatureFlag());
    globalFeatureFlag.setIsEnabled(isEnabled);
    globalFeatureFlag.setFlagName(featureFlag.getFlagName());
    return globalFeatureFlagRepository.save(globalFeatureFlag);
  }


  public UserFeatureFlag setUserFeatureFlag(Long userId, FeatureFlags flagName, boolean isEnabled) {
    UserFeatureFlag userFeatureFlag = userFeatureFlagRepository.findByUserIdAndFlagName(userId, flagName.getFlagName())
            .orElse(new UserFeatureFlag());
    userFeatureFlag.setUserId(userId);
    userFeatureFlag.setFlagName(flagName.getFlagName());
    userFeatureFlag.setIsEnabled(isEnabled);
    return userFeatureFlagRepository.save(userFeatureFlag);
  }
}
