package com.codingbc.runmydocker.repositories;

import com.codingbc.runmydocker.models.ActivationCode;
import com.codingbc.runmydocker.models.User;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface ActivationCodeRepository extends JpaRepository<ActivationCode, Long> {
  @Query("select a from ActivationCode a where a.code = ?1 and a.user = ?2")
  Optional<ActivationCode> findByCodeAndUser(String code, User user);

  @Query("select a from ActivationCode a where a.code = ?1 and a.user.id = ?2 and a.uuidToken = ?3")
  Optional<ActivationCode> findByCodeAndUserIdAndUuidToken(String code, long id, String uuidToken);

  @Query("select a from ActivationCode a where a.uuidToken = ?1")
  ActivationCode findByUuidToken(String uuidToken);

    @Query("select a from ActivationCode a where a.user.username = ?1")
    Optional<ActivationCode> findByUsername(String username);

  String user(User user);
}
