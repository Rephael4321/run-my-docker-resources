package com.codingbc.runmydocker.factories;

import com.codingbc.runmydocker.models.UserApplication;
import com.codingbc.runmydocker.services.DockerService;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class RemoteContainerCreationStrategy implements ContainerCreationStrategy {

  private final DockerService dockerService;

  public RemoteContainerCreationStrategy(DockerService dockerService) {
    this.dockerService = dockerService;
  }

  @Override
  public void createContainer(UserApplication userApplication) {
    log.info("[RemoteContainerCreationStrategy] in createContainer");
    dockerService.pullImgAsync(userApplication);
    log.info("[RemoteContainerCreationStrategy] after pullImgAsync");
  }
}
