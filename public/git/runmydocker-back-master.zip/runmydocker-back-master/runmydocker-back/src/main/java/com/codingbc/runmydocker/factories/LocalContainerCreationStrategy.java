package com.codingbc.runmydocker.factories;

import com.codingbc.runmydocker.models.UserApplication;
import com.codingbc.runmydocker.services.DockerService;

public class LocalContainerCreationStrategy implements ContainerCreationStrategy {

  private final DockerService dockerService;

  public LocalContainerCreationStrategy(DockerService dockerService) {
    this.dockerService = dockerService;
  }

  @Override
  public void createContainer(UserApplication userApplication) {
    dockerService.createDockerContainer(userApplication);
  }
}
