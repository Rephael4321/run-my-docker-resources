/*
 * Copyright (c) 2024.
 */

package com.codingbc.runmydocker.mappers.UserApplication;

import com.codingbc.runmydocker.dto.UserApplication.ApplicationCreateResponse;
import com.codingbc.runmydocker.dto.UserApplication.NewApplicationResponse;
import com.codingbc.runmydocker.dto.UserApplication.UserApplicationCreateDTO;
import com.codingbc.runmydocker.dto.UserApplication.UserApplicationOut;
import com.codingbc.runmydocker.models.UserApplication;

public interface IUserApplicationMapper {
  UserApplication toUserApplication(UserApplicationCreateDTO dto);
  ApplicationCreateResponse toApplicationCreateResponse(UserApplication userApplication);
  UserApplicationOut toUserApplicationOut(UserApplication userApplication);
  NewApplicationResponse toNewApplicationResponse(UserApplication userApplication);
}
