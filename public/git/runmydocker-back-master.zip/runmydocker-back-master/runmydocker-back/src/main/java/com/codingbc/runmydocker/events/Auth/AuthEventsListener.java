package com.codingbc.runmydocker.events.Auth;

import com.codingbc.runmydocker.models.ActivationCode;
import com.codingbc.runmydocker.services.ActivationCodeService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class AuthEventsListener {
  @Autowired private ActivationCodeService activationCodeService;
  @Autowired private Environment environment;

  @EventListener
  @Async
  public void handleSendCodeEvent(SendCodeEvent event) {
    log.info("Send code event received");
    ActivationCode activationCode = event.getActivationCode();
    log.info("Sending activation code to user {}", activationCode.getUser().getUsername());
    if (environment.acceptsProfiles("dev")) {
      log.info("Activation code: {}", activationCode.getCode());
      return;
    }
    activationCodeService.sendActivationCode(activationCode);
  }
}
