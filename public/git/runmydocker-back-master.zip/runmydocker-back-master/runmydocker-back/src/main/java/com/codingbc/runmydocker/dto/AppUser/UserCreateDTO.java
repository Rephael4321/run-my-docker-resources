/*
 * Copyright (c) 2024.
 */

package com.codingbc.runmydocker.dto.AppUser;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import lombok.Data;
import org.hibernate.validator.constraints.Length;

@Data
public abstract class UserCreateDTO {
  @Email(message = "invalid email format")
  @NotNull(message = "username is require")
  protected String username;

  @NotBlank(message = "password is require")
  @Length(min = 4, message = "password needs to be at least 4 chars length")
  protected String password;}
