package com.codingbc.runmydocker.mappers.User;

import com.codingbc.runmydocker.builders.UserBuilder;
import com.codingbc.runmydocker.builders.UserOutDtoBuilder;
import com.codingbc.runmydocker.dto.AppUser.OAuth2UserCreateDTO;
import com.codingbc.runmydocker.dto.AppUser.RegularUserCreateDTO;
import com.codingbc.runmydocker.dto.AppUser.UserOutDTO;
import com.codingbc.runmydocker.models.User;

public class UserMapper implements IUserMapper {

  @Override
  public User regularUserCreateDtoToUser(RegularUserCreateDTO dto) {
    if (dto == null) return null;
    return UserBuilder.builder()
        .firstName(dto.getFirstName())
        .lastName(dto.getLastName())
        .username(dto.getUsername())
        .phone(dto.getPhone())
        .password(dto.getPassword())
        .build();
  }

  @Override
  public User OAuth2UserCreateDTOToUser(OAuth2UserCreateDTO dto) {
    if (dto == null) return null;

    return UserBuilder.builder()
        .username(dto.getUsername())
        .providerId(dto.getProviderId())
        .password(dto.getPassword())
        .isActivated(false)
        .registrationCompleted(false)
        .build();
  }

  @Override
  public UserOutDTO fromUserToUserOutDTO(User user) {
    if (user == null) return null;

    return UserOutDtoBuilder.builder()
        .withId(user.getId())
        .withFirstName(user.getFirstName())
        .withLastName(user.getLastName())
        .withUsername(user.getUsername())
        .withPhone(user.getPhone())
        .withActivated(user.isActivated())
        .build();
  }
}
