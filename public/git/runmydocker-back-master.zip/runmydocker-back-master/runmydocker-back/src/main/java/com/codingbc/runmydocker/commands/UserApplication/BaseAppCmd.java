/*
 * Copyright (c) 2024.
 */

package com.codingbc.runmydocker.commands.UserApplication;

import com.codingbc.runmydocker.dto.UserApplication.ApplicationActionRequest;
import com.codingbc.runmydocker.enums.ContainerCreationStatus;
import com.codingbc.runmydocker.exceptions.NotFoundError;
import com.codingbc.runmydocker.models.UserApplication;
import com.codingbc.runmydocker.repositories.UserApplicationRepository;
import com.codingbc.runmydocker.services.DockerService;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public abstract class BaseAppCmd implements UserAppCmd {

  protected final DockerService dockerService;
  protected final UserApplicationRepository userApplicationRepository;
  protected final ApplicationActionRequest actionRequest;

  public BaseAppCmd(DockerService dockerService,
      UserApplicationRepository userApplicationRepository,
      ApplicationActionRequest actionRequest) {
    this.dockerService = dockerService;
    this.userApplicationRepository = userApplicationRepository;
    this.actionRequest = actionRequest;
  }

  /**
   * Find the user application by appId and appName
   *
   * @return UserApplication
   * @throws NotFoundError if the  application is not found
   */
  protected UserApplication findByAppIdAndAppName() {
    log.info("Finding application by appId: {} and appName: {}", actionRequest.getAppId(),
        actionRequest.getAppName());
    return userApplicationRepository.findByIdAndAppName(
            actionRequest.getAppId(),
            actionRequest.getAppName())
        .orElseThrow(() -> new NotFoundError("Application not found",
            Map.of("appId", actionRequest.getAppId(), "appName", actionRequest.getAppName())));
  }


  protected boolean isAppFailedToCreate(UserApplication userApplication) {
    return userApplication.getStatus().equals(ContainerCreationStatus.FAILED);
  }

  protected abstract void validateState(UserApplication userApplication);
}
