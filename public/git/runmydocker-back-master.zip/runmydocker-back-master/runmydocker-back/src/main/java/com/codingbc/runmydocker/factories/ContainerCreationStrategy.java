package com.codingbc.runmydocker.factories;

import com.codingbc.runmydocker.models.UserApplication;

public interface ContainerCreationStrategy {
  void createContainer(UserApplication userApplication);
}

