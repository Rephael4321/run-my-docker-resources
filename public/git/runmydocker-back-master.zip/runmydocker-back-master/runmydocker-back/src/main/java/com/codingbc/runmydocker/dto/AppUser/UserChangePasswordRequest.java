package com.codingbc.runmydocker.dto.AppUser;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class UserChangePasswordRequest {
  @JsonIgnore private String username;

  @JsonProperty("password")
  private String newPassword;
}
