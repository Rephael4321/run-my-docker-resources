/*
 * Copyright (c) 2024.
 */

package com.codingbc.runmydocker.events.Docker;

import com.codingbc.runmydocker.events.EventPublisher;
import com.codingbc.runmydocker.events.UserApplication.ImagePullCompleteEvent;
import com.codingbc.runmydocker.factories.ContainerCreationStrategyFactory;
import com.codingbc.runmydocker.factories.ContainerCreationStrategy;
import com.codingbc.runmydocker.models.UserApplication;
import com.codingbc.runmydocker.repositories.UserApplicationRepository;
import com.codingbc.runmydocker.services.DockerService;
import com.codingbc.runmydocker.services.UserApplicationService;
import com.github.dockerjava.api.command.CreateContainerResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class DockerEventListener {

  @Autowired
  private UserApplicationRepository userApplicationRepository;

  @Autowired
  private DockerService dockerService;
  @Autowired
  @Lazy
  private UserApplicationService userApplicationService;

  @EventListener
  public void onImagePullCompleted(ImagePullCompleteEvent event) {
    dockerService.onImagePulled(event.getUserApplication());
  }

  @Async
  @EventListener
  public void handleCreateContainerEvent(CreateContainerEvent event) {
    log.info("Create container event received for container: {}", event.getUserApplication().getAppName());
    UserApplication userApplication = event.getUserApplication();
    String dockerImage = userApplication.getDockerImage();

    boolean imgFoundOnLocal = dockerService.isImageAvailableLocally(dockerImage);
    log.info("Docker image found on local? : {}", imgFoundOnLocal);
    ContainerCreationStrategy creationStrategy = ContainerCreationStrategyFactory.getFactory(
        imgFoundOnLocal,
        dockerService);

    creationStrategy.createContainer(userApplication);
  }

  @EventListener
  public void handleContainerCreatedEvent(ContainerCreatedEvent event) {
    CreateContainerResponse createContainerResponse = event.getCreateContainerResponse();
    UserApplication application = event.getApplication();
    log.info("Container created event received for container: {}", application.getAppName());

    userApplicationService.onDockerContainerCreated(createContainerResponse, application);
  }

  @EventListener
  public void hadleContainerStartedEvent(ContainerStartedEvent event) {
    userApplicationService.onAppStarted(event.getAppName());
  }

  @EventListener
  public void handleContainerDeletedForUpdateEvent(ContainerDeletedForUpdateEvent event) {
    String appName = event.getApplication().getAppName();
    log.info("Container Deleted for update event received for container: {}", appName);
    UserApplication application = event.getApplication();
    application.setContainerId(null);
    userApplicationRepository.save(application);

    EventPublisher.publishCreateContainerEvent(application);

  } // for update event, need to implement
}
