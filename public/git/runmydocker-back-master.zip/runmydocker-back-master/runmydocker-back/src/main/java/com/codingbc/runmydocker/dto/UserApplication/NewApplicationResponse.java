package com.codingbc.runmydocker.dto.UserApplication;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class NewApplicationResponse {

    private long id;

    private String name;

    private String url;
}
