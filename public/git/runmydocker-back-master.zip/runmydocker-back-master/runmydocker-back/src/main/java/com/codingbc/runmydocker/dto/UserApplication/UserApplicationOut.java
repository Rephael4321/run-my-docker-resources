/*
 * Copyright (c) 2024.
 */

package com.codingbc.runmydocker.dto.UserApplication;

import com.codingbc.runmydocker.enums.ContainerCreationStatus;
import com.codingbc.runmydocker.util.Dates;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Date;
import lombok.Data;
import org.joda.time.LocalDateTime;

@Data
public class UserApplicationOut {

  private Long Id;
  private String dockerImage;
  private String appName;
  private String mappingPort;
  private String username;
  private Date createdAt;
  private Date updatedAt;
  private boolean isRunning;
  private int remainingTime;
  private StatusInfo statusInfo;

  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
  @JsonProperty("createdAt")
  public LocalDateTime formatCreatedAt() {
    return Dates.atLocalTime(createdAt);
  }

  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
  @JsonProperty("updatedAt")
  public LocalDateTime formatUpdatedAt() {
    return Dates.atLocalTime(updatedAt);
  }

  @Data
  public static class StatusInfo {
    private ContainerCreationStatus status;
    private String error;
  }
}
