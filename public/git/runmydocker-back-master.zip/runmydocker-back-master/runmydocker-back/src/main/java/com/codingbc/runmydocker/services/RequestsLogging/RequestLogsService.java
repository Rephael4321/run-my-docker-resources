package com.codingbc.runmydocker.services.RequestsLogging;

import com.codingbc.runmydocker.models.RequestLog;
import com.codingbc.runmydocker.repositories.RequestLogRepository;
import java.util.UUID;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

@Service
@Qualifier("RequestLogsService")
public class RequestLogsService implements IRequestLogsService {

  @Autowired private RequestLogRepository requestLogRepository;

  @Override
  public RequestLog save(RequestLog requestLog) {
    return requestLogRepository.saveAndFlush(requestLog);
  }

  @Override
  public RequestLog findByRequestId(UUID requestId) {
    return requestLogRepository.findByRequestId(requestId);
  }

  @Override
  public RequestLog update(RequestLog requestLog) {
    return requestLogRepository.saveAndFlush(requestLog);
  }
}
