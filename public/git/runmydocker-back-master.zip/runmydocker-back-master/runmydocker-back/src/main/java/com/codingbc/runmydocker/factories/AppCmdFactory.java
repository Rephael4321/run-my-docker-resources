/*
 * Copyright (c) 2024.
 */

package com.codingbc.runmydocker.factories;

import com.codingbc.runmydocker.commands.UserApplication.BaseAppCmd;
import com.codingbc.runmydocker.commands.UserApplication.ChangeAppVersionCmd;
import com.codingbc.runmydocker.commands.UserApplication.DeleteAppCmd;
import com.codingbc.runmydocker.commands.UserApplication.StartAppCmd;
import com.codingbc.runmydocker.commands.UserApplication.StopAppCmd;
import com.codingbc.runmydocker.dto.UserApplication.ApplicationActionRequest;
import com.codingbc.runmydocker.enums.AppActions;
import com.codingbc.runmydocker.exceptions.BadRequest;
import com.codingbc.runmydocker.repositories.UserApplicationRepository;
import com.codingbc.runmydocker.services.DockerService;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class AppCmdFactory {

  public static BaseAppCmd getCmd(AppActions action, DockerService dockerService,
      UserApplicationRepository userApplicationRepository,
      ApplicationActionRequest actionRequest) {
    switch (action) {
      case START:
        return new StartAppCmd(dockerService, userApplicationRepository, actionRequest);
      case STOP:
        return new StopAppCmd(dockerService, userApplicationRepository, actionRequest);
      case DELETE:
        return new DeleteAppCmd(dockerService, userApplicationRepository, actionRequest);
      case CHANGE_VERSION:
        return new ChangeAppVersionCmd(dockerService, userApplicationRepository, actionRequest);
      default:
        log.info("Action {} not found.", action);
        throw new BadRequest("Invalid action");

    }
  }

}
