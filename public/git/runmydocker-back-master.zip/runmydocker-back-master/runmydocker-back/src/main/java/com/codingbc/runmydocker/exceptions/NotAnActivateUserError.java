package com.codingbc.runmydocker.exceptions;

import java.util.Map;
import org.springframework.http.HttpStatus;

public class NotAnActivateUserError extends BaseException {


  public NotAnActivateUserError() {
    super(HttpStatus.UNAUTHORIZED, "User is not activated", null);
  }

  public NotAnActivateUserError(String message) {
    super(HttpStatus.UNAUTHORIZED, message, null);
  }

  public NotAnActivateUserError(String message, Map<String, Object> additionalInfo) {
    super(HttpStatus.UNAUTHORIZED, message, additionalInfo);
  }
}
