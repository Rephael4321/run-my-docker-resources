package com.codingbc.runmydocker.exceptions;

import java.util.HashMap;
import java.util.Map;
import lombok.Getter;
import lombok.Setter;
import org.springframework.http.HttpStatus;

@Getter
@Setter
public class ValidationError extends BaseException {
  private Map<String, String> validationsError;

  public ValidationError(HttpStatus status) {
    super(status, "Validation Error", null);
  }

  public void addValidationError(String fieldName, String errorMessage) {
    if (validationsError == null) {
      validationsError = new HashMap<>();
    }
    validationsError.put(fieldName, errorMessage);
  }
}
