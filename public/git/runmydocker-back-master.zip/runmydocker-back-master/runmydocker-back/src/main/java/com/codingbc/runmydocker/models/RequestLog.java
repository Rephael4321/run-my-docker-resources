package com.codingbc.runmydocker.models;

import com.codingbc.runmydocker.BaseEntity;
import io.hypersistence.utils.hibernate.type.json.JsonBinaryType;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.Map;
import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;

@Entity
@Table(name = "request_logs")
@Getter
@Setter
@TypeDef(name = "jsonb", typeClass = JsonBinaryType.class) // Hibernate JSONB support
public class RequestLog extends BaseEntity {

  @Column(name = "request_id", nullable = false)
  private UUID requestId;

  @Column(name = "request_url", nullable = false)
  private String requestUrl;

  @Column(name = "method", nullable = false)
  private String method;

  @Column(name = "success")
  private boolean success;

  @Column(name = "client_ip", nullable = false)
  private String clientIp;

  @Column(name = "username")
  private String username;

  @Column(name = "timestamp", nullable = false)
  private LocalDateTime timestamp;

  @Type(type = "jsonb")
  @Column(name = "request_body", columnDefinition = "jsonb")
  private Map<String, Object> requestBody;

  @Type(type = "jsonb")
  @Column(name = "response_body", columnDefinition = "jsonb")
  private Map<String, Object> responseBody;

  @Type(type = "jsonb")
  @Column(name = "query_params", columnDefinition = "jsonb")
  private Map<String, Object> queryParams;

  @Column(name = "status_code")
  private int statusCode;

  public RequestLog() {}

  @PrePersist
  @PreUpdate
  public void prePersist() {
    if (requestBody == null) {
      requestBody = Collections.emptyMap();
    }
    if (responseBody == null) {
      responseBody = Collections.emptyMap();
    }
    if (queryParams == null) {
      queryParams = Collections.emptyMap();
    }
  }
}
