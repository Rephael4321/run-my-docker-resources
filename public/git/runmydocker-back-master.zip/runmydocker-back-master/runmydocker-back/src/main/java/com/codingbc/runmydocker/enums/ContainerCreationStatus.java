/*
 * Copyright (c) 2024.
 */

package com.codingbc.runmydocker.enums;

public enum ContainerCreationStatus {
  PENDING,
  CREATING,
  CREATED,
  FAILED,
  UNHEALTHY,
  IN_PROGRESS,
}
