/*
 * Copyright (c) 2024.
 */

package com.codingbc.runmydocker.security.OAuth2;

import com.codingbc.runmydocker.builders.OAuth2UserCreateDTOBuilder;
import com.codingbc.runmydocker.builders.UserBuilder;
import com.codingbc.runmydocker.configuration.OAuth2Config;
import com.codingbc.runmydocker.dto.AppUser.OAuth2UserCreateDTO;
import com.codingbc.runmydocker.exceptions.GeneralError;
import com.codingbc.runmydocker.models.User;
import com.codingbc.runmydocker.repositories.UserRepository;
import com.codingbc.runmydocker.security.OAuth2.OAuthUserInfo.OAuth2UserInfo;
import com.codingbc.runmydocker.security.OAuth2.OAuthUserInfo.OAuth2UserInfoFactory;
import com.codingbc.runmydocker.security.OAuth2.OAuthUserInfo.eRegistrationId;
import com.codingbc.runmydocker.services.UserService;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Lazy;
import org.springframework.security.authentication.InternalAuthenticationServiceException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.client.userinfo.DefaultOAuth2UserService;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserRequest;
import org.springframework.security.oauth2.core.OAuth2AuthenticationException;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

@Service
@Slf4j
public class CustomOAuth2UserService extends DefaultOAuth2UserService {
  private final UserRepository userRepository;
  private final UserService userService;
  private final PasswordEncoder passwordEncoder;

  private final OAuth2Config oAuth2Config;

  public CustomOAuth2UserService(
      UserRepository userRepository,
      @Lazy UserService userService,
      PasswordEncoder passwordEncoder,
      OAuth2Config oAuth2Config) {
    this.userRepository = userRepository;
    this.userService = userService;
    this.passwordEncoder = passwordEncoder;
    this.oAuth2Config = oAuth2Config;
  }

  @Override
  public OAuth2User loadUser(OAuth2UserRequest userRequest) throws OAuth2AuthenticationException {
    OAuth2User oAuth2User = super.loadUser(userRequest);
    try {
      return processOAuth2User(userRequest, oAuth2User);
    } catch (Exception ex) {
      throw new InternalAuthenticationServiceException(ex.getMessage(), ex.getCause());
    }
  }

  private OAuth2UserInfo getOAuth2UserInfo(OAuth2UserRequest request, OAuth2User oAuth2User) {
    String registrationId = request.getClientRegistration().getRegistrationId();
    Map<String, Object> attributes = oAuth2User.getAttributes();

    return OAuth2UserInfoFactory.getUserInfo(registrationId, attributes);
  }

  private void validateOAuthUserEmail(String email, String registrationId) {
    if (!StringUtils.hasText(email)
        && registrationId.equalsIgnoreCase(eRegistrationId.GOOGLE.getValue())) {
      throw new GeneralError("Email is not presented on OAuth2 provider");
    }
  }

  private OAuth2User processOAuth2User(OAuth2UserRequest request, OAuth2User oAuth2User) {
    OAuth2UserInfo userInfo = getOAuth2UserInfo(request, oAuth2User);
    String email = userInfo.getEmail();
    validateOAuthUserEmail(email, request.getClientRegistration().getRegistrationId());

    User user =
        userRepository
            .findByUsername(email)
            .map(existingUser -> updateExistingUser(existingUser, userInfo))
            .orElseGet(() -> registerNewUser(userInfo));

    return UserPrincipal.create(user, oAuth2User.getAttributes());
  }

  private User updateExistingUser(User user, OAuth2UserInfo userInfo) {
    user.setProviderId(userInfo.getId());
    return userRepository.save(user);
  }

  private User registerNewUser(OAuth2UserInfo userInfo) {
    //    User user =
    //        UserBuilder.builder()
    //            .username(userInfo.getEmail())
    //            .providerId(userInfo.getId())
    //            .password(passwordEncoder.encode(oAuth2Config.getAuth().getOauth2UserPassword()))
    //            .isActivated(false)
    //            .registrationCompleted(false)
    //            .build();
    //    return userRepository.save(user);

    OAuth2UserCreateDTO dto =
        OAuth2UserCreateDTOBuilder.anOAuth2UserCreateDTO()
            .withUsername(userInfo.getEmail())
            .withPassword(oAuth2Config.getAuth().getOauth2UserPassword())
            .withProviderId(userInfo.getId())
            //            .withRegistrationCompleted(false)
            //            .withActivated(false)
            .build();

    return userService.create(dto);
  }
}
