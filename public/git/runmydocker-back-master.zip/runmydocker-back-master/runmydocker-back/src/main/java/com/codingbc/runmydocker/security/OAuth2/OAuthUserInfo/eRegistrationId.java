/*
 * Copyright (c) 2024.
 */

package com.codingbc.runmydocker.security.OAuth2.OAuthUserInfo;

public enum eRegistrationId {
  GOOGLE("google"),
  GITHUB("github");

  private final String value;

  eRegistrationId(String value) {
    this.value = value;
  }

  public String getValue() {
    return value;
  }
}
