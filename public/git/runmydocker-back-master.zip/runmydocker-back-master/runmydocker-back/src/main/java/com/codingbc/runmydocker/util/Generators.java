/*
 * Copyright (c) 2024.
 */

package com.codingbc.runmydocker.util;

import java.util.Random;

public class Generators {

  public static int generatePort() {
    Random random = new Random();
    final int low = 1024;
    final int high = 49151;
    return random.nextInt(high - low) + low;
  }
}
