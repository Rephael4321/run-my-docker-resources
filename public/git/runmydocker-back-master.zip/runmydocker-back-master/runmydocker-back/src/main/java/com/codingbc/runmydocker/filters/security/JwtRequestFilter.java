package com.codingbc.runmydocker.filters.security;

import com.codingbc.runmydocker.security.CustomUserDetailsService;
import com.codingbc.runmydocker.util.JwtTokenUtil;
import io.jsonwebtoken.ExpiredJwtException;
import java.io.IOException;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

@Component
@Slf4j
public class JwtRequestFilter extends OncePerRequestFilter {
  private static final String AUTH_HEADER = "Authorization";
  private static final String BEARER_PREFIX = "Bearer ";
  private final CustomUserDetailsService customUserDetailsService;
  private final JwtTokenUtil jwtTokenUtil;

  public JwtRequestFilter(
      CustomUserDetailsService customUserDetailsService, JwtTokenUtil jwtTokenUtil) {
    this.customUserDetailsService = customUserDetailsService;
    this.jwtTokenUtil = jwtTokenUtil;
  }

  @Override
  protected void doFilterInternal(
      HttpServletRequest httpServletRequest,
      HttpServletResponse httpServletResponse,
      FilterChain filterChain)
      throws ServletException, IOException {
    if (shouldSkipFilter(httpServletRequest)) {
      filterChain.doFilter(httpServletRequest, httpServletResponse);
      return;
    }

    String token = extractTokenFromHeader(httpServletRequest.getHeader(AUTH_HEADER));
    if (token != null) {
      String username = extractUsername(token);
      if (username != null && SecurityContextHolder.getContext().getAuthentication() == null) {
        validateAndSetAuthentication(username, token, httpServletRequest);
      }
    }

    filterChain.doFilter(httpServletRequest, httpServletResponse);
  }

  private boolean shouldSkipFilter(HttpServletRequest request) {
    String path = request.getServletPath();
    return path.startsWith("/api/auth/")
        || path.equals("/login")
        || path.equals("/register")
        || path.equals("/loginGoogle")
        || path.equals("/googleRegister");
  }

  private String extractTokenFromHeader(String authHeader) {
    if (authHeader != null && authHeader.startsWith(BEARER_PREFIX)) {
      return authHeader.substring(BEARER_PREFIX.length());
    }
    return null;
  }

  private String extractUsername(String token) {
    try {
      return jwtTokenUtil.getUsernameFromToken(token);
    } catch (ExpiredJwtException e) {
      log.error("Token expired: {}", e.getMessage());
      return null;
    }
  }

  private void validateAndSetAuthentication(
      String username, String token, HttpServletRequest request) {
    UserDetails userDetails = customUserDetailsService.loadUserByUsername(username);
    if (jwtTokenUtil.validateToken(token, userDetails)) {
      UsernamePasswordAuthenticationToken authenticationToken =
          new UsernamePasswordAuthenticationToken(userDetails, null, userDetails.getAuthorities());
      request.setAttribute("username", username);
      SecurityContextHolder.getContext().setAuthentication(authenticationToken);
    }
  }
}
