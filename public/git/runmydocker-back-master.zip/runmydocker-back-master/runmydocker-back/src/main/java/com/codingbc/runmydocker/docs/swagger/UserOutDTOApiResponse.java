package com.codingbc.runmydocker.docs.swagger;

import com.codingbc.runmydocker.dto.AppUser.UserOutDTO;
import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = true)
@Data
public class UserOutDTOApiResponse extends BaseResponseModal {
    private UserOutDTO data;
}
