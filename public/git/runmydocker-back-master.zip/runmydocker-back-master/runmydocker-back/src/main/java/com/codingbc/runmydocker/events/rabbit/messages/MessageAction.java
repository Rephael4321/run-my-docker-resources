package com.codingbc.runmydocker.events.rabbit.messages;

public enum MessageAction {
  USER_REGISTERED("user_registered"),
  USER_LOGGED_IN("user_logged_in"),
  LOGOUT("logout"),
  DELETE("delete"),
  CREATE_CONTAINER("create_container"),
  CONTAINER_CREATED("container_created");

  private final String value;

  MessageAction(String value) {
    this.value = value;
  }

    public String getValue() {
        return value;
    }
}
