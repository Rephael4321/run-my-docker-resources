package com.codingbc.runmydocker.models;

import com.codingbc.runmydocker.events.rabbit.messages.MessageAction;
import com.codingbc.runmydocker.util.Dates;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.hypersistence.utils.hibernate.type.json.JsonBinaryType;
import lombok.*;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.jetbrains.annotations.NotNull;
import org.joda.time.LocalDateTime;

import javax.persistence.*;
import java.util.Date;
import java.util.UUID;

@Slf4j
@Table(
        name = "messages",
        indexes = {
                @Index(name = "idx_appmessage_message_id_unq", columnList = "message_id", unique = true)
        })
@TypeDef(name = "jsonb", typeClass = JsonBinaryType.class)
@Entity
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AppMessage {

  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  @JsonProperty("id")
  @JsonFormat(shape = JsonFormat.Shape.STRING)
  private UUID id;

  @Column(nullable = false, name = "message_id")
  @JsonProperty("messageId")
  @JsonFormat(shape = JsonFormat.Shape.STRING)
  private UUID messageId;

  @Column(nullable = false)
  private String type;

  @Column(nullable = false, name = "is_read")
  private boolean isRead;

  @Column(nullable = false, name = "created_at")
  @NotNull
  private final Date createdAt = Dates.nowUTC();

  @Column(nullable = false, name = "username")
  private String username;

  @Type(type = "jsonb")
  @Column(nullable = false, name = "payload", columnDefinition = "jsonb")
  private Object payload;

  @Column(nullable = false, name = "action")
  @Enumerated(EnumType.STRING)
  private MessageAction action;

  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
  @JsonProperty("createdAt")
  public LocalDateTime calcCreatedAt() {
    return Dates.atLocalTime(createdAt);
  }

  @PostPersist
  public void postPersist() {
    log.info("[AppMessage] Message persisted: {}", this);
  }
}