package com.codingbc.runmydocker.events.Auth;

import com.codingbc.runmydocker.models.ActivationCode;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import org.springframework.context.ApplicationEvent;

@Getter
@Setter
public class SendCodeEvent extends ApplicationEvent {
  private ActivationCode activationCode;

  public SendCodeEvent(Object source, ActivationCode activationCode) {
    super(source);
    this.activationCode = activationCode;
  }
}
