package com.codingbc.runmydocker.dto.migrations;

import com.codingbc.runmydocker.util.Dates;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import org.jetbrains.annotations.PropertyKey;
import org.joda.time.LocalDateTime;
import org.json.JSONPropertyName;

import java.util.Date;

@Data
public class OldUserDTO {
    private int id;
    @JsonProperty("created_at")
    private  Date createdAt = Dates.nowUTC();
    @JsonProperty("first_name")
    private String firstName;
    @JsonProperty("is_activated")
    private boolean isActivated;
    @JsonProperty("last_name")
    private String lastName;
    private String password;
    private String phone;
    private String username;
    @JsonProperty("google_id")
    private String googleId;
    private String provider;
    @JsonProperty("provider_id")
    private String providerId;
    @JsonProperty("registration_completed")
    private boolean registrationCompleted;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonProperty("created_at")
    public LocalDateTime calcCreatedAt() {
        return Dates.atLocalTime(createdAt);
    }
}