package com.codingbc.runmydocker.dto.migrations;

import com.codingbc.runmydocker.util.Dates;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.Date;

@Data
public class ContainerInfo {
    private int id;
    @JsonProperty("app_name")
    private String appName;
    @JsonProperty("container_id")
    private String containerId;
    @JsonProperty("created_at")
    private Date createdAt = Dates.nowUTC();
    @JsonProperty("docker_image")
    private String dockerImage;
    @JsonProperty("is_running")
    private boolean isRunning;
    @JsonProperty("mapping_port")
    private String mappingPort;
    private int port;
    @JsonProperty("remaining_time")
    private int remainingTime;
    @JsonProperty("updated_at")
    private Date updatedAt;
    private String username;
    @JsonProperty("user_id")
    private int userId;
    @JsonProperty("minikube_app")
    private String minikubeApp;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonProperty("created_at")
    public org.joda.time.LocalDateTime calcCreatedAt() {
        return Dates.atLocalTime(createdAt);
    }

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonProperty("updated_at")
    public org.joda.time.LocalDateTime calcUpdatedAt() {
        return Dates.atLocalTime(updatedAt);
    }



    @Override
    public String toString() {
        return "ContainerInfo{" +
                "id=" + id +
                ", appName='" + appName + '\'' +
                ", containerId='" + containerId + '\'' +
                ", createdAt=" + createdAt +
                ", dockerImage='" + dockerImage + '\'' +
                ", isRunning=" + isRunning +
                ", mappingPort='" + mappingPort + '\'' +
                ", port=" + port +
                ", remainingTime=" + remainingTime +
                ", updatedAt=" + updatedAt +
                ", username='" + username + '\'' +
                ", userId=" + userId +
                ", minikubeApp='" + minikubeApp + '\'' +
                '}';
    }
}