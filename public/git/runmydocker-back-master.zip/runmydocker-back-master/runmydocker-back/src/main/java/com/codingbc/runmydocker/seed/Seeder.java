package com.codingbc.runmydocker.seed;

import com.codingbc.runmydocker.builders.UserBuilder;
import com.codingbc.runmydocker.models.User;
import com.codingbc.runmydocker.models.UserApplication;
import com.codingbc.runmydocker.repositories.ActivationCodeRepository;
import com.codingbc.runmydocker.repositories.UserApplicationRepository;
import com.codingbc.runmydocker.repositories.UserRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

//@Component
@Slf4j
public class Seeder implements CommandLineRunner {

  private final UserRepository userRepository;
  private final UserApplicationRepository userApplicationRepository;
  private final ActivationCodeRepository activationCodeRepository;
  private final PasswordEncoder passwordEncoder;

  public Seeder(UserRepository userRepository, UserApplicationRepository userApplicationRepository,
      ActivationCodeRepository activationCodeRepository, PasswordEncoder passwordEncoder) {
    this.userRepository = userRepository;
    this.userApplicationRepository = userApplicationRepository;
    this.activationCodeRepository = activationCodeRepository;
    this.passwordEncoder = passwordEncoder;

  }

  private void createUser() {
    User user =
        UserBuilder.builder()
            .username("natan@gmail.com")
            .password(passwordEncoder.encode("Natan1997"))
            .phone("972546594945")
            .firstName("Natan")
            .lastName("Gershbein")
            .isActivated(true)
            .registrationCompleted(true)
            .build();
    userRepository.saveAndFlush(user);
    log.info(user.toString());

  }

  @Override
  public void run(String... args) throws Exception {
//    userRepository.deleteAll();
    System.out.println("Seeding data");
    try {
      createUser();
    } catch (Exception e) {
      log.error("Error seeding data: {}", e.getMessage());
    }
  }
}
