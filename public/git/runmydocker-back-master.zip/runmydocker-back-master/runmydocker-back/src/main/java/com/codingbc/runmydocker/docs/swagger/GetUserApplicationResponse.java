package com.codingbc.runmydocker.docs.swagger;

import com.codingbc.runmydocker.dto.UserApplication.UserApplicationOut;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = true)
@Data
public class GetUserApplicationResponse extends BaseResponseModal {
  private List<UserApplicationOut> data;
}
