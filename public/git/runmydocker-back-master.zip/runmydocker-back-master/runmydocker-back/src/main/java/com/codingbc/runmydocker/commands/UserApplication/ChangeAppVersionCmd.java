package com.codingbc.runmydocker.commands.UserApplication;

import com.codingbc.runmydocker.dto.UserApplication.ApplicationActionRequest;
import com.codingbc.runmydocker.dto.UserApplication.ChangeVersionRequest;
import com.codingbc.runmydocker.events.EventPublisher;
import com.codingbc.runmydocker.exceptions.BadRequest;
import com.codingbc.runmydocker.models.UserApplication;
import com.codingbc.runmydocker.repositories.UserApplicationRepository;
import com.codingbc.runmydocker.services.DockerService;
import com.codingbc.runmydocker.util.AppActionsValidationUtils;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ChangeAppVersionCmd extends BaseAppCmd {

  public ChangeAppVersionCmd(DockerService dockerService,
      UserApplicationRepository userApplicationRepository, ApplicationActionRequest actionRequest) {
    super(dockerService, userApplicationRepository, actionRequest);
  }

  @Override
  protected void validateState(UserApplication userApplication) {
    AppActionsValidationUtils.validateAppCanChangeVersion(userApplication, dockerService);
  }

  private UserApplication updateNewVersionInfo(UserApplication oldApplication,
      ChangeVersionRequest versionNewInfo) {
    oldApplication.setDockerImage(versionNewInfo.getDockerImage());
    oldApplication.setContainerPort(versionNewInfo.getContainerPort());
    return userApplicationRepository.saveAndFlush(oldApplication);
  }

  private void removeOldContainer(UserApplication updatedApplication) {
    dockerService.removeContainer(updatedApplication.getAppName());
    EventPublisher.publishContainerDeletedForUpdateEvent(updatedApplication);
  }


  private void validateChangeRequestInfo(UserApplication userApplication,
      ChangeVersionRequest request) {
    boolean isTheSameImage = userApplication.getDockerImage().equals(request.getDockerImage());
    boolean isTheSamePort = userApplication.getContainerPort() == request.getContainerPort();

    if (isTheSameImage && isTheSamePort) {
      throw new BadRequest("New version is the same as the current version");
    }
  }

  private void handleFailedApp(UserApplication userApplication,
      ChangeVersionRequest changeVersionRequest) {
    log.warn(
        "Application is in failed state. Proceeding to update version without removing old container");
    updateNewVersionInfo(userApplication, changeVersionRequest);
    EventPublisher.publishCreateContainerEvent(userApplication);
  }

  private void updateVersion(UserApplication userApplication) {
    ChangeVersionRequest changeVersionRequest = (ChangeVersionRequest) actionRequest;
    validateChangeRequestInfo(userApplication, changeVersionRequest);

    if (isAppFailedToCreate(userApplication)) {
      handleFailedApp(userApplication, changeVersionRequest);
      return;
    }
    validateState(userApplication);

    UserApplication updatedApplication = updateNewVersionInfo(userApplication,
        changeVersionRequest);
    removeOldContainer(updatedApplication);
  }


  @Override
  public void execute() {
    UserApplication userApplication = findByAppIdAndAppName();
    updateVersion(userApplication);
  }
}