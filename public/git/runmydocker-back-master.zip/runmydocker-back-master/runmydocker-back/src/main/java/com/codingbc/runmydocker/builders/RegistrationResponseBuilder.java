package com.codingbc.runmydocker.builders;

import com.codingbc.runmydocker.dto.AppUser.UserOutDTO;
import com.codingbc.runmydocker.dto.auth.RegistrationResponse;

public final class RegistrationResponseBuilder {

  private RegistrationResponse registrationResponse;

  public RegistrationResponseBuilder() {
    registrationResponse = new RegistrationResponse();
  }

  public RegistrationResponseBuilder(RegistrationResponse other) {
    this.registrationResponse = other;
  }

  public static RegistrationResponseBuilder aRegistrationResponse() {
    return new RegistrationResponseBuilder();
  }

  public RegistrationResponseBuilder withUser(UserOutDTO user) {
    registrationResponse.setUser(user);
    return this;
  }

  public RegistrationResponseBuilder withUuid(String uuid) {
    registrationResponse.setUuid(uuid);
    return this;
  }

  public RegistrationResponse build() {
    return registrationResponse;
  }
}
