/*
 * Copyright (c) 2024.
 */

package com.codingbc.runmydocker.controllers;

import com.codingbc.runmydocker.configuration.OAuth2Config;
import com.codingbc.runmydocker.exceptions.GeneralError;
import com.codingbc.runmydocker.models.User;
import com.codingbc.runmydocker.repositories.UserRepository;
import com.codingbc.runmydocker.util.JwtTokenUtil;
import java.util.Optional;
import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@RestController
@Slf4j
public class OAuth2LoginController {
  @Value("${app.frontend.baseurl}")
  private String BASE_URL;

  private String SUCCESS_REDIRECT_URL_GOOGLE;
  private String COMPLETE_REGISTRATION_URL_GOOGLE;

  private final OAuth2Config auth2Config;
  private final JwtTokenUtil jwtTokenUtil;
  private final UserRepository userRepository;

  public OAuth2LoginController(
      OAuth2Config auth2Config, JwtTokenUtil jwtTokenUtil, UserRepository userRepository) {
    this.auth2Config = auth2Config;
    this.jwtTokenUtil = jwtTokenUtil;
    this.userRepository = userRepository;
  }

  @PostConstruct
  public void init() {
    this.SUCCESS_REDIRECT_URL_GOOGLE = BASE_URL + "/dologin-google?token=";
    this.COMPLETE_REGISTRATION_URL_GOOGLE = BASE_URL + "/dologin-google?id=";
  }

  private ModelAndView handleGoogleLogin(String token) {
    if (!StringUtils.hasText(token)) throw new GeneralError("Token is not presented");

    if (!jwtTokenUtil.validateToken(token))
      throw new GeneralError("invalid token or user not found");

    String username = jwtTokenUtil.getUsernameFromToken(token);
    Optional<User> optionalUser = userRepository.findByUsername(username);

    if (optionalUser.isEmpty()) {
      throw new GeneralError("invalid token or user not found");
    }

    User user = optionalUser.get();
    if (!user.isRegistrationCompleted() || !user.isActivated()) {
      return new ModelAndView("redirect:" + COMPLETE_REGISTRATION_URL_GOOGLE + user.getId());
    }

    Authentication authentication =
        new UsernamePasswordAuthenticationToken(
            user.getUsername(), auth2Config.getAuth().getOauth2UserPassword());

    String successfulLoginToken = jwtTokenUtil.generateToken(authentication);
    return new ModelAndView("redirect:" + SUCCESS_REDIRECT_URL_GOOGLE + successfulLoginToken);
  }

  @GetMapping("/google")
  public ModelAndView index(
      HttpServletRequest request, Model model, @RequestParam(required = false) String token) {
    return handleGoogleLogin(token);

    //    if (StringUtils.hasText(token)) {
    //      jwtTokenUtil.validateToken(token);
    //      String username = jwtTokenUtil.getUsernameFromToken(token);
    //      Optional<User> optionalUser = userRepository.findByUsername(username);
    //
    //      if (optionalUser.isPresent()) {
    //        User user = optionalUser.get();
    //        if (!user.isRegistrationCompleted() || !user.isActivated()) {
    //          return new ModelAndView("redirect:" + COMPLETE_REGISTRATION_URL_GOOGLE +
    // user.getId());
    //        }
    //
    //        Authentication authentication =
    //            new UsernamePasswordAuthenticationToken(
    //                user.getUsername(), auth2Config.getAuth().getOauth2UserPassword());
    //
    //        String successfulLoginToken = jwtTokenUtil.generateToken(authentication);
    //        return new ModelAndView("redirect:" + SUCCESS_REDIRECT_URL_GOOGLE +
    // successfulLoginToken);
    //      }
    //    }
    //
    //    throw new GeneralError("invalid token or user not found");
  }
}
