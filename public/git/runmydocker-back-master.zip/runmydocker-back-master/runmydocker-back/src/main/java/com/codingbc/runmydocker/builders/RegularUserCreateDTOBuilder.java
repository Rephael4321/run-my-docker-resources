/*
 * Copyright (c) 2024.
 */

package com.codingbc.runmydocker.builders;

import com.codingbc.runmydocker.dto.AppUser.RegularUserCreateDTO;

public final class RegularUserCreateDTOBuilder {

  private RegularUserCreateDTO regularUserCreateDTO;

  public RegularUserCreateDTOBuilder() {
    regularUserCreateDTO = new RegularUserCreateDTO();
  }

  public RegularUserCreateDTOBuilder(RegularUserCreateDTO other) {
    this.regularUserCreateDTO = other;
  }

  public static RegularUserCreateDTOBuilder aRegularUserCreateDTO() {
    return new RegularUserCreateDTOBuilder();
  }

  public RegularUserCreateDTOBuilder withFirstName(String firstName) {
    regularUserCreateDTO.setFirstName(firstName);
    return this;
  }

  public RegularUserCreateDTOBuilder withLastName(String lastName) {
    regularUserCreateDTO.setLastName(lastName);
    return this;
  }

  public RegularUserCreateDTOBuilder withPhone(String phone) {
    regularUserCreateDTO.setPhone(phone);
    return this;
  }

  public RegularUserCreateDTOBuilder withUsername(String username) {
    regularUserCreateDTO.setUsername(username);
    return this;
  }

  public RegularUserCreateDTOBuilder withPassword(String password) {
    regularUserCreateDTO.setPassword(password);
    return this;
  }

  public RegularUserCreateDTO build() {
    return regularUserCreateDTO;
  }
}
