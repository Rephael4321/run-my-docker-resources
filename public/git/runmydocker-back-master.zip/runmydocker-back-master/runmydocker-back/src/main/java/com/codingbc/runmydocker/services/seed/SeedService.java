package com.codingbc.runmydocker.services.seed;

import com.codingbc.runmydocker.models.User;
import com.codingbc.runmydocker.repositories.UserRepository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class SeedService {
  private final UserRepository userRepository;
  private ArrayList<User> users;

  public SeedService(UserRepository userRepository) {
    this.userRepository = userRepository;
    this.users = new ArrayList<>();
  }

  public void truncateUsers() {
    userRepository.deleteAllById(users.stream().map(User::getId).collect(Collectors.toList()));
  }

  public void seedUserForTests() {
    for (int i = 0; i < 2; i++) {
      User user = new User();
      user.setFirstName("test");
      user.setLastName("user");
      user.setUsername(String.format("test-user-%d@gmail.com", i));
      user.setPassword("password");
      user.setPhone("0541111111");
      user.setRegistrationCompleted(true);
      user.setActivated(true);

      try {
        userRepository.saveAndFlush(user);
      } catch (Exception e) {
        System.out.println(e.getMessage());
      }
    }
  }
}
