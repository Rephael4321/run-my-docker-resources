/*
 * Copyright (c) 2024.
 */

package com.codingbc.runmydocker.dto.AppUser;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;

@EqualsAndHashCode(callSuper = true)
@Data
public class OAuth2UserCreateDTO extends UserCreateDTO {

  private String providerId;
  private boolean activated;
  private boolean registrationCompleted;
}
