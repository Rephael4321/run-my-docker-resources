/*
 * Copyright (c) 2024.
 */

package com.codingbc.runmydocker.builders;

import com.codingbc.runmydocker.dto.UserApplication.NewContainerData;

public final class NewContainerDataBuilder {

  private NewContainerData newContainerData;

  public NewContainerDataBuilder() {
    newContainerData = new NewContainerData();
  }

  public NewContainerDataBuilder(NewContainerData other) {
    this.newContainerData = other;
  }

  public static NewContainerDataBuilder aNewContainerData() {
    return new NewContainerDataBuilder();
  }

  public NewContainerDataBuilder withImage(String image) {
    newContainerData.setImage(image);
    return this;
  }

  public NewContainerDataBuilder withContainerName(String containerName) {
    newContainerData.setContainerName(containerName);
    return this;
  }

  public NewContainerDataBuilder withPort(int port) {
    newContainerData.setPort(port);
    return this;
  }

  public NewContainerDataBuilder withContainerPort(int containerPort) {
    newContainerData.setContainerPort(containerPort);
    return this;
  }

  public NewContainerData build() {
    return newContainerData;
  }
}
