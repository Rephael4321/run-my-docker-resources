/*
 * Copyright (c) 2024.
 */

package com.codingbc.runmydocker.commands.UserApplication;

import com.codingbc.runmydocker.dto.UserApplication.ApplicationActionRequest;
import com.codingbc.runmydocker.models.UserApplication;
import com.codingbc.runmydocker.repositories.UserApplicationRepository;
import com.codingbc.runmydocker.services.DockerService;
import com.codingbc.runmydocker.util.AppActionsValidationUtils;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class StopAppCmd extends BaseAppCmd {


  public StopAppCmd(DockerService dockerService,
      UserApplicationRepository userApplicationRepository, ApplicationActionRequest actionRequest) {
    super(dockerService, userApplicationRepository, actionRequest);
  }

  @Override
  public void execute() {
    stopApp();

  }

  @Override
  protected void validateState(UserApplication userApplication) {
    AppActionsValidationUtils.validateAppCanStop(userApplication, dockerService);
  }

  private void stopApp() {
    UserApplication userApplication = findByAppIdAndAppName();
    validateState(userApplication);
    dockerService.stopContainer(userApplication.getAppName());
  }


}
