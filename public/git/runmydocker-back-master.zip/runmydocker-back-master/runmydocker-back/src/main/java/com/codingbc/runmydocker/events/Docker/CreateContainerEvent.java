package com.codingbc.runmydocker.events.Docker;

import com.codingbc.runmydocker.models.UserApplication;
import lombok.Getter;
import org.springframework.context.ApplicationEvent;

@Getter
public class CreateContainerEvent extends ApplicationEvent {
  private final UserApplication userApplication;

  public CreateContainerEvent(Object source, UserApplication userApplication) {
    super(source);
    this.userApplication = userApplication;
  }

}
