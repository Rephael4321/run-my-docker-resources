package com.codingbc.runmydocker.util;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.util.Map;

import com.github.dockerjava.api.exception.DockerException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class JsonUtil {
  @Autowired private ObjectMapper objectMapper;

  public Map<String, Object> parseToMap(String json) {
    try {
      if (json == null || json.isEmpty()) {
        return Map.of();
      }
      return objectMapper.readValue(json, new TypeReference<>() {});
    } catch (IOException e) {
      log.error("Error parsing JSON", e);
      return Map.of();
    }
  }

  public Map<String, Object> parseToMap(Object object) {
    try {
      if (object == null) {
        return Map.of();
      }
      return objectMapper.convertValue(object, new TypeReference<>() {});
    } catch (Exception e) {
      log.error("Error parsing JSON", e);
      return Map.of();
    }
  }

  public String parseToJsonString(Object object) {
    try {
      return objectMapper.writeValueAsString(object);
    } catch (Exception e) {
      log.error("Error parsing JSON", e);
      throw new RuntimeException("Error parsing JSON", e);
    }
  }

  public <T> T parseToJson(String json, Class<T> clazz) {
    try {
      return objectMapper.readValue(json, clazz);
    } catch (IOException e) {
      log.error("Error parsing JSON", e);
      throw new RuntimeException("Error parsing JSON", e);
    }
  }
}
