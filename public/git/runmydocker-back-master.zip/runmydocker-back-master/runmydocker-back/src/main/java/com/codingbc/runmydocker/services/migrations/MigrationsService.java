package com.codingbc.runmydocker.services.migrations;

import com.codingbc.runmydocker.builders.UserBuilder;
import com.codingbc.runmydocker.controllers.UserApplicationController;
import com.codingbc.runmydocker.dto.UserApplication.UserApplicationCreateDTO;
import com.codingbc.runmydocker.dto.migrations.ContainerInfo;
import com.codingbc.runmydocker.dto.migrations.OldUserDTO;
import com.codingbc.runmydocker.models.User;
import com.codingbc.runmydocker.models.UserApplication;
import com.codingbc.runmydocker.models.migrations.UserApplicationToMigrate;
import com.codingbc.runmydocker.repositories.UserApplicationRepository;
import com.codingbc.runmydocker.repositories.UserApplicationToMigrateRepository;
import com.codingbc.runmydocker.repositories.UserRepository;
import com.codingbc.runmydocker.services.DockerService;
import com.codingbc.runmydocker.services.UserApplicationService;
import com.codingbc.runmydocker.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.transaction.Transactional;
import java.io.IOException;
import java.util.*;

@Service
public class MigrationsService {
  private final JsonService jsonService;
  private final UserRepository userRepository;
  private final DockerService dockerService;
  private UserApplicationController userApplicationController;
  private final UserApplicationToMigrateRepository userApplicationToMigrateRepository;
  @Autowired private UserApplicationService userApplicationService;
    @Autowired
    private UserApplicationRepository userApplicationRepository;

    public MigrationsService(
      JsonService jsonService,
      UserRepository userRepository,
      DockerService dockerService,
      UserApplicationToMigrateRepository userApplicationToMigrateRepository) {
    this.jsonService = jsonService;
    this.userRepository = userRepository;
    this.dockerService = dockerService;
    this.userApplicationToMigrateRepository = userApplicationToMigrateRepository;
  }

  @Transactional
  public Map<?, ?> migrateContainersData(MultipartFile file) throws IOException {
    List<ContainerInfo> containerInfos = jsonService.parseContainers(file);
    List<ContainerInfo> userApplicationsToCreate = new ArrayList<>();
    List<ContainerInfo> userApplicationsToSkip = new ArrayList<>();
    List<UserApplicationCreateDTO> userApplicationsDtos = new ArrayList<>();

    containerInfos.parallelStream()
        .forEach(
            containerInfo -> {
              String portMap = containerInfo.getMappingPort();
              String dockerImage = containerInfo.getDockerImage();
              String appName = containerInfo.getAppName();
              String username = containerInfo.getUsername();

              userRepository
                  .findByUsername(username)
                  .ifPresentOrElse(
                      user -> {
                        userApplicationsToCreate.add(containerInfo);
                        UserApplicationCreateDTO userApplicationCreateDTO =
                            new UserApplicationCreateDTO();
                        userApplicationCreateDTO.setDockerImage(dockerImage);
                        userApplicationCreateDTO.setAppName(appName);
                        userApplicationCreateDTO.setContainerPort(Integer.parseInt(portMap));
                        userApplicationCreateDTO.setUsername(username);

                        userApplicationsDtos.add(userApplicationCreateDTO);
                        userApplicationToMigrateRepository.save(
                            UserApplicationToMigrate.toUserApplicationToMigrate(
                                userApplicationCreateDTO));
                        System.out.println(
                            "User found: "
                                + username
                                + " - "
                                + appName
                                + " - "
                                + dockerImage
                                + " - "
                                + portMap);
                      },
                      () -> {
                        userApplicationsToSkip.add(containerInfo);
                        System.out.println("User not found: " + username);
                      });
            });

    return Map.of("to create", userApplicationsDtos, "to skip", userApplicationsToSkip);
  }

  @Transactional
  public Map<?, ?> migrateUsers(MultipartFile file) throws IOException {
    List<OldUserDTO> oldUserDTOS = jsonService.parseOldUsers(file);
    List<OldUserDTO> failedUsers = new ArrayList<>();
    List<OldUserDTO> successUsers = new ArrayList<>();

    oldUserDTOS.parallelStream()
        .forEach(
            oldUserDTO -> {
              boolean success = migrateOldUser(oldUserDTO);
              if (success) {
                successUsers.add(oldUserDTO);
              } else {
                failedUsers.add(oldUserDTO);
              }
            });
    return Map.of("success", successUsers, "failed", failedUsers);

    //    oldUserDTOS.parallelStream()
    //        .forEach(
    //            oldUserDTO -> {
    //              Optional<User> byUsername =
    // userRepository.findByUsername(oldUserDTO.getUsername());
    //
    //              if (byUsername.isEmpty()) {
    //
    //                User user = new User();
    //                // check if username is email
    //                if (oldUserDTO.getUsername().contains("@")) {
    //                  user.setUsername(oldUserDTO.getUsername());
    //                } else {
    //                  System.out.printf(
    //                      "user[%s]-username[%s] is not email%n",
    //                      oldUserDTO.getId(), oldUserDTO.getUsername());
    //
    //                  return;
    //                }
    //                user.setFirstName(oldUserDTO.getFirstName());
    //                user.setActivated(oldUserDTO.isActivated());
    //                user.setLastName(oldUserDTO.getLastName());
    //                user.setPassword(oldUserDTO.getPassword());
    //                user.setPhone(oldUserDTO.getPhone());
    //                user.setProviderId(oldUserDTO.getProviderId());
    //                user.setRegistrationCompleted(oldUserDTO.isRegistrationCompleted());
    //                user.setUsername(oldUserDTO.getUsername());
    //                usernames.add(oldUserDTO.getUsername());
    //                try {
    //
    //                  users.add(user);
    //                } catch (Exception e) {
    //                  System.out.println(user.getUsername() + " error");
    //
    //                  e.printStackTrace();
    //                }
    //              }
    //            });

    //    return usernames;
  }

  public boolean migrateOldUser(OldUserDTO user) {
    User migratedUser =
        UserBuilder.builder()
            .firstName(user.getFirstName())
            .lastName(user.getLastName())
            .password(user.getPassword())
            .phone(user.getPhone())
            .username(user.getUsername())
            .isActivated(user.isActivated())
            .providerId(user.getProviderId())
            .registrationCompleted(user.isRegistrationCompleted())
            .build();
    migratedUser.setOldCreatedAt(user.getCreatedAt().toString());

    boolean isExists = userRepository.existsByUsernameIgnoreCase(user.getUsername());
    if (isExists) {
      return false;
    }
    try {
      userRepository.save(migratedUser);
      return true;
    } catch (Exception e) {
      var reason = e.getMessage();
      System.out.println(
          "[Migration] Error while migrating user: "
              + user.getUsername()
              + "[id: "
              + user.getId()
              + "]"
              + " Reason: "
              + reason);
      return false;
    }
  }

  public void migrateContainer(UserApplicationToMigrate userApplicationToMigrate) {
        dockerService.isContainerExists(userApplicationToMigrate.getAppName());
    System.out.println("Container exists: " + userApplicationToMigrate.getAppName() + " - " + userApplicationToMigrate.getUsername());
//      UserApplication byAppName = userApplicationRepository.findByAppName(userApplicationToMigrate.getAppName())
//              .orElseGet(() -> null);
//      if (byAppName != null) {
//        // remove container
//          dockerService.removeContainer(byAppName.getContainerId());
//          UserApplicationCreateDTO userApplicationCreateDTO = new UserApplicationCreateDTO();
//            userApplicationCreateDTO.setAppName(userApplicationToMigrate.getAppName());
//            userApplicationCreateDTO.setContainerPort(userApplicationToMigrate.getMappingPort());
//            userApplicationCreateDTO.setDockerImage(userApplicationToMigrate.getDockerImage());
//            userApplicationCreateDTO.setUsername(userApplicationToMigrate.getUsername());
//
//          try {
//              UserApplication userApplication = userApplicationService.create(userApplicationCreateDTO);
//              userApplicationToMigrate.setMigrated(true);
//              userApplicationToMigrateRepository.save(userApplicationToMigrate);
//              System.out.println("Container migrated: " + userApplicationToMigrate.getAppName());
//          }
//            catch (Exception e) {
//                userApplicationToMigrate.setFailureReason(e.getMessage());
//                userApplicationToMigrateRepository.save(userApplicationToMigrate);
//                System.out.println("Error while migrating container: " + e.getMessage());
//            }
//
//      } else {
//       try {
//           UserApplicationCreateDTO userApplicationCreateDTO = new UserApplicationCreateDTO();
//           userApplicationCreateDTO.setAppName(userApplicationToMigrate.getAppName());
//           userApplicationCreateDTO.setContainerPort(userApplicationToMigrate.getMappingPort());
//           userApplicationCreateDTO.setDockerImage(userApplicationToMigrate.getDockerImage());
//           userApplicationCreateDTO.setUsername(userApplicationToMigrate.getUsername());
//
//           UserApplication userApplication = userApplicationService.create(userApplicationCreateDTO);
//           userApplicationToMigrate.setMigrated(true);
//           System.out.println("Container migrated: " + userApplicationToMigrate.getAppName());
//           userApplicationToMigrateRepository.save(userApplicationToMigrate);
//       } catch (Exception e) {
//           userApplicationToMigrate.setFailureReason(e.getMessage());
//           userApplicationToMigrateRepository.save(userApplicationToMigrate);
//           System.out.println("Error while migrating container: " + e.getMessage());
//       }
//    }
  }

  public void migrateDockerContainersFromDb() {
      List<UserApplicationToMigrate> all = userApplicationToMigrateRepository.findAll();
      UserApplicationToMigrate userApplicationToMigrate = null;
    for (int i = 0; i < 15; i++) {
        try {
             userApplicationToMigrate =  all.get(i);
            userApplicationService.createFromMigration(userApplicationToMigrate);
            userApplicationToMigrate.setMigrated(true);
            userApplicationToMigrateRepository.save(userApplicationToMigrate);
        } catch (Exception e) {
            System.out.println("Error while migrating container: " + e.getMessage());
            userApplicationToMigrate.setFailureReason(e.getMessage());
            userApplicationToMigrateRepository.save(userApplicationToMigrate);

        }
    }

  }
}
