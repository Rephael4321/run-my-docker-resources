/*
 * Copyright (c) 2024.
 */

package com.codingbc.runmydocker.events.Docker;

import com.codingbc.runmydocker.models.UserApplication;
import lombok.Getter;
import org.springframework.context.ApplicationEvent;


@Getter
public class ContainerStartedEvent extends ApplicationEvent {

  private final String appName;

  public ContainerStartedEvent(Object source, String appName) {
    super(source);
    this.appName = appName;
  }
}
