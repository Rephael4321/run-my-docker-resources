/*
 * Copyright (c) 2024.
 */

package com.codingbc.runmydocker.security.OAuth2;

import com.codingbc.runmydocker.exceptions.GeneralError;
import com.codingbc.runmydocker.util.CookieUtils;
import com.codingbc.runmydocker.util.JwtTokenUtil;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.SimpleUrlAuthenticationSuccessHandler;
import org.springframework.stereotype.Component;
import org.springframework.web.util.UriComponentsBuilder;

@Component
@Slf4j
public class OAuth2AuthenticationSuccessHandler extends SimpleUrlAuthenticationSuccessHandler {
  private final HttpCookieOAuth2AuthorizationRequestRepository
      cookieOAuth2AuthorizationRequestRepository;

  private final JwtTokenUtil jwtTokenUtil;

  public OAuth2AuthenticationSuccessHandler(
      HttpCookieOAuth2AuthorizationRequestRepository cookieOAuth2AuthorizationRequestRepository,
      JwtTokenUtil jwtTokenUtil) {
    this.cookieOAuth2AuthorizationRequestRepository = cookieOAuth2AuthorizationRequestRepository;
    this.jwtTokenUtil = jwtTokenUtil;
  }

  @Override
  public void onAuthenticationSuccess(
      HttpServletRequest request, HttpServletResponse response, Authentication authentication)
      throws IOException, ServletException {
    String targetUrl = findTargetUrl(request, response, authentication);
    if (response.isCommitted()) {
      log.debug("Response has already been committed. Unable to redirect to " + targetUrl);
      return;
    }

    clearAuthenticationAttributes(request, response);
    getRedirectStrategy().sendRedirect(request, response, targetUrl);
  }

  protected void clearAuthenticationAttributes(
      HttpServletRequest request, HttpServletResponse response) {
    super.clearAuthenticationAttributes(request);
    cookieOAuth2AuthorizationRequestRepository.removeAuthorizationRequestCookies(request, response);
  }

  private String findTargetUrl(
      HttpServletRequest request, HttpServletResponse response, Authentication authentication) {
    String redirectUriParamCookieName =
        HttpCookieOAuth2AuthorizationRequestRepository.REDIRECT_URI_PARAM_COOKIE_NAME;
    Optional<Cookie> cookieFromRequest =
        CookieUtils.getCookieFromRequest(request, redirectUriParamCookieName);
    Optional<String> redirectUrl = cookieFromRequest.map(Cookie::getValue);

    if (redirectUrl.isEmpty()) {
      return handleMissingRedirectUrl();
    }

    validateRedirectUrl(redirectUrl.get());

    return generateTargetUrl(redirectUrl, authentication);
  }

  private String generateTargetUrl(Optional<String> redirectUrl, Authentication authentication) {
    String token = jwtTokenUtil.generateToken(authentication);
    String targetUri = redirectUrl.orElse(getDefaultTargetUrl());

    return UriComponentsBuilder.fromUriString(targetUri)
        .queryParam("token", token)
        .build()
        .toUriString();
  }

  private String handleMissingRedirectUrl() {
    return UriComponentsBuilder.fromUriString("/google/error")
        .queryParam(
            "error",
            "Sorry! We've got an Unauthorized Redirect URI and can't proceed with the authentication")
        .build()
        .toUriString();
  }

  private void validateRedirectUrl(String url) {
    if (!isAuthorizedRedirectUri(url)) {
      throw new GeneralError(
          "Sorry! We've got an Unauthorized Redirect URI and can't proceed with the authentication");
    }
  }

  private boolean isAuthorizedRedirectUri(String url) {
    List<String> authorizedRedirectUris =
        Arrays.asList(
            "http://localhost:8081/google",
            "https://backend.runmydocker.com/google",
            "https://backend.runmydocker.com/github",
            "http://backend.runmydocker.com/github",
            "http://localhost:8081/github",
            "http://localhost:8081/google");

    return authorizedRedirectUris.contains(url);
  }
}
