package com.codingbc.runmydocker.repositories;

import com.codingbc.runmydocker.models.migrations.UserApplicationToMigrate;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface UserApplicationToMigrateRepository
    extends JpaRepository<UserApplicationToMigrate, UUID> {}
