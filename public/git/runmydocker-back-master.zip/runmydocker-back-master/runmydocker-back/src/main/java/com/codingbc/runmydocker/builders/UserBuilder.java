package com.codingbc.runmydocker.builders;

import com.codingbc.runmydocker.models.User;

public class UserBuilder {
  private String firstName;

  private String lastName;

  private String username;

  private boolean isActivated;
  private String password;
  private String phone;
  private String providerId;
  private boolean registrationCompleted;

  public UserBuilder() {}

  public static UserBuilder builder() {
    return new UserBuilder();
  }

  public UserBuilder firstName(String firstName) {
    this.firstName = firstName;
    return this;
  }

  public UserBuilder lastName(String lastName) {
    this.lastName = lastName;
    return this;
  }

  public UserBuilder username(String username) {
    this.username = username;
    return this;
  }

  public UserBuilder isActivated(boolean isActivated) {
    this.isActivated = isActivated;
    return this;
  }

  public UserBuilder password(String password) {
    this.password = password;
    return this;
  }

  public UserBuilder phone(String phone) {
    this.phone = phone;
    return this;
  }

  public UserBuilder providerId(String providerId) {
    this.providerId = providerId;
    return this;
  }

  public UserBuilder registrationCompleted(boolean registrationCompleted) {
    this.registrationCompleted = registrationCompleted;
    return this;
  }

  public User build() {
    User user = new User();

    user.setFirstName(firstName);
    user.setLastName(lastName);
    user.setUsername(username);
    user.setActivated(isActivated);
    user.setPassword(password);
    user.setPhone(phone);
    user.setProviderId(providerId);
    user.setRegistrationCompleted(registrationCompleted);

    return user;
  }
}
