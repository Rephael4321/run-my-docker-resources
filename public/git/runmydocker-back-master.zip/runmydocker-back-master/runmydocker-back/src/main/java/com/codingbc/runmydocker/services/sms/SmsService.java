package com.codingbc.runmydocker.services.sms;

import lombok.extern.slf4j.Slf4j;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestTemplate;

@Service
@Slf4j
public class SmsService implements ISmsService {

  @Value("${sms4free.key}")
  private String ACCOUNT_KEY;

  @Value("${sms4free.user}")
  private String ACCOUNT_USER;

  @Value("${sms4free.password}")
  private String ACCOUNT_PASS;

  @Value("${sms4free.ApiUrl}")
  private String API_URL;

  @Autowired private RestTemplate restTemplate;

  public SmsService() {}

  @Override
  public boolean send(String phone, String text) {
    if (!StringUtils.hasText(phone)) {
      log.warn("Phoe is require, the given phone is: {}", phone);
      return false;
    }
    if (phone.startsWith("+972")) {
      phone = phone.replaceAll("\\+972", "0");
    }
    ResponseEntity<String> exchange =
        restTemplate.exchange(
            API_URL,
            HttpMethod.POST,
            new HttpEntity<>(buildSmsJsonPayLoad(text, phone).toString()),
            String.class);

    return exchange.getStatusCode().is2xxSuccessful();
  }

  private JSONObject buildSmsJsonPayLoad(String text, String phoneNumber) {
    JSONObject jsonPayload = new JSONObject();
    jsonPayload.put("key", ACCOUNT_KEY);
    jsonPayload.put("user", ACCOUNT_USER);
    jsonPayload.put("pass", ACCOUNT_PASS);
    jsonPayload.put("sender", "Run My Docker");
    jsonPayload.put("recipient", phoneNumber);
    jsonPayload.put("msg", text);
    return jsonPayload;
  }
}
