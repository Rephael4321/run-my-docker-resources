package com.codingbc.runmydocker.docs.swagger;

import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = true)
@Data
public class GetApplicationLogsResponse extends BaseResponseModal {
  private String data;
}
