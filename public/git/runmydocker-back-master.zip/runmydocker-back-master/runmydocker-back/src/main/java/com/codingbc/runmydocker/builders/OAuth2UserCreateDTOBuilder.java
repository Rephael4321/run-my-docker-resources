/*
 * Copyright (c) 2024.
 */

package com.codingbc.runmydocker.builders;

import com.codingbc.runmydocker.dto.AppUser.OAuth2UserCreateDTO;

public final class OAuth2UserCreateDTOBuilder {

  private OAuth2UserCreateDTO oAuth2UserCreateDTO;

  public OAuth2UserCreateDTOBuilder() {
    oAuth2UserCreateDTO = new OAuth2UserCreateDTO();
  }

  public OAuth2UserCreateDTOBuilder(OAuth2UserCreateDTO other) {
    this.oAuth2UserCreateDTO = other;
  }

  public static OAuth2UserCreateDTOBuilder anOAuth2UserCreateDTO() {
    return new OAuth2UserCreateDTOBuilder();
  }

  public OAuth2UserCreateDTOBuilder withProviderId(String providerId) {
    oAuth2UserCreateDTO.setProviderId(providerId);
    return this;
  }

  public OAuth2UserCreateDTOBuilder withActivated(boolean activated) {
    oAuth2UserCreateDTO.setActivated(activated);
    return this;
  }

  public OAuth2UserCreateDTOBuilder withRegistrationCompleted(boolean registrationCompleted) {
    oAuth2UserCreateDTO.setRegistrationCompleted(registrationCompleted);
    return this;
  }

  public OAuth2UserCreateDTOBuilder withUsername(String username) {
    oAuth2UserCreateDTO.setUsername(username);
    return this;
  }

  public OAuth2UserCreateDTOBuilder withPassword(String password) {
    oAuth2UserCreateDTO.setPassword(password);
    return this;
  }

  public OAuth2UserCreateDTO build() {
    return oAuth2UserCreateDTO;
  }
}
