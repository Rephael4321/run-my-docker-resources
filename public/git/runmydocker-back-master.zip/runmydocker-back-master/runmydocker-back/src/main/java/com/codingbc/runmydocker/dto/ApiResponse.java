package com.codingbc.runmydocker.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.HashMap;
import java.util.Map;
import lombok.Getter;
import lombok.Setter;
import org.springframework.http.HttpStatus;

@ApiModel(description = "Standard API response wrapper")
@Setter
@Getter
public class ApiResponse<T> {
  @ApiModelProperty(value = "Indicates if the operation was successful or not")
  private boolean success;

  @ApiModelProperty(value = "HTTP success code or custom code")
  private int code;

  @ApiModelProperty(value = "The response data, can be null in case of error")
  private T data;

  @ApiModelProperty(value = "A message describing the result")
  private String message;

  @ApiModelProperty(value = "Additional info (e.g., metadata, pagination, etc.)")
  private Map<String, ?> extraInfo;

  public ApiResponse(
      boolean success, HttpStatus httpStatus, T data, String message, Map<String, ?> extraInfo) {
    this.success = success;
    setCode(httpStatus);
    setMessage(message);
    this.data = data;
    this.extraInfo = extraInfo == null ? new HashMap<>() : extraInfo;
  }

  // error response
  public ApiResponse(
      boolean success, HttpStatus httpStatus, String message, Map<String, ?> extraInfo) {
    this(success, httpStatus, null, message, extraInfo);
  }

  public void setMessage(String message) {
    if (message == null) {
      this.message = success ? "Operation successful" : "An error occurred";
      return;
    }
    this.message = message;
  }

  public void setCode(HttpStatus httpStatus) {
    if (httpStatus == null) {
      this.code = success ? HttpStatus.OK.value() : HttpStatus.INTERNAL_SERVER_ERROR.value();
      return;
    }

    this.code = httpStatus.value();
  }

  public static <T> ApiResponse<T> success(
      T data, String message, HttpStatus httpStatus, Map<String, ?> extraInfo) {
    return new ApiResponse<>(
        true, httpStatus != null ? httpStatus : HttpStatus.OK, data, message, extraInfo);
  }

  public static <T> ApiResponse<T> error(
      String message, HttpStatus httpStatus, Map<String, ?> extraInfo) {
    return new ApiResponse<>(
        false, httpStatus != null ? httpStatus : HttpStatus.BAD_REQUEST, message, extraInfo);
  }

  @Override
  public String toString() {
    return "ApiResponse{" +
        "success=" + success +
        ", code=" + code +
        ", data=" + data +
        ", message='" + message + '\'' +
        ", extraInfo=" + extraInfo +
        '}';
  }
}
