package com.codingbc.runmydocker.dto.UserApplication;

import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = true)
@Data
public class UpdateUserApplicationDTO extends UserApplicationCreateDTO {
    private long appId;
}
