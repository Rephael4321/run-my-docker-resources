/*
 * Copyright (c) 2024.
 */

package com.codingbc.runmydocker.builders;

import com.codingbc.runmydocker.dto.auth.AuthenticationRequest;

public final class AuthenticationRequestBuilder {

  private AuthenticationRequest authenticationRequest;

  public AuthenticationRequestBuilder() {
    authenticationRequest = new AuthenticationRequest();
  }

  public AuthenticationRequestBuilder(AuthenticationRequest other) {
    this.authenticationRequest = other;
  }

  public static AuthenticationRequestBuilder anAuthenticationRequest() {
    return new AuthenticationRequestBuilder();
  }

  public AuthenticationRequestBuilder withUsername(String username) {
    authenticationRequest.setUsername(username);
    return this;
  }

  public AuthenticationRequestBuilder withPassword(String password) {
    authenticationRequest.setPassword(password);
    return this;
  }

  public AuthenticationRequest build() {
    return authenticationRequest;
  }
}
