/*
 * Copyright (c) 2024.
 */

package com.codingbc.runmydocker.dto.UserApplication;

import java.util.List;
import lombok.Data;

@Data
public class ListOfUserApplicationOut {

  private List<UserApplicationOut> applications;

  public ListOfUserApplicationOut(List<UserApplicationOut> applications) {
    this.applications = applications;
  }
}
