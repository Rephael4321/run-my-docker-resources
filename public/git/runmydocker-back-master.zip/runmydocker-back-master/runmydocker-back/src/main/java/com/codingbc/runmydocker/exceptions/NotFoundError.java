/*
 * Copyright (c) 2024.
 */

package com.codingbc.runmydocker.exceptions;

import java.util.Map;
import org.springframework.http.HttpStatus;

public class NotFoundError extends BaseException {

  public NotFoundError() {
    super(HttpStatus.NOT_FOUND, "Not Found", null);
  }

  public NotFoundError(String message) {
    super(HttpStatus.NOT_FOUND, message, null);
  }

  public NotFoundError(String message, Map<String, Object> additionalInfo) {
    super(HttpStatus.NOT_FOUND, message, additionalInfo);
  }

}
