package com.codingbc.runmydocker.exceptions;

import java.util.Map;
import org.springframework.http.HttpStatus;

public class GeneralError extends BaseException {

  public GeneralError() {
    super(HttpStatus.INTERNAL_SERVER_ERROR, "General Error", null);
  }

  public GeneralError(String message) {
    super(HttpStatus.INTERNAL_SERVER_ERROR, message, null);
  }

  public GeneralError(String message, Map<String, Object> additionalInfo) {
    super(HttpStatus.INTERNAL_SERVER_ERROR, message, additionalInfo);
  }
}
