package com.codingbc.runmydocker.dto.AppUser;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class UserOutDTO {
  private long id;
  private String firstName;
  private String lastName;
  private String username;
  private String phone;

  @JsonProperty("isActivated")
  private boolean activated;
}
