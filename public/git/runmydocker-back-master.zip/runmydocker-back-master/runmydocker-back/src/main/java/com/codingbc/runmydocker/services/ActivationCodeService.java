package com.codingbc.runmydocker.services;

import com.codingbc.runmydocker.builders.ActivationCodeBuilder;
import com.codingbc.runmydocker.exceptions.GeneralError;
import com.codingbc.runmydocker.models.ActivationCode;
import com.codingbc.runmydocker.models.User;
import com.codingbc.runmydocker.repositories.ActivationCodeRepository;
import com.codingbc.runmydocker.repositories.UserRepository;
import com.codingbc.runmydocker.services.sms.SmsService;
import java.time.LocalDateTime;
import java.util.Optional;
import java.util.Random;
import java.util.UUID;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Slf4j
@Service
public class ActivationCodeService {
  @Autowired private Environment environment;
  private final int CODE_LENGTH = 6;
  private final String CHARS = "1234567890";
  private final ActivationCodeRepository activationCodeRepository;
  private final UserRepository userRepository;

  private final SmsService smsService;

  public ActivationCodeService(
      ActivationCodeRepository activationCodeRepository,
      UserRepository userRepository,
      SmsService smsService) {
    this.activationCodeRepository = activationCodeRepository;
    this.userRepository = userRepository;
    this.smsService = smsService;
  }

  public ActivationCode generateActivationCode(User user) {
    String code = generateCode();
    LocalDateTime expirationTime = LocalDateTime.now().plusMinutes(10);
    return ActivationCodeBuilder.anActivationCode()
        .withCode(code)
        .withUser(user)
        .withExpirationTime(expirationTime)
        .withUuidToken(UUID.randomUUID().toString())
        .build();
  }

  private String generateCode() {
    StringBuilder code = new StringBuilder();
    Random random = new Random();
    for (int i = 0; i < CODE_LENGTH; i++) {
      int randomIndex = random.nextInt(CHARS.length());
      char randomChar = CHARS.charAt(randomIndex);
      code.append(randomChar);
    }

    return code.toString();
  }

  @Transactional
  public void sendActivationCode(String username) {
    Optional<ActivationCode> byUsername = activationCodeRepository.findByUsername(username);
    if (byUsername.isEmpty()) {
      log.info("Activation code not found for user: {}", username);
      throw new GeneralError("Activation code not found for user: " + username);
    }
    sendActivationCode(byUsername.get());
  }

  public void sendActivationCode(ActivationCode activationCode) {
    if (activationCode == null) {
      log.info("Sms cant be send - activation code: null");
      throw new GeneralError("Sms cant be send - activation code: null");
    }

    log.info(
        "sending activation code to user:"
            + activationCode.getUser().getUsername()
            + "code: "
            + activationCode.getCode());
    String meesage =
        String.format(
            "Hey, %s, your activation code is %s is valid for 10 minutes",
            activationCode.getUser().getFirstName() + " " + activationCode.getUser().getLastName(),
            activationCode.getCode());

    if (environment.acceptsProfiles("dev")) {
      log.info("Activation code: {}", activationCode.getCode());
      return;
    }
    smsService.send(activationCode.getUser().getPhone(), meesage);
  }
}
