package com.codingbc.runmydocker.events.User;

import com.codingbc.runmydocker.models.ActivationCode;
import com.codingbc.runmydocker.models.User;
import com.codingbc.runmydocker.services.ActivationCodeService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class UserEventListener {
  @Autowired private ActivationCodeService activationCodeService;
  @Autowired private Environment environment;

  @Async
  @EventListener
  public void handleUserRegisteredEvent(UserRegisteredEvent event) {
    User user = event.getUser();
    log.info("User registered {}", user.getUsername());
    sendActivationCode(user.getLastActivationCode());
  }

  private void sendActivationCode(ActivationCode activationCode) {
    log.info("Sending activation code to user {}", activationCode.getUser().getUsername());
    if (environment.acceptsProfiles("dev")) {
      log.info("Activation code: {}", activationCode.getCode());
      return;
    }
    activationCodeService.sendActivationCode(activationCode);
  }
}
