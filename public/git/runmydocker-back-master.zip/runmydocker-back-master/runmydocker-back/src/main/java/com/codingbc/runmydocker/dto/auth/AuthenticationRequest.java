package com.codingbc.runmydocker.dto.auth;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.validator.constraints.Length;


@Setter
@Getter
public class AuthenticationRequest {
  @Email
  @NotBlank(message = "username is require")
  private String username;

  @NotBlank(message = "password is require")
  @Length(min = 4)
  private String password;

  public AuthenticationRequest() {}

  public AuthenticationRequest(String username, String password) {
    this.username = username;
    this.password = password;
  }

}
