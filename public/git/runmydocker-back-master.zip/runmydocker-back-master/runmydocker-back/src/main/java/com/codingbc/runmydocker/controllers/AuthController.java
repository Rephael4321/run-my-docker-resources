package com.codingbc.runmydocker.controllers;

import com.codingbc.runmydocker.dto.AppUser.RegularUserCreateDTO;
import com.codingbc.runmydocker.dto.auth.*;
import com.codingbc.runmydocker.events.rabbit.MessageProducer;

import com.codingbc.runmydocker.exceptions.ApiError;
import com.codingbc.runmydocker.mappers.User.IUserMapper;
import com.codingbc.runmydocker.services.AuthService;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

import java.util.Map;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Lazy;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import static com.codingbc.runmydocker.dto.ApiResponse.success;

@RestController
@RequestMapping("/api/auth")
@Slf4j
public class AuthController {

  private final AuthService authService;
  private final IUserMapper userMapper;
  private final MessageProducer messageProducer;





  public AuthController(@Lazy AuthService authService, IUserMapper userMapper, MessageProducer messageProducer) {
    this.authService = authService;
    this.userMapper = userMapper;
      this.messageProducer = messageProducer;
  }

  @PostMapping("/register")
  @ApiOperation(value = "Create a new user")
  @ApiResponses(
      value = {
        @ApiResponse(code = 201, message = "User created successfully"),
        @ApiResponse(
            code = 400,
            response = com.codingbc.runmydocker.dto.ApiResponse.class,
            message = "Validation error"),
        @ApiResponse(
            code = 400,
            response = com.codingbc.runmydocker.dto.ApiResponse.class,
            message = "malform request"),
        @ApiResponse(
            code = 409,
            response = com.codingbc.runmydocker.dto.ApiResponse.class,
            message = "User already exists")
      })
  public ResponseEntity<com.codingbc.runmydocker.dto.ApiResponse<RegistrationResponse>> register(
      @Valid @RequestBody RegularUserCreateDTO request, HttpServletResponse response) {
    RegistrationResponse registrationResponse = authService.register(request);
    response.setHeader("UUID", registrationResponse.getUuid());
    response.addCookie(new Cookie("UUID", registrationResponse.getUuid()));

    var apiResponse = success(registrationResponse, null, HttpStatus.CREATED, null);

    return new ResponseEntity<>(apiResponse, HttpStatus.CREATED);
  }

  @ApiOperation(value = "Login")
  @ApiResponses(
      value = {
        @ApiResponse(code = 200, message = "User authenticated successfully"),
        @ApiResponse(
            code = 400,
            message = "Bad Request",
            response = com.codingbc.runmydocker.dto.ApiResponse.class),
      })
  @PostMapping("/login")
  public ResponseEntity<com.codingbc.runmydocker.dto.ApiResponse<AuthResponse>> login(
      @RequestBody @Valid AuthenticationRequest request) {
    String token = authService.authenticate(request);
    AuthResponse response = AuthResponse.builder().token(token).build();
    var apiResponse = success(response, null, HttpStatus.OK, null);

    return new ResponseEntity<>(apiResponse, HttpStatus.OK);
  }

  @PutMapping("/activate")
  @ApiOperation(value = "Activate user")
  @ApiResponses(
      value = {
        @ApiResponse(
            code = 400,
            message = "Validation Errors",
            response = com.codingbc.runmydocker.dto.ApiResponse.class),
        @ApiResponse(
            code = 404,
            response = com.codingbc.runmydocker.dto.ApiResponse.class,
            message = "User or activation code are not found"),
        @ApiResponse(
            code = 500,
            response = com.codingbc.runmydocker.dto.ApiResponse.class,
            message = "user already activated or activation code expired"),
        @ApiResponse(code = 400, message = "Bad Request", response = ApiError.class),
      })
  public ResponseEntity<com.codingbc.runmydocker.dto.ApiResponse<ActivationResponse>> activateUser(
      @RequestBody @Valid ActivationRequest request) {
    ActivationResponse activationResponse = authService.activateUser(request);
    var apiResponse =
        success(activationResponse, "user activated successfully", HttpStatus.OK, null);

    return ResponseEntity.ok(apiResponse);
  }

  @GetMapping("/resendCode")
  @ApiOperation(value = "Resend activation code")
  @ApiResponses(
      value = {
        @ApiResponse(
            code = 404,
            response = com.codingbc.runmydocker.dto.ApiResponse.class,
            message = "User not found"),
      })
  public ResponseEntity<com.codingbc.runmydocker.dto.ApiResponse<RegistrationResponse>> resendCode(
      @RequestParam("username") String username, HttpServletResponse response) {
    RegistrationResponse registrationResponse = authService.resendActicationCode(username);
    response.setHeader("UUID", registrationResponse.getUuid());

    return ResponseEntity.ok(success(registrationResponse, "code sent", HttpStatus.OK, null));
  }

  @PutMapping("/completeRegistration/{id}")
  @ApiResponses(
      value = {
        @ApiResponse(
            code = 404,
            response = com.codingbc.runmydocker.dto.ApiResponse.class,
            message = "User not found"),
        @ApiResponse(
            code = 400,
            response = com.codingbc.runmydocker.dto.ApiResponse.class,
            message = "Bad Request"),
        @ApiResponse(
            code = 400,
            response = com.codingbc.runmydocker.dto.ApiResponse.class,
            message = "malform request"),
      })
  public ResponseEntity<com.codingbc.runmydocker.dto.ApiResponse<RegistrationResponse>>
      completeRegistration(
          @PathVariable(name = "id") Long userId,
          @RequestBody CompleteRegistrationRequest request) {
    RegistrationResponse response = authService.completeUserRegistration(userId, request);

    return ResponseEntity.ok()
        .body(success(response, "User registered successfully", HttpStatus.OK, null));
  }

  @GetMapping("/forgotPassword")
  @ApiOperation(value = "Send forgot password code")
  @ApiResponses(
      value = {
        @ApiResponse(
            code = 404,
            response = com.codingbc.runmydocker.dto.ApiResponse.class,
            message = "User not found"),
      })
  public ResponseEntity<com.codingbc.runmydocker.dto.ApiResponse<ForgotPasswordResponse>> forgotPassword(
      @RequestParam String username, HttpServletResponse response) {
    String uuidToken = authService.sendForgotPasswordCode(username);
    response.setHeader("UUID", uuidToken);

    return ResponseEntity.ok()
        .body(
            success(
                ForgotPasswordResponse.of(uuidToken),
                "Code sent",
                HttpStatus.OK,
                Map.of("username", username)));
  }

  @PutMapping("/changePassword")
  @ApiOperation(value = "Change password")
  @ApiResponses(
      value = {
        @ApiResponse(
            code = 404,
            response = com.codingbc.runmydocker.dto.ApiResponse.class,
            message = "User or Activation code not found"),
        @ApiResponse(
            code = 400,
            response = com.codingbc.runmydocker.dto.ApiResponse.class,
            message = "Bad Request | Validation Error"),
      })
  public ResponseEntity<com.codingbc.runmydocker.dto.ApiResponse<?>> changePassword(
      @RequestBody @Valid ChangePasswordRequest request) {
    authService.changePassword(request);

    return ResponseEntity.ok().body(success(null, "Password changed", HttpStatus.NO_CONTENT, null));
  }

  @GetMapping("/hash-password")
    public ResponseEntity<com.codingbc.runmydocker.dto.ApiResponse<String>> hashPassword(@RequestParam String password) {
        String hashedPassword = new BCryptPasswordEncoder().encode(password);
        return ResponseEntity.ok().body(success(hashedPassword, "Password hashed", HttpStatus.OK, null));
    }

}
