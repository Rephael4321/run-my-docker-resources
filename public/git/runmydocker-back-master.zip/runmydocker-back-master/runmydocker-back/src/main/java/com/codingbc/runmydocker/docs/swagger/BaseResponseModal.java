package com.codingbc.runmydocker.docs.swagger;

import lombok.Data;

@Data
public abstract class BaseResponseModal {
  private boolean success;
  private int code;
  private String message;
  private Object extraInfo;
}
