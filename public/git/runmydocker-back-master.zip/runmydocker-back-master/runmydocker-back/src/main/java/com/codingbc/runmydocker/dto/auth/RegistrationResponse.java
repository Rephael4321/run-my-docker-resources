package com.codingbc.runmydocker.dto.auth;

import com.codingbc.runmydocker.dto.AppUser.UserOutDTO;
import lombok.Data;

@Data
public class RegistrationResponse {
  private UserOutDTO user;
  private String uuid;
}
