package com.codingbc.runmydocker.configuration;

import com.codingbc.runmydocker.exceptions.CustomAsyncExceptionHandler;
import com.codingbc.runmydocker.filters.UUIDInjectionFilter;
import com.codingbc.runmydocker.mappers.User.IUserMapper;
import com.codingbc.runmydocker.mappers.User.UserMapper;
import com.codingbc.runmydocker.mappers.UserApplication.IUserApplicationMapper;
import com.codingbc.runmydocker.mappers.UserApplication.UserApplicationMapper;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.joda.JodaModule;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import lombok.extern.slf4j.Slf4j;

import java.util.concurrent.Executor;
import java.util.concurrent.ThreadPoolExecutor;

import org.springframework.aop.interceptor.AsyncUncaughtExceptionHandler;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.lang.Nullable;
import org.springframework.scheduling.annotation.AsyncConfigurer;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.web.client.RestTemplate;

@Configuration
@EnableAsync
@Slf4j
public class AppConfig implements AsyncConfigurer {
	@Bean
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}

	@Bean
	public ObjectMapper objectMapper() {
		ObjectMapper mapper = new ObjectMapper();
		mapper.registerModule(new JodaModule());
		mapper.registerModule(new JavaTimeModule());
		return mapper;
	}

	@Override
	public AsyncUncaughtExceptionHandler getAsyncUncaughtExceptionHandler() {
		return new CustomAsyncExceptionHandler();
	}

	@Bean
	public IUserMapper userMapper() {
		return new UserMapper();
	}

	@Bean
	public IUserApplicationMapper userApplicationMapper() {
		return new UserApplicationMapper();
	}

	@Bean(name = "taskExecutor")
	public java.util.concurrent.Executor taskExecutor() {
		ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
		executor.setCorePoolSize(50);
		executor.setMaxPoolSize(200);
		executor.setQueueCapacity(800);
		executor.setThreadNamePrefix("AsyncExecutor-");

		executor.setRejectedExecutionHandler((runnable, threadPoolExecutor) -> {
			log.error("Task rejected from thread pool. Active threads: {}, Pool size: {}, Queue size: {}",
					threadPoolExecutor.getActiveCount(),
					threadPoolExecutor.getPoolSize(),
					threadPoolExecutor.getQueue().size());
		});

		executor.initialize();
		log.info("Custom taskExecutor initialized");
		return executor;
	}

	@Override
	@Nullable
	public Executor getAsyncExecutor() {
		return taskExecutor();
	}

}
