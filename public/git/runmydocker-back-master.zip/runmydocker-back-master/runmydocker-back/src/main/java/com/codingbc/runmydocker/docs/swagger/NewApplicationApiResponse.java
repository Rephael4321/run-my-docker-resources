package com.codingbc.runmydocker.docs.swagger;

import com.codingbc.runmydocker.dto.UserApplication.NewApplicationResponse;
import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = true)
@Data
public class NewApplicationApiResponse extends BaseResponseModal {
  private NewApplicationResponse data;
}
