/*
 * Copyright (c) 2024.
 */

package com.codingbc.runmydocker.dto.UserApplication;


import com.codingbc.runmydocker.enums.AppActions;
import com.codingbc.runmydocker.enums.AppStatus;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class ExecutionResponse {

  private Long id;
  private String message;
  private AppActions action;
  private AppStatus appStatus;

  // TODO: refactor to mapper
  static public ExecutionResponse toResponse(long appId, String message, AppActions action,
      AppStatus status) {
    ExecutionResponse response = new ExecutionResponse();
    response.setId(appId);
    response.setMessage(message);
    response.setAction(action);
    response.setAppStatus(status);
    return response;
  }
}
