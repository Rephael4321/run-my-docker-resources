package com.codingbc.runmydocker.models;

import com.codingbc.runmydocker.BaseEntity;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.persistence.*;
import javax.validation.constraints.Email;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.validator.constraints.Length;

@Entity
@Table(name = "users")
@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class User extends BaseEntity {
  @Length(min = 1, max = 60)
  private String firstName;

  @Length(min = 1, max = 60)
  private String lastName;

  @Email
  @Column(unique = true)
  private String username;

  @Column(name = "is_activated")
  private boolean isActivated;

  private String password;
  private String phone;

  @Column(name = "provider_id")
  private String providerId;

  private String role;

  @Column(name = "registration_completed")
  private boolean registrationCompleted;

  @Column(name = "old_created_at")
    private String oldCreatedAt;

  @JsonManagedReference
  @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = true)
  private List<ActivationCode> activationCodes = new ArrayList<>();

  @OneToMany(
      mappedBy = "user",
      cascade = {CascadeType.PERSIST, CascadeType.REMOVE})
  private Set<UserApplication> userApplications = new HashSet<>();

  public ActivationCode getLastActivationCode() {
    if (this.activationCodes.isEmpty()) {
      return null;
    }
    return this.activationCodes.get(this.activationCodes.size() - 1);
  }

  public void addActivationCode(ActivationCode activationCode) {
    activationCode.setUser(this);
    activationCodes.add(activationCode);
  }

  public void removeActicationCode(ActivationCode activationCode) {
    activationCode.setUser(null);
    activationCodes.remove(activationCode);
  }

  public User() {
    isActivated = false;
    registrationCompleted = false;
  }

  @Override
  public String toString() {
    return "User{"
        + "firstName='"
        + firstName
        + '\''
        + ", lastName='"
        + lastName
        + '\''
        + ", username='"
        + username
        + '\''
        + ", isActivated="
        + isActivated
        + ", password='"
        + password
        + '\''
        + ", phone='"
        + phone
        + '\''
        + ", providerId='"
        + providerId
        + '\''
        + ", role='"
        + role
        + '\''
        + ", registrationCompleted="
        + registrationCompleted
        + ", activationCodes="
        + activationCodes
        + '}';
  }

  public boolean isActivated() {
    return isActivated;
  }

  public void setActivated(boolean activated) {
    isActivated = activated;
  }

  public int getApplicationCount() {
    return userApplications.size();
  }
}
