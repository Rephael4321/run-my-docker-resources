/*
 * Copyright (c) 2024.
 */

package com.codingbc.runmydocker.dto.UserApplication;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class UserApplicationCreateDTO {

  private String dockerImage;
  private String appName;
  @JsonProperty("portMap")
  private int containerPort;
//  @JsonIgnore
  private String username;

  public UserApplicationCreateDTO() {

  }
}
