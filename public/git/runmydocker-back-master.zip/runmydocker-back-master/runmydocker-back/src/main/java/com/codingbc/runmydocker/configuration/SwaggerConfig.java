package com.codingbc.runmydocker.configuration;

import static springfox.documentation.builders.PathSelectors.*;

import com.codingbc.runmydocker.dto.ApiResponse;
import com.google.common.collect.*;

import io.swagger.annotations.ApiResponses;
import java.awt.print.*;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.*;

import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.*;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.http.*;
import org.springframework.util.StreamUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.ResponseMessageBuilder;
import springfox.documentation.schema.ModelRef;
import springfox.documentation.service.*;
import springfox.documentation.spi.*;
import springfox.documentation.spi.service.contexts.*;
import springfox.documentation.spring.web.plugins.*;
import springfox.documentation.swagger2.annotations.*;

@Configuration
@EnableSwagger2
public class SwaggerConfig {
  public static final String AUTHORIZATION_HEADER = "Authorization";
  public static final String DEFAULT_INCLUDE_PATTERN = "/.*";

  @Autowired private ResourceLoader resourceLoader;

  @Bean
  public Docket swaggerSpringfoxDocket() {
    Contact contact = new Contact("CodingBC", "https:///codingbc.com", "admin@handson.com");

    Docket docket =
        new Docket(DocumentationType.SWAGGER_2)
            .pathMapping("/")
            .apiInfo(apiInfo())
            .forCodeGeneration(true)
            .genericModelSubstitutes(ResponseEntity.class)
            .ignoredParameterTypes(Pageable.class)
            .ignoredParameterTypes(java.sql.Date.class)
            .directModelSubstitute(java.time.LocalDate.class, java.sql.Date.class)
            .directModelSubstitute(java.time.ZonedDateTime.class, Date.class)
            .directModelSubstitute(java.time.LocalDateTime.class, Date.class)
            .securityContexts(Lists.newArrayList(securityContext()))
            .securitySchemes(Lists.newArrayList(apiKey()))
            .useDefaultResponseMessages(false);

    docket = docket.select().paths(regex(DEFAULT_INCLUDE_PATTERN)).build();


    return docket;
  }

  private ApiKey apiKey() {
    return new ApiKey("Authorization", AUTHORIZATION_HEADER, "header");
  }

  private ApiInfo apiInfo() {
    try {
      Resource resource = resourceLoader.getResource("classpath:ApiInfo.md");
      String apiInfoInMd =
          StreamUtils.copyToString(resource.getInputStream(), StandardCharsets.UTF_8);
      return new ApiInfoBuilder()
          .title("RunMyDocker API")
          .version("3.0")
          .description(apiInfoInMd)
          .build();
    } catch (IOException e) {
      throw new RuntimeException(e);
    }
  }

  private SecurityContext securityContext() {
    return SecurityContext.builder()
        .securityReferences(defaultAuth())
        .forPaths(regex(DEFAULT_INCLUDE_PATTERN))
        .build();
  }

  List<SecurityReference> defaultAuth() {
    AuthorizationScope authorizationScope = new AuthorizationScope("global", "accessEverything");
    AuthorizationScope[] authorizationScopes = new AuthorizationScope[1];
    authorizationScopes[0] = authorizationScope;
    return Lists.newArrayList(new SecurityReference("Authorization", authorizationScopes));
  }

  private List<ResponseMessage> responseMessageList() {
    ResponseMessage okResponse =
        new ResponseMessageBuilder()
            .code(200)
            .message("Successful Operation")
            .responseModel(new ModelRef("ApiResponse"))
            .build();

    ResponseMessage badRequestResponse =
        new ResponseMessageBuilder()
            .code(400)
            .message("Bad Request")
            .responseModel(new ModelRef("ApiResponse"))
            .build();

    ResponseMessage unauthorizedResponse =
        new ResponseMessageBuilder()
            .code(401)
            .message("Unauthorized")
            .responseModel(new ModelRef("ApiResponse"))
            .build();

    ResponseMessage forbiddenResponse =
        new ResponseMessageBuilder()
            .code(403)
            .message("Forbidden")
            .responseModel(new ModelRef("ApiResponse"))
            .build();

    ResponseMessage notFoundResponse =
        new ResponseMessageBuilder()
            .code(404)
            .message("Not Found")
            .responseModel(new ModelRef("ApiResponse"))
            .build();

    ResponseMessage conflictResponse =
        new ResponseMessageBuilder()
            .code(409)
            .message("Conflict")
            .responseModel(new ModelRef("ApiResponse"))
            .build();

    ResponseMessage internalServerErrorResponse =
        new ResponseMessageBuilder()
            .code(500)
            .message("Internal Server Error")
            .responseModel(new ModelRef("ApiResponse"))
            .build();

    return Lists.newArrayList(
        okResponse,
//        createdResponse,
//        noContentResponse,
        badRequestResponse,
        unauthorizedResponse,
        forbiddenResponse,
        notFoundResponse,
        conflictResponse,
        internalServerErrorResponse);
  }
}
