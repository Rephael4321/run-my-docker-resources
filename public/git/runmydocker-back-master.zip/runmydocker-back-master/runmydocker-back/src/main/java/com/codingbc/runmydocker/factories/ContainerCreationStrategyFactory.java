package com.codingbc.runmydocker.factories;

import com.codingbc.runmydocker.services.DockerService;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ContainerCreationStrategyFactory {

  public static ContainerCreationStrategy getFactory(boolean isLocalImage,
      DockerService dockerService) {
    if (isLocalImage) {
      log.info("[ContainerCreationStrategyFactory] Using LocalContainerCreationStrategy");
      return new LocalContainerCreationStrategy(dockerService);
    }
    log.info("[ContainerCreationStrategyFactory] Using RemoteContainerCreationStrategy");
    return new RemoteContainerCreationStrategy(dockerService);
  }

}
