/*
 * Copyright (c) 2024.
 */

package com.codingbc.runmydocker.security.OAuth2.OAuthUserInfo;

public enum eOAuth2UserAttributes {
  SUB("sub"),
  NAME("name"),
  EMAIL("email");

  private final String value;

  eOAuth2UserAttributes(String value) {
    this.value = value;
  }

  public String getValue() {
    return value;
  }
}
