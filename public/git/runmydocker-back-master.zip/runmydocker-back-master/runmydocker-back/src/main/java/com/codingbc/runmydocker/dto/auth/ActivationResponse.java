package com.codingbc.runmydocker.dto.auth;

import lombok.Data;

@Data
public class ActivationResponse {
    private String message;
    private String username;
    private String jwtToken;
}
