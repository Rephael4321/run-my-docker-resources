package com.codingbc.runmydocker.exceptions;

import java.util.Map;
import org.springframework.http.HttpStatus;

public class ConflictError extends BaseException {

  public ConflictError() {
    super(HttpStatus.CONFLICT, "Conflict", null);
  }

  public ConflictError(String message) {
    super(HttpStatus.CONFLICT, message, null);
  }

  public ConflictError(String message, Map<String, Object> additionalInfo) {
    super(HttpStatus.CONFLICT, message, additionalInfo);
  }

}
