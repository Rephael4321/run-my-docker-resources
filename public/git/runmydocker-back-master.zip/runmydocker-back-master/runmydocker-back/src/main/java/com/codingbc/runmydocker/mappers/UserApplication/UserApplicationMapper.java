/*
 * Copyright (c) 2024.
 */

package com.codingbc.runmydocker.mappers.UserApplication;

import com.codingbc.runmydocker.builders.UserApplicationBuilder;
import com.codingbc.runmydocker.builders.UserApplicationOutBuilder;
import com.codingbc.runmydocker.dto.UserApplication.ApplicationCreateResponse;
import com.codingbc.runmydocker.dto.UserApplication.NewApplicationResponse;
import com.codingbc.runmydocker.dto.UserApplication.UserApplicationCreateDTO;
import com.codingbc.runmydocker.dto.UserApplication.UserApplicationOut;
import com.codingbc.runmydocker.models.UserApplication;

public class UserApplicationMapper implements IUserApplicationMapper {

  private static final String DOMAIN_NAME = ".runmydocker-app.com";

  @Override
  public UserApplication toUserApplication(UserApplicationCreateDTO dto) {
    if (dto == null) {
      return null;
    }

    return UserApplicationBuilder.anUserApplication()
        .withContainerPort(dto.getContainerPort())
        .withAppName(dto.getAppName())
        .withDockerImage(dto.getDockerImage())
        .withUsername(dto.getUsername())
        .build();
  }

  @Override
  public ApplicationCreateResponse toApplicationCreateResponse(UserApplication userApplication) {
    if (userApplication == null) {
      return null;
    }

    return ApplicationCreateResponse.toApplicationCreateResponse(userApplication);
  }

  @Override
  public UserApplicationOut toUserApplicationOut(UserApplication userApplication) {
    if (userApplication == null) {
      return null;
    }

    return UserApplicationOutBuilder.anUserApplicationOut()
        .withId(userApplication.getId())
        .withAppName(userApplication.getAppName())
        .withMappingPort(String.valueOf(userApplication.getContainerPort()))
        .withCreatedAt(userApplication.getCreatedAt())
        .withDockerImage(userApplication.getDockerImage())
        .withUsername(userApplication.getUsername())
        .withRemainingTime(userApplication.getRemainingTime())
        .withUpdatedAt(userApplication.getLastUsed())
        .withIsRunning(userApplication.isRunning())
        .withStatusInfo(userApplication.getStatus(), userApplication.getCreationError())
        .build();
  }

  @Override
  public NewApplicationResponse toNewApplicationResponse(UserApplication userApplication) {
    if (userApplication == null) {
      return null;
    }

    String applicationUrl = String.format("%s%s", userApplication.getAppName(), DOMAIN_NAME);
    NewApplicationResponse build = NewApplicationResponse.builder()
        .id(userApplication.getId())
        .name(userApplication.getAppName())
        .url(applicationUrl)
        .build();

    return build;

  }
}
