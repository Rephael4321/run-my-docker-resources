package com.codingbc.runmydocker.services;

import com.codingbc.runmydocker.builders.ActivationResponseBuilder;
import com.codingbc.runmydocker.builders.RegistrationResponseBuilder;
import com.codingbc.runmydocker.dto.AppUser.RegularUserCreateDTO;
import com.codingbc.runmydocker.dto.AppUser.UserOutDTO;
import com.codingbc.runmydocker.dto.auth.*;
import com.codingbc.runmydocker.events.EventPublisher;
import com.codingbc.runmydocker.events.User.UserRegisteredEvent;
import com.codingbc.runmydocker.events.rabbit.MessageProducer;
import com.codingbc.runmydocker.exceptions.GeneralError;
import com.codingbc.runmydocker.exceptions.NotFoundError;
import com.codingbc.runmydocker.mappers.User.IUserMapper;
import com.codingbc.runmydocker.models.ActivationCode;
import com.codingbc.runmydocker.models.User;
import com.codingbc.runmydocker.repositories.ActivationCodeRepository;
import com.codingbc.runmydocker.repositories.UserRepository;
import com.codingbc.runmydocker.security.CustomUserDetailsService;
import com.codingbc.runmydocker.util.JwtTokenUtil;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

@Service
@Slf4j
public class AuthService {

  private final ActivationCodeRepository activationCodeRepository;
  private final UserRepository userRepository;
  private final AuthenticationManager authenticationManager;
  private final CustomUserDetailsService customUserDetailsService;
  private final JwtTokenUtil jwtTokenUtil;
  private final UserService userService;
  private final ApplicationEventPublisher eventPublisher;
  private final IUserMapper userMapper;
  private final ActivationCodeService activationCodeService;
  private final PasswordEncoder passwordEncoder;
  private final MessageProducer messageProducer;

  public AuthService(
      AuthenticationManager authenticationManager,
      CustomUserDetailsService customUserDetailsService,
      JwtTokenUtil jwtTokenUtil,
      UserService userService,
      ApplicationEventPublisher eventPublisher,
      IUserMapper userMapper,
      UserRepository userRepository,
      ActivationCodeRepository activationCodeRepository,
      ActivationCodeService activationCodeService,
      PasswordEncoder passwordEncoder,
      MessageProducer messageProducer) {
    this.authenticationManager = authenticationManager;
    this.customUserDetailsService = customUserDetailsService;
    this.jwtTokenUtil = jwtTokenUtil;
    this.userService = userService;
    this.eventPublisher = eventPublisher;

    this.userMapper = userMapper;
    this.userRepository = userRepository;
    this.activationCodeRepository = activationCodeRepository;
    this.activationCodeService = activationCodeService;
    this.passwordEncoder = passwordEncoder;
    this.messageProducer = messageProducer;
  }

  public String authenticate(AuthenticationRequest request) {
    UsernamePasswordAuthenticationToken authToken =
        new UsernamePasswordAuthenticationToken(request.getUsername(), request.getPassword());
    Authentication authenticate = authenticationManager.authenticate(authToken);
    UserDetails userDetails = customUserDetailsService.loadUserByUsername(request.getUsername());

    return jwtTokenUtil.generateToken(userDetails);
  }

  /**
   * Register user
   *
   * @param regularUserCreateDTO {@link RegularUserCreateDTO}
   * @return {@link RegistrationResponse}
   * @throws NotFoundError if username exists
   */
  public RegistrationResponse register(RegularUserCreateDTO regularUserCreateDTO) {
    User user = userService.create(regularUserCreateDTO);
    log.info("user registered: {}", user);
    UserOutDTO userOutDTO = userMapper.fromUserToUserOutDTO(user);
    ActivationCode activationCode = user.getActivationCodes().get(0);
//    EventPublisher.publishUserRegisteredEvent(user);
    messageProducer.sendUserRegisteredMessage(user);

    return RegistrationResponseBuilder.aRegistrationResponse()
        .withUser(userOutDTO)
        .withUuid(activationCode.getUuidToken())
        .build();
  }

  /**
   * Activate user
   *
   * @param request {@link ActivationRequest}
   * @return {@link ActivationResponse}
   * @throws NotFoundError if user or activation code not found
   * @throws GeneralError if user already activated or activation code expired or used
   */
  @Transactional
  public ActivationResponse activateUser(ActivationRequest request) {
    User user = userService.findByUsernameOr404(request.getUsername());
    if (user.isActivated()) {
      throw new GeneralError("User already activated");
    }

    ActivationCode activationCode =
        activationCodeRepository
            .findByCodeAndUserIdAndUuidToken(request.getCode(), user.getId(), request.getUuid())
            .orElseThrow(
                () ->
                    new NotFoundError(
                        "Activation code not found",
                        Map.of("code", request.getCode(), "userId", user.getId())));

    if (activationCode.isExpired() || activationCode.isUsed()) {
      throw new GeneralError("Activation code expired or already used, please request a new one.");
    }

    user.setActivated(true);
    activationCode.setUsed(true);
    userRepository.save(user);

    return buildActivationResponse(user);
  }

  private ActivationResponse buildActivationResponse(User user) {
    UserDetails userDetails = customUserDetailsService.loadUserByUsername(user.getUsername());
    String token = jwtTokenUtil.generateToken(userDetails);
    return ActivationResponseBuilder.anActivationResponse()
        .withMessage("User activated")
        .withUsername(user.getUsername())
        .withJwtToken(token)
        .build();
  }

  public RegistrationResponse resendActicationCode(String username) {
    User user = userService.findByUsernameOr404(username);
    userService.associateUserWithActivationCode(user);
    List<ActivationCode> activationCodes = userRepository.saveAndFlush(user).getActivationCodes();
    ActivationCode activationCode = activationCodes.get(activationCodes.size() - 1);
    activationCodeService.sendActivationCode(activationCode);

    return RegistrationResponseBuilder.aRegistrationResponse()
        .withUuid(activationCode.getUuidToken())
        .withUser(userMapper.fromUserToUserOutDTO(activationCode.getUser()))
        .build();
  }

  public RegistrationResponse completeUserRegistration(
      Long userId, CompleteRegistrationRequest request) {
    if (!Objects.equals(request.getId(), userId)) {
      // todo change to 403 error - forbidden
      throw new GeneralError("You can't complete registration for other user");
    }

    User updatedUser = userService.completeRegistration(userId, request);
    log.info("Updated user: {} ", updatedUser);
//    eventPublisher.publishEvent(new UserRegisteredEvent(this, updatedUser));
    messageProducer.sendUserRegisteredMessage(updatedUser);


    return RegistrationResponseBuilder.aRegistrationResponse()
        .withUser(userMapper.fromUserToUserOutDTO(updatedUser))
        .withUuid(updatedUser.getLastActivationCode().getUuidToken())
        .build();
  }

  /**
   * Send forgot password code
   *
   * @param username username
   * @return UUID token of the activation code
   * @throws NotFoundError if user not found
   */
  public String sendForgotPasswordCode(String username) {
    log.info("Sending forgot password code to user {}", username);
    User user = userService.findByUsernameOr404(username);
    if (StringUtils.hasText(user.getProviderId())) {
      throw new GeneralError(
          "User registered without password", Map.of("username", username, "hasProviderId", true));
    }
    userService.associateUserWithActivationCode(user);
    List<ActivationCode> activationCodes = userRepository.saveAndFlush(user).getActivationCodes();
    ActivationCode activationCode = activationCodes.get(activationCodes.size() - 1);

    activationCodeService.sendActivationCode(activationCode);
    return activationCode.getUuidToken();
  }

  /**
   * Change password
   *
   * @param changePasswordRequest
   * @throws NotFoundError if activation code not found | or user not found
   */
  public void changePassword(ChangePasswordRequest changePasswordRequest) {
    String code = changePasswordRequest.getCode();
    String uuid = changePasswordRequest.getUuid();
    String username = changePasswordRequest.getUsername();
    User user = userService.findByUsernameOr404(username);

    ActivationCode activationCode =
        activationCodeRepository
            .findByCodeAndUserIdAndUuidToken(code, user.getId(), uuid)
            .orElseThrow(
                () ->
                    new NotFoundError(
                        "Activation code not found", Map.of("code", code, "userId", user.getId())));

    if (activationCode.isExpired() || activationCode.isUsed()) {
      throw new GeneralError("Activation code expired or already used, please request a new one.");
    }

    String encodedPassword = passwordEncoder.encode(changePasswordRequest.getPassword());
    user.setPassword(encodedPassword);
    activationCode.setUsed(true);
    userRepository.save(user);
  }
}
