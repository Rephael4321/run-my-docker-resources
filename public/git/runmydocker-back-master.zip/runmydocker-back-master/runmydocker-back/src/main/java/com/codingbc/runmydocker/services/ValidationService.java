package com.codingbc.runmydocker.services;

import com.codingbc.runmydocker.exceptions.BadRequest;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class ValidationService {
  public void validateAppId(Long appIdFromPath, Long appIdFromRequest) {
    if (!appIdFromPath.equals(appIdFromRequest)) {
      log.error("appId in the path does not match appId in the request body");
      throw new BadRequest(
          "appId in the path does not match appId in the request body",
          Map.of("appIdFromPath", appIdFromPath, "appIdFromRequest", appIdFromRequest));
    }
  }
}
