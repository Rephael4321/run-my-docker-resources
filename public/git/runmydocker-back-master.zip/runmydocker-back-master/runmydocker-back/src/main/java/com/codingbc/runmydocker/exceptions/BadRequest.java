/*
 * Copyright (c) 2024.
 */

package com.codingbc.runmydocker.exceptions;

import java.util.Map;
import org.springframework.http.HttpStatus;

public class BadRequest extends BaseException {

  public BadRequest() {
    super(HttpStatus.BAD_REQUEST, "Bad Request", null);
  }

  public BadRequest(String message) {
    super(HttpStatus.BAD_REQUEST, message, null);
  }

  public BadRequest(String message, Map<String, Object> additionalInfo) {
    super(HttpStatus.BAD_REQUEST, message, additionalInfo);
  }
}
