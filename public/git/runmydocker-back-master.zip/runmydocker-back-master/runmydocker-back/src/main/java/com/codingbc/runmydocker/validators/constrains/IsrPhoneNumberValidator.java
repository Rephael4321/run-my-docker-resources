package com.codingbc.runmydocker.validators.constrains;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.StringUtils;

@Slf4j
public class IsrPhoneNumberValidator implements ConstraintValidator<PhoneValidator, String> {

  @Override
  public boolean isValid(String value, ConstraintValidatorContext context) {

    log.info("Validating phone number: {}", value);
    return StringUtils.hasText(value)
        && (value.matches("\\+972-\\d{9}") || value.matches("\\+972-[1-9]{9}"));
  }
}
