package com.codingbc.runmydocker.jobs;

import com.codingbc.runmydocker.models.UserApplication;
import com.codingbc.runmydocker.repositories.UserApplicationRepository;
import com.codingbc.runmydocker.util.Dates;
import com.github.dockerjava.api.DockerClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

@Component
@Slf4j
public class SyncDB {
  private final UserApplicationRepository userApplicationRepository;
  private final DockerClient dockerClient;

  public SyncDB(UserApplicationRepository userApplicationRepository, DockerClient dockerClient) {
    this.userApplicationRepository = userApplicationRepository;
    this.dockerClient = dockerClient;
  }

  @PostConstruct
  private void init() {
    log.info("SyncDB job started");
  }

  @Scheduled(fixedRate = 60000)
  private void syncApplicationsStatus() {
    for (UserApplication userApplication : userApplicationRepository.findAll()) {
      if (userApplication.getContainerId() == null) continue;
      String appName = userApplication.getAppName();
      String containerStatus =
          dockerClient.inspectContainerCmd(appName).exec().getState().getStatus();
      boolean isContainerRunningInDB = userApplication.isRunning();

      if (containerStatus == null) {
        log.info("container status is null for {}", appName);
        return;
      }

      if (!containerStatus.equals("running") && isContainerRunningInDB) {
        log.info("found running container in db but not running in docker for {}", appName);
        userApplication.setRunning(false);
        userApplication.setLastUsed(Dates.nowUTC());
        userApplicationRepository.save(userApplication);
      }
    }
  }
}
