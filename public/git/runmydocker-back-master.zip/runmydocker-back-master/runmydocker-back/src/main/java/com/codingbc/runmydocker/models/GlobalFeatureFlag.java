package com.codingbc.runmydocker.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.codingbc.runmydocker.BaseEntity;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "global_feature_flags")
@Getter
@Setter
public class GlobalFeatureFlag extends BaseEntity {

    @Column(unique = true, nullable = false)
    private String flagName;
    
    @Column(nullable = false)
    private Boolean isEnabled;


}
