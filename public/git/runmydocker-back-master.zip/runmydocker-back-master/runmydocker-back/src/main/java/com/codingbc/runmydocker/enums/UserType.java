/*
 * Copyright (c) 2024.
 */

package com.codingbc.runmydocker.enums;

public enum UserType {
  REGULAR,
  OAUTH2
}
