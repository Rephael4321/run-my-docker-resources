package com.codingbc.runmydocker.events.rabbit;

import com.codingbc.runmydocker.configuration.RabbitConfig;
import com.codingbc.runmydocker.events.rabbit.messages.MessageAction;
import com.codingbc.runmydocker.factories.ContainerCreationStrategy;
import com.codingbc.runmydocker.factories.ContainerCreationStrategyFactory;
import com.codingbc.runmydocker.models.AppMessage;
import com.codingbc.runmydocker.models.User;
import com.codingbc.runmydocker.models.UserApplication;
import com.codingbc.runmydocker.repositories.AppMessageRepository;
import com.codingbc.runmydocker.services.ActivationCodeService;
import com.codingbc.runmydocker.services.DockerService;
import com.codingbc.runmydocker.services.UserApplicationService;
import com.codingbc.runmydocker.util.JsonUtil;
import com.rabbitmq.client.Channel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.Map;
import java.util.UUID;

@Component
public class MessageConsumer {
  private final Logger logger = LoggerFactory.getLogger(MessageConsumer.class);
  @Autowired
  private JsonUtil jsonUtil;
  @Autowired
  private AppMessageRepository appMessageRepository;
  @Autowired
  private ActivationCodeService activationCodeService;
  @Autowired
  private DockerService dockerService;
  @Autowired
  private UserApplicationService userApplicationService;

  @RabbitListener(queues = { RabbitConfig.USER_APP_QUEUE, RabbitConfig.AUTH_QUEUE }, ackMode = "MANUAL")
  public void handleAppMessage(String payload, Channel channel, Message message) throws IOException {
    try {
      AppMessage appMessage = jsonUtil.parseToJson(payload, AppMessage.class);
      logger.info("[Messages-Consumer] Received App message: {}", appMessage.toString());
      processAppMessage(appMessage);
      ackMessage(channel, message, appMessage.getMessageId());
    } catch (Exception e) {
      logger.error("[UserApp-Consumer] Error handling message: {}", e.getMessage());
      channel.basicNack(message.getMessageProperties().getDeliveryTag(), false, false);
    }
  }

  private void processAppMessage(AppMessage appMessage) {
    try {
      logger.info("[UserApp-Consumer] Processing message: {}", appMessage.toString());
      MessageAction action = appMessage.getAction();
      System.out.println(action);
      switch (action) {
        case CREATE_CONTAINER:
          handleCreateContainer(appMessage);
          break;
        case CONTAINER_CREATED:
          handleContainerCreated(appMessage);
          break;
        case USER_REGISTERED:
          handleUserRegistered(appMessage);
          break;
        default:
          logger.error("[UserApp-Consumer] Unknown action: {}", action);
      }
      appMessageRepository.updateIsReadByMessageId(true, appMessage.getMessageId());
    } catch (Exception e) {
      logger.error("[UserApp-Consumer] Error processing message: {}", e.getMessage());
    }
  }

  private void handleUserRegistered(AppMessage message) {
    User user = jsonUtil.parseToJson(message.getPayload().toString(), User.class);
    activationCodeService.sendActivationCode(user.getUsername());
  }

  private void handleCreateContainer(AppMessage appMessage) {
    logger.info("[UserApp-Consumer] Create container event processing");
    UserApplication userApplication = jsonUtil.parseToJson(appMessage.getPayload().toString(), UserApplication.class);
    String dockerImage = userApplication.getDockerImage();
    boolean imgFoundOnLocal = dockerService.isImageAvailableLocally(dockerImage);
    logger.info("[UserApp-Consumer] Docker image found on local? : {}", imgFoundOnLocal);

    // comment out for investigation and pull image issue
    // ContainerCreationStrategy creationStrategy =
    // ContainerCreationStrategyFactory.getFactory(imgFoundOnLocal,
    // dockerService);
    // logger.info("[UserApp-Consumer] Creating container: {}",
    // creationStrategy.getClass().getSimpleName());
    // creationStrategy.createContainer(userApplication);

    if (imgFoundOnLocal) {
      dockerService.createDockerContainer(userApplication);
    } else {
      logger.info("[UserApp-Consumer] Image not found locally, pulling image: {}", dockerImage);
      dockerService.pullImgAsync(userApplication);
      logger.info("[UserApp-Consumer] After pullImgAsync");
    }

  }

  private void handleContainerCreated(AppMessage appMessage) {
    logger.info("[UserApp-Consumer] Created Container event processing");
    Map<String, Object> createdContainerData = jsonUtil.parseToMap(appMessage.getPayload().toString());
    String containerId = createdContainerData.get("containerId").toString();
    UserApplication userApplication = jsonUtil.parseToJson(createdContainerData.get("application").toString(),
        UserApplication.class);
    if (containerId == null) {
      logger.error(
          "[UserApp-Consumer] Container ID is null for user application: {}",
          userApplication.getAppName());
      return;
    }
    userApplicationService.onDockerContainerCreated(containerId, userApplication.getId());
  }

  private void ackMessage(Channel channel, Message message, UUID messageId) {
    try {
      channel.basicAck(message.getMessageProperties().getDeliveryTag(), false);
    } catch (IOException e) {
      logger.error("[Auth-Consumer] Error acknowledging message: {}", e.getMessage());
      handleRejection(channel, message, messageId);
    }
  }

  private void handleRejection(Channel channel, Message message, UUID messageId) {
    try {
      int retryCount = (Integer) message.getMessageProperties().getHeaders().getOrDefault("retryCount", 0);
      if (retryCount < 3) {
        logger.info("[Auth-Consumer] Retrying message: {}", message);
        channel.basicReject(message.getMessageProperties().getDeliveryTag(), false);
      } else {
        logger.error("[Auth-Consumer] Max retries reached for message: {}", message);
        channel.basicReject(message.getMessageProperties().getDeliveryTag(), true);
      }
    } catch (IOException e) {
      logger.error(
          "[Auth-Consumer] Error handling rejection: {} messageId {}", e.getMessage(), messageId);
    }
  }
}
