/*
 * Copyright (c) 2024.
 */

package com.codingbc.runmydocker.services;

import com.codingbc.runmydocker.enums.ContainerCreationStatus;
import com.codingbc.runmydocker.events.EventPublisher;
import com.codingbc.runmydocker.events.rabbit.MessageProducer;
import com.codingbc.runmydocker.exceptions.NotFoundError;
import com.codingbc.runmydocker.models.UserApplication;
import com.codingbc.runmydocker.repositories.UserApplicationRepository;
import com.github.dockerjava.api.DockerClient;
import com.github.dockerjava.api.async.ResultCallback;
import com.github.dockerjava.api.async.ResultCallbackTemplate;
import com.github.dockerjava.api.command.*;
import com.github.dockerjava.api.exception.BadRequestException;
import com.github.dockerjava.api.exception.ConflictException;
import com.github.dockerjava.api.exception.DockerException;
import com.github.dockerjava.api.exception.NotFoundException;
import com.github.dockerjava.api.model.*;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;

import com.github.dockerjava.core.InvocationBuilder;
import com.github.dockerjava.core.command.LogContainerResultCallback;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException.NotFound;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

@Service
@Slf4j
public class DockerService {

  private final MessageProducer messageProducer;

  @Value("${container.validation.time}")
  private int validationTime;

  private final DockerClient dockerClient;
  private final EventPublisher eventPublisher;
  private final Environment environment;

  private final UserApplicationRepository userApplicationRepository;

  public DockerService(
      DockerClient dockerClient,
      EventPublisher eventPublisher,
      Environment environment,
      UserApplicationRepository userApplicationRepository,
      MessageProducer messageProducer) {
    this.dockerClient = dockerClient;
    this.eventPublisher = eventPublisher;
    this.environment = environment;
    this.userApplicationRepository = userApplicationRepository;
    this.messageProducer = messageProducer;
  }

  public boolean isImageAvailableLocally(String imageName) {
    try {
      InspectImageResponse imageResponse = dockerClient.inspectImageCmd(imageName).exec();
      log.info("Image {} found locally.", imageName);
      return imageResponse != null;
    } catch (Exception e) {
      log.info("Image {} not found locally. Need to pull.", imageName);
      return false;
    }
  }

  /**
   * Check if the image is available on docker hub
   *
   * @param imageName the name of the image
   * @return true if the image is available on docker hub
   */
  public boolean isImgOnDockerHub(String imageName) {
    String searchImgTerm = imageName.contains(":") ? imageName.split(":")[0] : imageName;
    List<SearchItem> exec = dockerClient.searchImagesCmd(searchImgTerm).exec();
    log.info("Searching for image: {}", searchImgTerm);

    return exec.stream().anyMatch(searchItem -> searchItem.getName().equals(searchImgTerm));
  }

  public void onImagePulled(UserApplication userApplication) {
    log.info(
        "Handeling container creation for image: {} and user application: {}",
        userApplication.getDockerImage(),
        userApplication.getAppName());
    // updateCreationStatus(ContainerCreationStatus.CREATING,
    // userApplication.getId());
    createDockerContainer(userApplication);
  }

  private void updateCreationStatus(ContainerCreationStatus status, long appId) {
    userApplicationRepository.updateStatusById(status, appId);
  }

  @Async()
  public void pullImgAsync(UserApplication userApplication) {
    log.info(
        "start to pull image: {} for user: {}",
        userApplication.getDockerImage(),
        userApplication.getUsername());
    try {

      // updateCreationStatus(ContainerCreationStatus.PENDING,
      // userApplication.getId());
      PullImageCmd pullImageCmd = dockerClient.pullImageCmd(userApplication.getDockerImage());
      pullImageCmd
          .exec(
              new PullImageResultCallback() {
                @Override
                public void onComplete() {
                  log.info("Image pulled {}", userApplication.getDockerImage());
                  onImagePulled(userApplication);
                }

                @Override
                public void onError(Throwable throwable) {
                  super.onError(throwable);
                }
              })
          .awaitCompletion();
    } catch (InterruptedException | DockerException e) {
      log.error("Error pulling image: " + userApplication.getDockerImage());
      log.error(e.getMessage());

      userApplicationRepository.updateCreationErrorById(
          e.getMessage(), ContainerCreationStatus.FAILED, userApplication.getId());
    }
  }

  /**
   * Create a docker container
   *
   * @param userApplication the user application
   * @throws NotFoundException   if the image is not found
   * @throws ConflictException   if container with the same name already exists
   * @throws BadRequestException invalid container name
   */
  public void createDockerContainer(UserApplication userApplication) {
    log.info("Creating container: {}", userApplication.getAppName());
    CreateContainerCmd createContainerCmd = buildCreateContainerCmd(userApplication);

    try {
      executeCreateContainerCmd(createContainerCmd, userApplication);
    } catch (DockerException exception) {
      handleDockerException(userApplication, exception);
      throw exception;
    }
  }

  /**
   * Start the container
   *
   * @param containerName the name of the container
   * @throws DockerException if the container is not found or there is an error
   *                         starting the
   *                         container
   */
  public void startContainer(String containerName) {
    try {
      StartContainerCmd startContainerCmd = dockerClient.startContainerCmd(containerName);
      startContainerCmd.exec();
    } catch (DockerException e) {
      log.error("Error starting container: " + containerName);
      log.error(e.toString());
      throw e;
    }
  }

  /**
   * Stop the container
   *
   * @param containerName the name of the container
   * @throws DockerException if the container is not found or there is an error
   *                         stopping the
   *                         container
   */
  public void stopContainer(String containerName) {
    try {
      StopContainerCmd stopContainerCmd = dockerClient.stopContainerCmd(containerName);
      stopContainerCmd.exec();
    } catch (DockerException e) {
      log.error("Error stopping container: " + containerName);
      log.error(e.toString());
      throw e;
    }
  }

  public void stopContainer1(String containerName) {
    String url = "http://localhost:2375/containers/" + containerName + "/" + "stop";

    RestTemplate restTemplate = new RestTemplate();
    String s = restTemplate.postForObject(url, null, String.class);
    log.info("Container stopped: " + s);
  }

  /**
   * Remove the container
   *
   * @param containerName the name of the container
   * @throws NotFoundException if the container is not found
   */
  public void removeContainer(String containerName) {
    try {
      dockerClient.removeContainerCmd(containerName).exec();
    } catch (NotFoundException e) {
      log.error("Error removing container: " + containerName);
      throw new NotFoundError(
          "Container not found", Collections.singletonMap("containerName", containerName));
    }
  }

  private CreateContainerCmd buildCreateContainerCmd(UserApplication userApplication) {
    ExposedPort exposedPort = ExposedPort.tcp(userApplication.getContainerPort());
    Ports portBindings = new Ports();
    portBindings.bind(exposedPort, Ports.Binding.bindPort(userApplication.getPort()));

    return dockerClient
        .createContainerCmd(userApplication.getDockerImage())
        .withName(userApplication.getAppName())
        .withExposedPorts(exposedPort)
        .withLabels(Collections.singletonMap("created_by", "runmydocker"))
        .withHostConfig(HostConfig.newHostConfig().withPortBindings(portBindings));
  }

  /**
   * Execute the create container command
   *
   * @param createContainerCmd the create container command
   * @param userApplication    the user application
   * @throws NotFoundException if the image is not found
   * @throws ConflictException if container with the same name already exists
   */
  private void executeCreateContainerCmd(
      CreateContainerCmd createContainerCmd, UserApplication userApplication) {
    CreateContainerResponse createContainerResponse = createContainerCmd.exec();
    // EventPublisher.publishContainerCreatedEvent(createContainerResponse,
    // userApplication);
    messageProducer.sendContainerCreatedMessage(userApplication, createContainerResponse);
  }

  private void handleDockerException(UserApplication userApplication, DockerException exception) {
    log.error("Error creating container: " + userApplication.getAppName());
    log.error(exception.toString());
    userApplicationRepository.updateCreationErrorAndStatusById(
        exception.getMessage(), ContainerCreationStatus.FAILED, userApplication.getId());
  }

  public Optional<Boolean> isContainerExists(String containerName) {
    try {
      InspectContainerResponse containerResponse = dockerClient.inspectContainerCmd(containerName).exec();
      return Optional.of(containerResponse != null);
    } catch (DockerException e) {
      return Optional.empty();
    }
  }

  public boolean isContainerRunning(String containerName) {
    try {
      InspectContainerResponse containerResponse = dockerClient.inspectContainerCmd(containerName).exec();
      return Boolean.TRUE.equals(containerResponse.getState().getRunning());
    } catch (Exception e) {
      log.error(e.getMessage());
      log.error("Container {} not found.", containerName);
      return false;
    }
  }

  /**
   * Inspect the docker container
   *
   * @param containerName the name of the container
   * @return InspectContainerResponse if the container is found
   * @throws NotFoundException if the container is not found
   */
  public InspectContainerResponse inspectDocker(String containerName) {
    return dockerClient.inspectContainerCmd(containerName).exec();
  }

  public boolean findIfDockerImageExists(String imageName) {
    try {
      InspectImageResponse imageResponse = dockerClient.inspectImageCmd(imageName).exec();
      return imageResponse != null;
    } catch (Exception e) {
      return false;
    }
  }

  public String getContainerLogs(String containerName) {
    log.info("Getting logs for container: {}", containerName);
    RestTemplate restTemplate = new RestTemplate();
    String url = "http://localhost:2375/containers/" + containerName + "/logs?stdout=true&stderr=true";
    try {

      ResponseEntity<String> responseEntity = restTemplate.exchange(url, HttpMethod.GET, null, String.class);
      return responseEntity.getBody();
    } catch (RestClientException e) {
      if (e instanceof NotFound) {
        log.error("Container {} not found.", containerName);
        throw new NotFoundException("Container not found");
      }
      log.error("Error getting logs for container: " + containerName);
      log.error(e.toString());
      throw e;
    }
  }

  @Async
  public CompletableFuture<Boolean> validateContainerHealthAsync(String containerName) {
    try {
      log.info("Validating container health: {}", containerName);
      log.info("Starting container: {}", containerName);
      startContainer(containerName);
      Thread.sleep(validationTime);
      InspectContainerResponse containerInfo = dockerClient.inspectContainerCmd(containerName).exec();
      Boolean isContainerRunning = containerInfo.getState().getRunning();
      return CompletableFuture.completedFuture(isContainerRunning);
    } catch (Exception ex) {
      log.info("Error validating container health: " + containerName);
      log.error(ex.getMessage());
      return CompletableFuture.completedFuture(false);
    }
  }

  public byte[] getContainerLogsForFile(String containerName) throws InterruptedException {
    ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
    try (LogContainerCmd logContainerCmd = dockerClient.logContainerCmd(containerName)) {
      logContainerCmd
          .withStdOut(true)
          .withStdErr(true)
          .withFollowStream(false)
          .exec(
              new ResultCallbackTemplate<>() {
                @Override
                public void onNext(Frame item) {
                  try {
                    log.info(item.toString());
                    outputStream.write(item.getPayload());
                  } catch (IOException e) {
                    System.out.println("Error writing to output stream ->" + e.getMessage());
                  }
                }
              })
          .awaitCompletion();

      return outputStream.toByteArray();
    }
  }
}
