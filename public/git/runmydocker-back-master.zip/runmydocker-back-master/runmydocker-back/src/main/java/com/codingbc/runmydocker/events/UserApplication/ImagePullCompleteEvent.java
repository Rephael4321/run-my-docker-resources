/*
 * Copyright (c) 2024.
 */

package com.codingbc.runmydocker.events.UserApplication;

import com.codingbc.runmydocker.models.UserApplication;
import org.springframework.context.ApplicationEvent;

public class ImagePullCompleteEvent extends ApplicationEvent {
  private final UserApplication userApplication;

  public ImagePullCompleteEvent(Object source, UserApplication userApplication) {
    super(source);
    this.userApplication = userApplication;
  }

  public UserApplication getUserApplication() {
    return userApplication;
  }
}
