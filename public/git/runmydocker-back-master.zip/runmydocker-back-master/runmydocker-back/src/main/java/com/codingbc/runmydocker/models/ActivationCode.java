package com.codingbc.runmydocker.models;

import com.codingbc.runmydocker.BaseEntity;
import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "activation_codes")
@JsonIgnoreProperties(ignoreUnknown = true)
public class ActivationCode extends BaseEntity {

  private String code;

  @Column(nullable = false)
  private LocalDateTime expirationTime;

  @Column(name = "uuid_token", nullable = false, unique = true)
  private String uuidToken;

  private boolean used = false;

  @JsonBackReference
  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "user_id")
  private User user;

  public ActivationCode() {
  }

  public ActivationCode(
      long id, String code, LocalDateTime expirationTime, User user, boolean used) {
    super(id);
    this.code = code;
    this.expirationTime = expirationTime;
    this.user = user;
    this.uuidToken = UUID.randomUUID().toString();
    this.used = used;

  }

  public ActivationCode(long id) {
    super(id);
    this.uuidToken = UUID.randomUUID().toString();
  }

  public User getUser() {    
    return user;
  }

  public void setUser(User user) {
    this.user = user;
  }

  public String getCode() {
    return code;
  }

  public void setCode(String code) {
    this.code = code;
  }

  public LocalDateTime getExpirationTime() {
    return expirationTime;
  }

  public void setExpirationTime(LocalDateTime expirationTime) {
    this.expirationTime = expirationTime;
  }

  public String getUuidToken() {
    return uuidToken;
  }

  public void setUuidToken(String uuidToken) {
    this.uuidToken = uuidToken;
  }

  public boolean isUsed() {
    return used;
  }

  public void setUsed(boolean used) {
    this.used = used;
  }


  public boolean isExpired() {
    return LocalDateTime.now().isAfter(expirationTime);
  }
}
