package com.codingbc.runmydocker.exceptions;

import com.codingbc.runmydocker.dto.ApiResponse;
import com.github.dockerjava.api.exception.DockerException;
import java.util.Collections;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.NotNull;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@Slf4j
@ControllerAdvice
public class ApiExceptionHandler extends ResponseEntityExceptionHandler {

  private ResponseEntity<Object> buildResponseEntity(ApiResponse<?> error) {
    log.error(error.getMessage());
    return new ResponseEntity<>(error, HttpStatus.valueOf(error.getCode()));
  }

  @ExceptionHandler(Exception.class)
  public ResponseEntity<Object> handleAllExceptions(Exception error) {
    HttpStatus status;
    Map<String, Object> additionalInfo = Collections.emptyMap();

    log.debug(error.getClass().getName());
    if (error instanceof DockerException) {
      var dockerException = (DockerException) error;
      int httpStatus = dockerException.getHttpStatus();
      status = HttpStatus.valueOf(httpStatus);
    } else if (error instanceof NotFoundError) {
      status = HttpStatus.NOT_FOUND;
      additionalInfo = ((NotFoundError) error).getAdditionalInfo();

    } else if (error instanceof NotAnActivateUserError) {
      status = HttpStatus.UNAUTHORIZED;
      additionalInfo = ((NotAnActivateUserError) error).getAdditionalInfo();

    } else if (error instanceof ConflictError) {
      status = HttpStatus.CONFLICT;
      additionalInfo = ((ConflictError) error).getAdditionalInfo();

    } else if (error instanceof GeneralError) {
      status = HttpStatus.INTERNAL_SERVER_ERROR;
      additionalInfo = ((GeneralError) error).getAdditionalInfo();

    } else if (error instanceof BadRequest) {
      status = HttpStatus.BAD_REQUEST;
      additionalInfo = ((BadRequest) error).getAdditionalInfo();
    }
    else if (error instanceof BadCredentialsException) {
      status = HttpStatus.UNAUTHORIZED;
    }
    else {
      status = HttpStatus.INTERNAL_SERVER_ERROR;
    }




    var response = ApiResponse.error(error.getMessage(), status, additionalInfo);
    return buildResponseEntity(response);
  }

  @NotNull
  @Override
  protected ResponseEntity<Object> handleMethodArgumentNotValid(
      MethodArgumentNotValidException ex,
      HttpHeaders headers,
      HttpStatus status,
      WebRequest request) {
    ValidationError error = new ValidationError(HttpStatus.BAD_REQUEST);
    ex.getBindingResult().getAllErrors().forEach(errorObject -> {
      String fieldName = ((org.springframework.validation.FieldError) errorObject).getField();
      String errorMessage = errorObject.getDefaultMessage();
      error.addValidationError(fieldName, errorMessage);
    });
    log.info(error.toString());
    var errorResponse = ApiResponse.error(error.getMessage(), HttpStatus.BAD_REQUEST,
        error.getValidationsError());
    return buildResponseEntity(errorResponse);
  }

  @Override
  protected ResponseEntity<Object> handleMissingServletRequestParameter(
      MissingServletRequestParameterException ex,
      HttpHeaders headers,
      HttpStatus status,
      WebRequest request) {
    String message = ex.getParameterName() + " parameter is missing";
    var errResponse = ApiResponse.error(message, HttpStatus.BAD_REQUEST, Map.of(ex.getParameterName(), "missing"));
    return buildResponseEntity(errResponse);
  }

  @Override
  protected ResponseEntity<Object> handleHttpMessageNotReadable(
      HttpMessageNotReadableException ex,
      HttpHeaders headers,
      HttpStatus status,
      WebRequest request) {
    ServletWebRequest servletWebRequest = (ServletWebRequest) request;
    log.info("{} to {}", servletWebRequest.getHttpMethod(), servletWebRequest.getRequest().getServletPath());
    String error = "Malformed JSON request";

    return buildResponseEntity(ApiResponse.error(error, HttpStatus.BAD_REQUEST, null));

  }
}