package com.codingbc.runmydocker.exceptions;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape;

import java.time.LocalDateTime;

import lombok.Data;
import org.springframework.http.HttpStatus;

@Data
public class ApiError {
  private HttpStatus status;

  @JsonFormat(shape = Shape.STRING, pattern = "yyyy-MM-dd hh:mm:ss")
  private LocalDateTime timeStamp;

  private String message;

  private ApiError() {
    timeStamp = LocalDateTime.now();
  }

  public ApiError(HttpStatus status) {
    this();
    this.status = status;
  }

  public ApiError(HttpStatus status, String message) {
    this(status);
    setMessage(message);
  }
}
