/*
 * Copyright (c) 2024.
 */

package com.codingbc.runmydocker.services;

import static com.codingbc.runmydocker.enums.AppActions.CHANGE_VERSION;
import static com.codingbc.runmydocker.enums.AppActions.DELETE;
import static com.codingbc.runmydocker.enums.AppActions.START;
import static com.codingbc.runmydocker.enums.AppActions.STOP;

import com.codingbc.runmydocker.builders.UserApplicationBuilder;
import com.codingbc.runmydocker.commands.UserApplication.BaseAppCmd;
import com.codingbc.runmydocker.commands.UserApplication.DeleteAppCmd;
import com.codingbc.runmydocker.commands.UserApplication.StartAppCmd;
import com.codingbc.runmydocker.dto.UserApplication.*;
import com.codingbc.runmydocker.enums.AppStatus;
import com.codingbc.runmydocker.enums.ContainerCreationStatus;
import com.codingbc.runmydocker.enums.FeatureFlags;
import com.codingbc.runmydocker.events.EventPublisher;
import com.codingbc.runmydocker.events.rabbit.MessageProducer;
import com.codingbc.runmydocker.exceptions.BadRequest;
import com.codingbc.runmydocker.exceptions.ConflictError;
import com.codingbc.runmydocker.exceptions.GeneralError;
import com.codingbc.runmydocker.exceptions.NotFoundError;
import com.codingbc.runmydocker.factories.AppCmdFactory;
import com.codingbc.runmydocker.mappers.UserApplication.IUserApplicationMapper;
import com.codingbc.runmydocker.models.User;
import com.codingbc.runmydocker.models.UserApplication;
import com.codingbc.runmydocker.models.migrations.UserApplicationToMigrate;
import com.codingbc.runmydocker.repositories.UserApplicationRepository;
import com.codingbc.runmydocker.util.Dates;
import com.codingbc.runmydocker.util.Generators;
import com.github.dockerjava.api.command.CreateContainerResponse;
import com.github.dockerjava.api.exception.DockerException;

import java.util.*;
import java.util.stream.Collectors;
import javax.annotation.PostConstruct;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class UserApplicationService {

  private static int INITIAL_REMAINING_TIME;

  private final IUserApplicationMapper userApplicationMapper;
  private final UserApplicationRepository userApplicationRepository;
  private final UserService userService;
  protected final DockerService dockerService;
  private final FeatureFlagService featureFlagService;
  private final MessageProducer messageProducer;

  @Value("${appsCapacity}")
  public static int appsCapacity;

  public static int USER_APPS_CAPACITY;

  @Autowired
  private Environment environment;

  @PostConstruct
  public void init() {
    USER_APPS_CAPACITY = Integer.parseInt(Objects.requireNonNull(environment.getProperty("appsCapacity")));
  }

  public UserApplicationService(
      IUserApplicationMapper userApplicationMapper,
      UserApplicationRepository userApplicationRepository,
      @Lazy UserService userService,
      DockerService dockerService,
      FeatureFlagService featureFlagService, MessageProducer messageProducer) {
    this.userApplicationMapper = userApplicationMapper;
    this.dockerService = dockerService;
    this.featureFlagService = featureFlagService;
    this.messageProducer = messageProducer;
    INITIAL_REMAINING_TIME = 6000;
    this.userApplicationRepository = userApplicationRepository;
    this.userService = userService;
  }

  private boolean isAppNameTaken(String appName) {
    return userApplicationRepository.existsByAppName(appName);
  }

  /**
   * Create a new application
   *
   * @param createAppDto UserApplicationCreateDTO
   * @return UserApplication
   * @throws NotFoundError if user not found
   * @throws BadRequest    if user reached to apps limit capacity or validation
   *                       error
   * @throws ConflictError if application name is taken
   * @throws NotFoundError if docker image not found
   */
  public UserApplication create(UserApplicationCreateDTO createAppDto) {
    User user = userService.findByUsernameOr404(createAppDto.getUsername());
    validateBeforeCreateApplication(createAppDto, user);
    int port = genrateHostPort(); // can throw general error;
    UserApplication userApplication = buildUserApplication(createAppDto, user, port, null);
    UserApplication savedUserApplication = userApplicationRepository.saveAndFlush(userApplication);
    // EventPublisher.publishCreateContainerEvent(userApplication); // async
    messageProducer.sendCreateContainerMessage(savedUserApplication);

    log.info("User({}) is creating a new application", createAppDto.getUsername());

    return savedUserApplication;
  }

  public void createFromMigration(UserApplicationToMigrate application) {
    // check if user exists
    User user = userService.findByUsernameOr404(application.getUsername());
    // check if user already have container with the same name or app has container
    // Id already
    userApplicationRepository
        .findByAppName(application.getAppName())
        .ifPresent(
            userApplication -> {
              if (userApplication.getContainerId() != null) {
                // delete the container
                dockerService.removeContainer(userApplication.getAppName());
                UserApplicationCreateDTO dto = new UserApplicationCreateDTO();
                dto.setAppName(application.getAppName());
                dto.setDockerImage(application.getDockerImage());
                dto.setContainerPort(application.getMappingPort());
                dto.setUsername(application.getUsername());
                UserApplication userApplication1 = create(dto);
              }
            });
    // else create the container
    UserApplicationCreateDTO dto = new UserApplicationCreateDTO();
    dto.setAppName(application.getAppName());
    dto.setDockerImage(application.getDockerImage());
    dto.setContainerPort(application.getMappingPort());
    dto.setUsername(application.getUsername());
    UserApplication userApplication1 = create(dto);
  }

  /**
   * Change the version of the application
   *
   * @param changeVersionRequest ChangeVersionRequest
   * @throws NotFoundError if application not found
   * @throws NotFoundError if docker image not found
   * @throws BadRequest    if application is running or ids are not matching
   */
  public void changeVersion(long appId, ChangeVersionRequest changeVersionRequest) {
    log.info("User({}) is changing app version.", changeVersionRequest.getUsername());
    if (changeVersionRequest.getAppId() != appId) {
      log.error("Id's are not matching in the request body and path");
      throw new BadRequest("Mismatched id's in the request body and path");
    }

    BaseAppCmd cmd = AppCmdFactory.getCmd(
        CHANGE_VERSION, dockerService, userApplicationRepository, changeVersionRequest);
    cmd.execute();
  }

  private NewApplicationResponse proccessUserApplication(
      UserApplicationCreateDTO dto, UserApplication existingApp) {
    UserApplication userApplication = null;

    try {
      userApplication = saveOrUpdateApplication(dto, existingApp);
      createDockerContainer(userApplication);
      return userApplicationMapper.toNewApplicationResponse(userApplication);
    } catch (Exception e) {
      updateApplicationStatusOnError(e, userApplication);
      throw e;
    }
  }

  /**
   * Create a docker container for the application
   *
   * @param userApplication UserApplication
   * @throws NotFoundError   if user not found
   * @throws NotFoundError   if docker image not found
   * @throws DockerException if docker image not found or container name is taken
   */
  public void createDockerContainer(UserApplication userApplication) {
    String dockerImage = userApplication.getDockerImage();
    boolean isImgExistsLocally = dockerService.isImageAvailableLocally(dockerImage);
    boolean imgOnDockerHub = dockerService.isImgOnDockerHub(dockerImage);
    if (!isImgExistsLocally && !imgOnDockerHub) {
      throw new NotFoundError("Docker image not found", Map.of("dockerImage", dockerImage));
    }

    if (!isImgExistsLocally) {
      dockerService.pullImgAsync(userApplication);
      return;
    }
    dockerService.createDockerContainer(userApplication);
  }

  /**
   * Validate the application name
   *
   * @param applicationName application name
   * @throws ConflictError if application name is taken
   * @throws BadRequest    if application name is invalid
   */
  private void validateApplicationName(String applicationName) {
    String containerNameRegex = "^[a-zA-Z0-9][a-zA-Z0-9_.-]+$";
    boolean appNameExistsInDB = userApplicationRepository.existsByAppName(applicationName);
    boolean appNameTakenByContainer = dockerService.isContainerExists(applicationName).orElse(false);

    if (appNameExistsInDB || appNameTakenByContainer) {
      log.info("Application name is taken in: {}", appNameExistsInDB ? "DB" : "Docker");
      throw new ConflictError("Application name is taken", Map.of("appName", applicationName));
    }

    if (!applicationName.matches(containerNameRegex)) {
      throw new BadRequest("Invalid application name", Map.of("appName", applicationName));
    }
  }

  /**
   * Save or update the application in the database
   *
   * @param dto         UserApplicationCreateDTO
   * @param existingApp UserApplication existing application
   * @return UserApplication
   * @throws ConflictError if application name is taken
   * @throws BadRequest    if user has reached the maximum amount of applications
   *                       permitted
   * @throws GeneralError  if it can't generate a port for the application
   * @throws NotFoundError if user not found
   */
  private UserApplication saveOrUpdateApplication(
      UserApplicationCreateDTO dto, UserApplication existingApp) {
    User user = userService.findByUsernameOr404(dto.getUsername());
    int port = genrateHostPort(); // can throw GeneralError
    if (existingApp == null) {
      validateBeforeCreateApplication(dto, user);
    }
    UserApplication userApplication = buildUserApplication(dto, user, port, existingApp);

    return userApplicationRepository.save(userApplication);
  }

  /**
   * Validate the application before creating it
   *
   * @param dto  UserApplicationCreateDTO
   * @param user User
   * @throws BadRequest    if user reached to apps limit capacity or validation
   *                       error
   * @throws ConflictError if application name is taken
   * @throws NotFoundError if docker image not found
   */
  private void validateBeforeCreateApplication(UserApplicationCreateDTO dto, User user) {
    boolean isUserAllowedMoreThanFiveApps = featureFlagService.isFeatureFlagEnabled(
        FeatureFlags.ALLOW_MORE_THAN_FIVE_APPS, user.getId());
    if (!isUserAllowedMoreThanFiveApps) {
      validateUserApplicationLimit(user);
    }
    validateApplicationName(dto.getAppName().toLowerCase());
    validateDockerImg(dto.getDockerImage());
  }

  private void validateDockerImg(String dockerImage) {
    boolean imgOnDockerHub = dockerService.isImgOnDockerHub(dockerImage);
    if (!imgOnDockerHub) {
      throw new NotFoundError(
          "Docker image not found on docker hub", Map.of("dockerImage", dockerImage));
    }
  }

  private UserApplication buildUserApplication(
      UserApplicationCreateDTO dto, User user, int port, UserApplication existingApp) {
    UserApplicationBuilder userApplicationBuilder = UserApplicationBuilder.anUserApplication()
        .withDockerImage(dto.getDockerImage())
        .withAppName(dto.getAppName().toLowerCase())
        .withPort(port)
        .withRemainingTime(INITIAL_REMAINING_TIME)
        .withUsername(dto.getUsername())
        .withUser(user)
        .withContainerPort(dto.getContainerPort())
        .withStatus(ContainerCreationStatus.IN_PROGRESS);

    if (existingApp != null) {
      userApplicationBuilder.withId(existingApp.getId());
    }

    return userApplicationBuilder.build();
  }

  /**
   * Validate the user application limit capacity
   *
   * @param user User
   * @throws BadRequest if user reached to apps limit capacity
   */
  public void validateUserApplicationLimit(User user) {
    if (user.getApplicationCount() >= USER_APPS_CAPACITY) {
      throw new BadRequest("Reach max user apps amount of apps permitted for user");
    }
  }

  private void removeContainerBeforeUpdate(UserApplication existingApplication) {
    if (existingApplication.getStatus().equals(ContainerCreationStatus.CREATED)) {
      dockerService.removeContainer(existingApplication.getAppName());
    }
  }

  @Deprecated
  public NewApplicationResponse updateUserApplication(long appId, UpdateUserApplicationDTO dto) {
    if (dto.getAppId() != appId) {
      log.error("Id's are not matching in the request body and path");
      throw new BadRequest("Id's are not matching in the request body and path");
    }
    UserApplication existingApplication = userApplicationRepository
        .findById(appId)
        .orElseThrow(() -> new NotFoundError("Application not found"));
    removeContainerBeforeUpdate(existingApplication);

    return proccessUserApplication(dto, existingApplication);
  }

  /**
   * Create a new application
   *
   * @param dto UserApplicationCreateDTO
   * @return ApplicationCreateResponse
   * @throws ConflictError if application name is taken
   * @throws BadRequest    user reached to apps limit capacity or validation error
   * @throws GeneralError  if can't generate a port for the application
   * @throws NotFoundError if user not found or docker image not found
   */
  @Deprecated
  public NewApplicationResponse createNewApplication(UserApplicationCreateDTO dto) {
    log.info("Creating new userApplication for user: {}", dto.getUsername());
    String username = dto.getUsername();
    String appName = dto.getAppName();
    String dockerImage = dto.getDockerImage();

    return proccessUserApplication(dto, null);
  }

  private void updateApplicationStatusOnError(Exception ex, UserApplication userApplication) {
    if (userApplication != null) {
      userApplicationRepository.updateCreationErrorAndStatusById(
          ex.getMessage(), ContainerCreationStatus.FAILED, userApplication.getId());
    }
  }

  public void onDockerContainerCreated(String containerId, Long applicationId) {
    userApplicationRepository.updateContainerId(containerId, applicationId);
    UserApplication application = getById(applicationId);
    checkContainerHealth(application);

  }

  public void onDockerContainerCreated(
      CreateContainerResponse response, UserApplication userApplication) {
    log.info("Container created for application: {}", userApplication.getAppName());
    userApplication.setContainerId(response.getId());
    // userApplication.setStatus(ContainerCreationStatus.PENDING);
    userApplicationRepository.save(userApplication);

    checkContainerHealth(userApplication);
  }

  private void checkContainerHealth(UserApplication userApplication) {
    dockerService
        .validateContainerHealthAsync(userApplication.getAppName())
        .thenAccept(
            isValid -> {
              if (isValid) {
                log.info("Health check passed for application: {}", userApplication.getAppName());
                userApplication.setStatus(ContainerCreationStatus.CREATED);
                userApplication.setRunning(true);
                userApplicationRepository.save(userApplication);

              } else {
                log.error(
                    String.format(
                        "Health check failed for application: %s", userApplication.getAppName()));
                userApplication.setStatus(ContainerCreationStatus.UNHEALTHY);
                userApplication.setCreationError("Health check failed, plase check container logs");
                userApplication.setRunning(false);
                userApplicationRepository.save(userApplication);
              }
            });
  }

  /**
   * Get user application by id
   *
   * @param id application id
   * @return UserApplication
   * @throws NotFoundError if application not found
   */
  public UserApplication getById(long id) {
    return userApplicationRepository
        .findById(id)
        .orElseThrow(() -> new NotFoundError("Application not found"));
  }

  public UserApplication findByAppNameOr404(String appName) {
    return userApplicationRepository
        .findByAppName(appName)
        .orElseThrow(() -> new NotFoundError("Application not found"));
  }

  private UserApplication findByIdAndAppNameOr404(long appId, String appName) {
    return userApplicationRepository
        .findByIdAndAppName(appId, appName)
        .orElseThrow(() -> new NotFoundError("Application not found"));
  }

  /**
   * Verify that the application and container exist and return the application
   *
   * @param appId   application id
   * @param appName application (container) name
   * @return UserApplication
   * @throws NotFoundError if application or container not found
   */
  public UserApplication verifyAppAndContainerExistence(long appId, String appName) {
    dockerService
        .isContainerExists(appName)
        .orElseThrow(() -> new NotFoundError("Container not found"));
    return findByIdAndAppNameOr404(appId, appName);
  }

  public void onAppStarted(String appName) {
    UserApplication userApplication = findByAppNameOr404(appName);
    onAppStarted(userApplication);
  }

  public void onAppStarted(UserApplication userApplication) {
    userApplication.setRunning(true);
    userApplication.setLastUsed(Dates.nowUTC());
    userApplicationRepository.save(userApplication);
  }

  public void onAppStopped(String appName) {
    UserApplication userApplication = findByAppNameOr404(appName);
    userApplication.setRunning(false);
    userApplication.setLastUsed(Dates.nowUTC());
    userApplicationRepository.save(userApplication);
  }

  /**
   * Start the application
   *
   * @param request ApplicationActionRequest
   * @return ExecutionResponse
   * @throws NotFoundError if application not found
   * @throws BadRequest    if application can't be started
   */
  public ExecutionResponse startApp(ApplicationActionRequest request) {
    StartAppCmd startCmd = (StartAppCmd) AppCmdFactory.getCmd(START, dockerService, userApplicationRepository, request);
    startCmd.execute();
    onAppStarted(request.getAppName());

    return ExecutionResponse.toResponse(
        request.getAppId(), UserApplication.APP_STARTED_MESSAGE, START, AppStatus.STARTED);
  }

  private ExecutionResponse startApp(UserApplication userApplication) {
    ApplicationActionRequest applicationActionRequest = new ApplicationActionRequest();
    applicationActionRequest.setAppId(userApplication.getId());
    applicationActionRequest.setUsername(userApplication.getUsername());
    applicationActionRequest.setAppName(userApplication.getAppName());

    return startApp(applicationActionRequest);
  }

  /**
   * Stop the application
   *
   * @param request ApplicationActionRequest
   * @return ExecutionResponse
   * @throws NotFoundError if application not found
   */
  public ExecutionResponse stopApp(ApplicationActionRequest request) {
    BaseAppCmd stopCmd = AppCmdFactory.getCmd(STOP, dockerService, userApplicationRepository, request);
    stopCmd.execute();
    onAppStopped(request.getAppName());

    return ExecutionResponse.toResponse(
        request.getAppId(), UserApplication.APP_STOPPED_MESSAFE, STOP, AppStatus.STOPPED);
  }

  /**
   * Generate a host port for the application
   *
   * @return the generated port
   * @throws GeneralError if can't generate a port for the application
   */
  private int genrateHostPort() {
    int i = 0;
    int port = Generators.generatePort();
    while (i < 10 && userApplicationRepository.isHostPortTaken(port)) {
      port = Generators.generatePort();
      i++;
    }
    if (i >= 10) {
      throw new GeneralError("Can't generate a port for the application");
    }

    return port;
  }

  private void deleteAppFromDb(long appId) {
    userApplicationRepository.deleteById(appId);
  }

  /**
   * Delete user application
   *
   * @param deleteRequest ApplicationActionRequest
   * @return ExecutionResponse
   * @throws NotFoundError if application not found
   */
  public ExecutionResponse deleteUserApplication(ApplicationActionRequest deleteRequest) {
    UserApplication userApplication = findByIdAndAppNameOr404(deleteRequest.getAppId(), deleteRequest.getAppName());
    boolean appWithFailedStatus = Objects.equals(userApplication.getStatus(), ContainerCreationStatus.FAILED);

    if (appWithFailedStatus) {
      log.info("Deleting application with failed success only from db");
      deleteAppFromDb(userApplication.getId());
    } else {
      log.info("Deleting application from db and docker");
      DeleteAppCmd deleteApplicationCommand = createDeleteApplicationCommand(deleteRequest);
      deleteApplicationCommand.execute();
    }

    return ExecutionResponse.toResponse(
        deleteRequest.getAppId(), UserApplication.APP_DELETED_MESSAGE, DELETE, AppStatus.DELETED);
  }

  private DeleteAppCmd createDeleteApplicationCommand(ApplicationActionRequest deleteRequest) {
    return (DeleteAppCmd) AppCmdFactory.getCmd(DELETE, dockerService, userApplicationRepository, deleteRequest);
  }

  /**
   * Get all user applications
   *
   * @param userName user name
   * @return {@link List<UserApplicationOut>}
   * @throws NotFoundError if user not found
   */
  public List<UserApplicationOut> getAllUserApplication(String userName) {
    User user = userService.findByUsernameOr404(userName);
    Set<UserApplication> userApplications = user.getUserApplications();
    List<UserApplicationOut> userApplicationOuts = userApplications.stream()
        .map(userApplicationMapper::toUserApplicationOut)
        .sorted(Comparator.comparing(UserApplicationOut::isRunning).reversed())
        .collect(Collectors.toList());

    return userApplicationOuts;
  }

  /**
   * Get application logs
   *
   * @param appId application id
   * @return application logs
   * @throws NotFoundError if application not found
   */
  public String getApplicationLogs(long appId) {
    UserApplication userApplication = userApplicationRepository
        .findById(appId)
        .orElseThrow(() -> new NotFoundError("Application not found"));
    if (userApplication.getContainerId() == null) {
      throw new NotFoundError("Container not found");
    }

    return dockerService.getContainerLogs(userApplication.getAppName());
  }

  /**
   * Get application by application name
   *
   * @param appName application name
   * @return application
   * @throws NotFoundError if application not found
   */
  public UserApplication findByAppName(String appName) {
    // TODO: change search to include user
    return userApplicationRepository
        .findByAppName(appName)
        .orElseThrow(() -> new NotFoundError("Application not found", Map.of("appName", appName)));
  }

  public byte[] getLogsForFile(Long appId) throws InterruptedException {
    UserApplication userApplication = getById(appId);
    if (userApplication.getContainerId() == null) {
      throw new NotFoundError("Container not found");
    }
    return dockerService.getContainerLogsForFile(userApplication.getAppName());
  }
}
