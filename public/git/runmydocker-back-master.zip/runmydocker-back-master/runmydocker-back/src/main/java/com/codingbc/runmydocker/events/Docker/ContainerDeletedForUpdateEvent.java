package com.codingbc.runmydocker.events.Docker;

import com.codingbc.runmydocker.models.UserApplication;
import lombok.Getter;
import org.springframework.context.ApplicationEvent;

@Getter
public class ContainerDeletedForUpdateEvent extends ApplicationEvent {

  private final UserApplication application;
  ;

  public ContainerDeletedForUpdateEvent(Object source, UserApplication application) {
    super(source);
    this.application = application;
  }

}
