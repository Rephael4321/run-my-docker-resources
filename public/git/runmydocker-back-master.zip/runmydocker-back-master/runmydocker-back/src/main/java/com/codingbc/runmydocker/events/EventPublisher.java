/*
 * Copyright (c) 2024.
 */

package com.codingbc.runmydocker.events;

import com.codingbc.runmydocker.events.Auth.SendCodeEvent;
import com.codingbc.runmydocker.events.Docker.ContainerCreatedEvent;
import com.codingbc.runmydocker.events.Docker.CreateContainerEvent;
import com.codingbc.runmydocker.events.Docker.ContainerDeletedForUpdateEvent;
import com.codingbc.runmydocker.events.User.UserRegisteredEvent;
import com.codingbc.runmydocker.events.UserApplication.ImagePullCompleteEvent;
import com.codingbc.runmydocker.models.ActivationCode;
import com.codingbc.runmydocker.models.User;
import com.codingbc.runmydocker.models.UserApplication;
import com.github.dockerjava.api.command.CreateContainerResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.ApplicationEventPublisherAware;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class EventPublisher implements ApplicationEventPublisherAware {

  private static ApplicationEventPublisher eventPublisher;

  @Override
  public void setApplicationEventPublisher(ApplicationEventPublisher applicationEventPublisher) {
    eventPublisher = applicationEventPublisher;
  }

  public static void publishImagePullCompleteEvent(UserApplication userApplication) {
    eventPublisher.publishEvent(new ImagePullCompleteEvent(EventPublisher.class, userApplication));
  }

  public static void publishContainerCreatedEvent(
      CreateContainerResponse createContainerResponse, UserApplication userApplication) {
    eventPublisher.publishEvent(
        new ContainerCreatedEvent(EventPublisher.class, createContainerResponse, userApplication));
  }

  public static void publishCreateContainerEvent(UserApplication userApplication) {
    CreateContainerEvent createContainerEvent = new CreateContainerEvent(EventPublisher.class, userApplication);
    eventPublisher.publishEvent(createContainerEvent);
  }

  public static void publishContainerDeletedForUpdateEvent(UserApplication userApplication) {
    ContainerDeletedForUpdateEvent containerDeletedForUpdateEvent = new ContainerDeletedForUpdateEvent(
        EventPublisher.class, userApplication);

    eventPublisher.publishEvent(containerDeletedForUpdateEvent);
  }

  public static void publishUserRegisteredEvent(User user) {
    UserRegisteredEvent userRegisteredEvent = new UserRegisteredEvent(EventPublisher.class, user);
    eventPublisher.publishEvent(userRegisteredEvent);
  }

  public static void publishSendActivationCodeEvent(ActivationCode code) {
    SendCodeEvent sendCodeEvent = new SendCodeEvent(EventPublisher.class, code);
    eventPublisher.publishEvent(sendCodeEvent);
  }
}
