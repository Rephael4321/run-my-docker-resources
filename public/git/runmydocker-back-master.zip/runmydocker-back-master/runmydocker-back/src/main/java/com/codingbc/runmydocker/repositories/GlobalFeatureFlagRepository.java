package com.codingbc.runmydocker.repositories;

import com.codingbc.runmydocker.models.GlobalFeatureFlag;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;


public interface GlobalFeatureFlagRepository extends JpaRepository<GlobalFeatureFlag, Long> {
    Optional<GlobalFeatureFlag> findByFlagName(String flagName);
}