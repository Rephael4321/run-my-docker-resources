package com.codingbc.runmydocker.docs.swagger;

import com.codingbc.runmydocker.dto.UserApplication.ExecutionResponse;
import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = true)
@Data
public class ApplicationActionResponse extends BaseResponseModal {
  private ExecutionResponse data;
}
