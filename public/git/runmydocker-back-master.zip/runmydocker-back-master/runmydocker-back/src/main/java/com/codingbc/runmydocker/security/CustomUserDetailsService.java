package com.codingbc.runmydocker.security;

import com.codingbc.runmydocker.exceptions.NotAnActivateUserError;
import com.codingbc.runmydocker.models.User;
import com.codingbc.runmydocker.repositories.UserRepository;
import java.util.ArrayList;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class CustomUserDetailsService implements UserDetailsService {

  private final UserRepository userRepository;

  public CustomUserDetailsService(UserRepository userRepository) {
    this.userRepository = userRepository;
  }

  /**
   * Map user to UserDetails - this is the method that will be called by Spring Security to get the
   * user details
   *
   * @param userFromDB user from the database
   * @return UserDetails - spring security user details
   */
  private org.springframework.security.core.userdetails.User mapUserToUserDeatils(User userFromDB) {
    ArrayList<SimpleGrantedAuthority> authorities = new ArrayList<>();
    return new org.springframework.security.core.userdetails.User(
        userFromDB.getUsername(), userFromDB.getPassword(), authorities);
  }

  @Override
  public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
    User userFromDb =
        userRepository
            .findByUsername(username)
            .orElseThrow(() -> new UsernameNotFoundException("user not found"));
    if (!userFromDb.isActivated()) {
      throw new NotAnActivateUserError("User is not activate");
    }

    return mapUserToUserDeatils(userFromDb);
  }
}
