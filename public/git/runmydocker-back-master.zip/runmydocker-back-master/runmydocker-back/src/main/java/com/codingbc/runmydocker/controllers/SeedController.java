package com.codingbc.runmydocker.controllers;

import com.codingbc.runmydocker.dto.ApiResponse;
import com.codingbc.runmydocker.models.User;
import com.codingbc.runmydocker.repositories.UserApplicationRepository;
import com.codingbc.runmydocker.repositories.UserRepository;
import com.codingbc.runmydocker.services.DockerService;
import com.codingbc.runmydocker.services.seed.SeedService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/seed")
@Slf4j
public class SeedController {

  @Autowired private UserApplicationRepository userApplicationRepository;

  @Autowired private DockerService dockerService;
  @Autowired private UserRepository userRepository;
  @Autowired private SeedService seedService;

  @DeleteMapping("/truncate/apps")
  public ResponseEntity<?> truncateApps() {
    userApplicationRepository.deleteAll();
    log.info("deleting apps from db");

    return ResponseEntity.noContent().build();
  }

  @GetMapping("/searchImage")
  public ResponseEntity<?> searchImage(@RequestParam("imageName") String imageName) {
    log.info("searching for image: {}", imageName);
    return ResponseEntity.ok(dockerService.isImgOnDockerHub(imageName));
  }

  @PostMapping("tests/seed")
  public ResponseEntity<?> seed() {
    log.info("seeding data");
    seedService.seedUserForTests();
    return ResponseEntity.ok("user seeded");
  }

  @PostMapping("tests/users")
  public ResponseEntity<?> seedTruncate() {
    seedService.seedUserForTests();
    return ResponseEntity.ok(ApiResponse.success("users seeded", "", HttpStatus.CREATED, null));
  }

  @DeleteMapping("tests/users")
  public ResponseEntity<?> truncate() {
    seedService.truncateUsers();
    return ResponseEntity.ok(ApiResponse.success("users truncated", "", HttpStatus.NO_CONTENT, null));
  }
}
