package com.codingbc.runmydocker.exceptions;

import java.lang.reflect.Method;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.springframework.aop.interceptor.AsyncUncaughtExceptionHandler;

@Slf4j
public class CustomAsyncExceptionHandler implements AsyncUncaughtExceptionHandler {

  @Override
  public void handleUncaughtException(Throwable throwable, Method method, Object... objects) {
    Map<String, Object> error =
        Map.of("method", method.getName(), "message", throwable.getMessage());

    log.error(error.toString(), throwable);
  }
}
