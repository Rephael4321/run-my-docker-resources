/*
 * Copyright (c) 2024.
 */

package com.codingbc.runmydocker.builders;

import com.codingbc.runmydocker.dto.UserApplication.UserApplicationOut;
import com.codingbc.runmydocker.enums.ContainerCreationStatus;
import java.util.Date;

public final class UserApplicationOutBuilder {

  private UserApplicationOut userApplicationOut;

  public UserApplicationOutBuilder() {
    userApplicationOut = new UserApplicationOut();
  }

  public UserApplicationOutBuilder(UserApplicationOut other) {
    this.userApplicationOut = other;
  }

  public static UserApplicationOutBuilder anUserApplicationOut() {
    return new UserApplicationOutBuilder();
  }

  public UserApplicationOutBuilder withId(Long Id) {
    userApplicationOut.setId(Id);
    return this;
  }

  public UserApplicationOutBuilder withDockerImage(String dockerImage) {
    userApplicationOut.setDockerImage(dockerImage);
    return this;
  }

  public UserApplicationOutBuilder withAppName(String appName) {
    userApplicationOut.setAppName(appName);
    return this;
  }

  public UserApplicationOutBuilder withMappingPort(String mappingPort) {
    userApplicationOut.setMappingPort(mappingPort);
    return this;
  }

  public UserApplicationOutBuilder withUsername(String username) {
    userApplicationOut.setUsername(username);
    return this;
  }

  public UserApplicationOutBuilder withCreatedAt(Date createdAt) {
    userApplicationOut.setCreatedAt(createdAt);
    return this;
  }

  public UserApplicationOutBuilder withUpdatedAt(Date updatedAt) {
    userApplicationOut.setUpdatedAt(updatedAt);
    return this;
  }

  public UserApplicationOutBuilder withRemainingTime(int remainingTime) {
    userApplicationOut.setRemainingTime(remainingTime);
    return this;
  }

  public UserApplicationOutBuilder withIsRunning(boolean isRunning) {
    userApplicationOut.setRunning(isRunning);
    return this;
  }

  public UserApplicationOutBuilder withStatusInfo(ContainerCreationStatus status, String error) {
    UserApplicationOut.StatusInfo statusInfo = new UserApplicationOut.StatusInfo();
    statusInfo.setStatus(status);
    statusInfo.setError(error);
    userApplicationOut.setStatusInfo(statusInfo);
    return this;
  }


  public UserApplicationOut build() {
    return userApplicationOut;
  }
}
