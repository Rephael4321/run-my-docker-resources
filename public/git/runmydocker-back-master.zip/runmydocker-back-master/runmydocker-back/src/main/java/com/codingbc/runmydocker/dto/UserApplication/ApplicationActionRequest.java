/*
 * Copyright (c) 2024.
 */

package com.codingbc.runmydocker.dto.UserApplication;

import com.fasterxml.jackson.annotation.JsonIgnore;
import javax.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ApplicationActionRequest {

  @JsonIgnore private String username;
  @NotBlank private Long appId;
  @NotBlank private String appName;
}
