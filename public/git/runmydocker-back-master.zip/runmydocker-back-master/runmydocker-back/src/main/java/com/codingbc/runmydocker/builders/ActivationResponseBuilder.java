package com.codingbc.runmydocker.builders;

import com.codingbc.runmydocker.dto.auth.ActivationResponse;

public final class ActivationResponseBuilder {

  private ActivationResponse activationResponse;

  public ActivationResponseBuilder() {
    activationResponse = new ActivationResponse();
  }

  public ActivationResponseBuilder(ActivationResponse other) {
    this.activationResponse = other;
  }

  public static ActivationResponseBuilder anActivationResponse() {
    return new ActivationResponseBuilder();
  }

  public ActivationResponseBuilder withMessage(String message) {
    activationResponse.setMessage(message);
    return this;
  }

  public ActivationResponseBuilder withUsername(String username) {
    activationResponse.setUsername(username);
    return this;
  }

  public ActivationResponseBuilder withJwtToken(String jwtToken) {
    activationResponse.setJwtToken(jwtToken);
    return this;
  }

  public ActivationResponse build() {
    return activationResponse;
  }
}
