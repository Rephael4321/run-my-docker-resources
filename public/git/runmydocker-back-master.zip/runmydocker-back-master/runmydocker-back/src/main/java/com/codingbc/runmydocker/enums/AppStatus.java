/*
 * Copyright (c) 2024.
 */

package com.codingbc.runmydocker.enums;

public enum AppStatus {
  STARTED,
  STOPPED,
  DELETED
}
