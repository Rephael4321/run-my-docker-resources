/*
 * Copyright (c) 2024.
 */

package com.codingbc.runmydocker.commands.UserApplication;

import com.codingbc.runmydocker.dto.UserApplication.ApplicationActionRequest;
import com.codingbc.runmydocker.models.UserApplication;
import com.codingbc.runmydocker.repositories.UserApplicationRepository;
import com.codingbc.runmydocker.services.DockerService;
import com.codingbc.runmydocker.util.AppActionsValidationUtils;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class DeleteAppCmd extends BaseAppCmd {

  public DeleteAppCmd(DockerService dockerService,
      UserApplicationRepository userApplicationRepository, ApplicationActionRequest actionRequest) {
    super(dockerService, userApplicationRepository, actionRequest);
  }

  @Override
  public void execute() {
    deleteApp();
  }

  @Override
  protected void validateState(UserApplication userApplication) {
    AppActionsValidationUtils.validateAppCanBeDeleted(userApplication, dockerService);
  }

  private void deleteApp() {
    UserApplication userApplication = findByAppIdAndAppName();
    validateState(userApplication);
    dockerService.removeContainer(userApplication.getAppName());
    userApplicationRepository.deleteById(userApplication.getId());
  }


}
