package com.codingbc.runmydocker.repositories;

import com.codingbc.runmydocker.models.User;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {

  @Query("select a from User a where lower(a.username) = lower(?1)")
  Optional<User> findByUsername(String username);

  @Query("select (count(a) > 0) from User a where upper(a.username) = upper(?1)")
  boolean existsByUsernameIgnoreCase(String username);

  @Query("select u from User u where u.username = ?1 and u.isActivated = true")
  Optional<User> findByUsernameAndIsActivated(String username);
}
