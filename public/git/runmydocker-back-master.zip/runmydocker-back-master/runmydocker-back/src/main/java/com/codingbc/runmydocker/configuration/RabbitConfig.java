package com.codingbc.runmydocker.configuration;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.*;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RabbitConfig {
  public static final String AUTH_EXCHANGE = "auth-exchange";
  public static final String USER_APP_EXCHANGE = "user-app-exchange";
  public static final String AUTH_QUEUE = "auth-queue";
  public static final String USER_APP_QUEUE = "user-app-queue";
  public static final String DEAD_LETTER_EXCHANGE = "dead-letter-exchange";
  public static final String DEAD_LETTER_QUEUE = "dead-letter-queue";
  public static final String AUTH_ROUTING_KEY = "auth";
  public static final String USER_APP_ROUTING_KEY = "user-app";

  private final Logger logger = LoggerFactory.getLogger(RabbitConfig.class);

  @Bean
  public RabbitTemplate rabbitTemplate(ConnectionFactory connectionFactory) {
    RabbitTemplate rabbitTemplate = new RabbitTemplate(connectionFactory);

    // Enable Publisher Confirms
    rabbitTemplate.setConfirmCallback(
        (correlationData, ack, cause) -> {
          if (ack) {
            logger.info("[RabbitMQ] Message delivery confirmed, correlationData: {}", correlationData);
          } else {
            logger.error("[RabbitMQ] Message delivery failed, correlationData: {}, {}", correlationData, cause);
          }
        });

    return rabbitTemplate;
  }

  @Bean
  public Exchange authExchange() {
    return ExchangeBuilder.directExchange(AUTH_EXCHANGE).durable(true).build();
  }

  @Bean
  public Exchange userAppExchange() {
    return ExchangeBuilder.directExchange(USER_APP_EXCHANGE).durable(true).build();
  }

  @Bean
  public Queue authQueue() {
    return QueueBuilder.durable(AUTH_QUEUE).deadLetterExchange(DEAD_LETTER_EXCHANGE).build();
  }

  @Bean
  public Queue userAppQueue() {
    return QueueBuilder.durable(USER_APP_QUEUE).deadLetterExchange(DEAD_LETTER_EXCHANGE).build();
  }

  @Bean
  public Queue deadLetterQueue() {
    return QueueBuilder.durable(DEAD_LETTER_QUEUE).build();
  }

  @Bean
  public Binding bindingAuthQueue() {
    return BindingBuilder.bind(authQueue()).to(authExchange()).with(AUTH_ROUTING_KEY).noargs();
  }

  @Bean
  public Binding bindingUserAppQueue() {
    return BindingBuilder.bind(userAppQueue()).to(userAppExchange()).with(USER_APP_ROUTING_KEY).noargs();
  }


  @Bean
  public Exchange deadLetterExchange() {
    return ExchangeBuilder.topicExchange(DEAD_LETTER_EXCHANGE).durable(true).build();
  }

  @Bean
  public Binding bindingDeadLetterQueue() {
    return BindingBuilder.bind(deadLetterQueue())
            .to(deadLetterExchange())
            .with("dead-letter")
            .noargs();
  }
}
