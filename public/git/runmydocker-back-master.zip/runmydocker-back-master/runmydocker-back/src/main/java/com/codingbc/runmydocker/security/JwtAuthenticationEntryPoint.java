package com.codingbc.runmydocker.security;

import com.codingbc.runmydocker.dto.ApiResponse;
import com.codingbc.runmydocker.models.RequestLog;
import com.codingbc.runmydocker.services.RequestsLogging.RequestLogsService;
import com.codingbc.runmydocker.util.JsonUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.time.LocalDateTime;
import java.util.Map;
import java.util.UUID;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class JwtAuthenticationEntryPoint implements AuthenticationEntryPoint {
  @Autowired private JsonUtil jsonUtil;
  @Autowired private ObjectMapper objectMapper;
  @Autowired private RequestLogsService requestLogsService;

  @Override
  public void commence(
      HttpServletRequest httpServletRequest,
      HttpServletResponse httpServletResponse,
      AuthenticationException e)
      throws IOException {
    String message = e.getMessage();
    log.error("Authentication failed: {} for: {} ", message, httpServletRequest.getServletPath());
    StringWriter stringWriter = new StringWriter();
    PrintWriter printWriter = new PrintWriter(stringWriter);
    e.printStackTrace(printWriter);
    var response = ApiResponse.error(message, HttpStatus.UNAUTHORIZED, Map.of());
    ResponseEntity<ApiResponse<Object>> apiResponseResponseEntity =
        new ResponseEntity<>(response, HttpStatus.UNAUTHORIZED);

    httpServletResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
    httpServletResponse.setContentType("applicaton/json");
    objectMapper.registerModule(new JavaTimeModule());
    log.debug(response.toString());
    objectMapper.writeValue(httpServletResponse.getOutputStream(), response);

    RequestLog requestLog = new RequestLog();
    requestLog.setRequestUrl(httpServletRequest.getRequestURI());
    requestLog.setRequestId(UUID.randomUUID());
    requestLog.setMethod(httpServletRequest.getMethod());
    requestLog.setSuccess(false);
    requestLog.setRequestBody(Map.of());
    requestLog.setResponseBody(jsonUtil.parseToMap(response));
    requestLog.setClientIp(httpServletRequest.getRemoteAddr());
    requestLog.setTimestamp(LocalDateTime.now());

    requestLogsService.save(requestLog);
  }
}
