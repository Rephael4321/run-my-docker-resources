package com.codingbc.runmydocker.repositories;

import com.codingbc.runmydocker.models.AppMessage;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import java.util.UUID;

public interface AppMessageRepository extends JpaRepository<AppMessage, UUID> {
  @Transactional
  @Modifying
  @Query("update AppMessage a set a.isRead = ?1 where a.messageId = ?2")
  void updateIsReadByMessageId(boolean isRead, UUID messageId);
}
