package com.codingbc.runmydocker.mappers.User;

import com.codingbc.runmydocker.dto.AppUser.OAuth2UserCreateDTO;
import com.codingbc.runmydocker.dto.AppUser.RegularUserCreateDTO;
import com.codingbc.runmydocker.dto.AppUser.UserOutDTO;
import com.codingbc.runmydocker.models.User;

public interface IUserMapper {
  User regularUserCreateDtoToUser(RegularUserCreateDTO dto);
  User OAuth2UserCreateDTOToUser(OAuth2UserCreateDTO dto);
  UserOutDTO fromUserToUserOutDTO(User user);
}
