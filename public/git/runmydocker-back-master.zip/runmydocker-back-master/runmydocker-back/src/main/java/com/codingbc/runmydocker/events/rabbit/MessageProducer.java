package com.codingbc.runmydocker.events.rabbit;

import com.codingbc.runmydocker.configuration.RabbitConfig;
import com.codingbc.runmydocker.events.rabbit.messages.MessageAction;
import com.codingbc.runmydocker.models.AppMessage;
import com.codingbc.runmydocker.models.User;
import com.codingbc.runmydocker.models.UserApplication;
import com.codingbc.runmydocker.repositories.AppMessageRepository;
import com.codingbc.runmydocker.util.JsonUtil;
import com.github.dockerjava.api.command.CreateContainerResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.UUID;

@Component
public class MessageProducer {
  private final Logger logger = LoggerFactory.getLogger(MessageProducer.class);
  @Autowired private RabbitTemplate rabbitTemplate;
  @Autowired private JsonUtil jsonUtil;
  @Autowired private AppMessageRepository appMessageRepository;

  public void sendUserRegisteredMessage(User user) {
    AppMessage appMessage =
        AppMessage.builder()
            .payload(jsonUtil.parseToJsonString(user))
            .username(user.getUsername())
            .isRead(false)
            .messageId(UUID.randomUUID())
            .type("auth")
            .action(MessageAction.USER_REGISTERED)
            .build();
    appMessageRepository.save(appMessage);
    publishMessage(
        RabbitConfig.AUTH_EXCHANGE,
        RabbitConfig.AUTH_ROUTING_KEY,
        jsonUtil.parseToJsonString(appMessage));
  }

  public void sendCreateContainerMessage(UserApplication userApplication) {
    AppMessage appMessage =
        AppMessage.builder()
            .payload(jsonUtil.parseToJsonString(userApplication))
            .username(userApplication.getUsername())
            .isRead(false)
            .messageId(UUID.randomUUID())
            .type("user-application")
            .action(MessageAction.CREATE_CONTAINER)
            .build();
    appMessageRepository.save(appMessage);
    publishMessage(
        RabbitConfig.USER_APP_EXCHANGE,
        RabbitConfig.USER_APP_ROUTING_KEY,
        jsonUtil.parseToJsonString(appMessage));
  }

  public void sendContainerCreatedMessage(
      UserApplication application, CreateContainerResponse createContainerResponse) {
    String createdContainerId = createContainerResponse.getId();
    application.setContainerId(createdContainerId);
    AppMessage appMessage =
        AppMessage.builder()
            .payload(
                jsonUtil.parseToJsonString(
                    Map.of("containerId", createdContainerId, "application", jsonUtil.parseToJsonString(application))))
            .username(application.getUsername())
            .isRead(false)
            .messageId(UUID.randomUUID())
            .type("user-application")
            .action(MessageAction.CONTAINER_CREATED)
            .build();
    appMessageRepository.save(appMessage);
    publishMessage(
        RabbitConfig.USER_APP_EXCHANGE,
        RabbitConfig.USER_APP_ROUTING_KEY,
        jsonUtil.parseToJsonString(appMessage));
  }

  public void publishMessage(String exchange, String routingKey, String messageAsJson) {
    try {
      rabbitTemplate.convertAndSend(exchange, routingKey, messageAsJson);
      logger.info("[Message-Producer] Sent message: {}", messageAsJson);
    } catch (Exception e) {
      logger.error("[Message-Producer] Error sending message: {}", e.getMessage());
    }
  }
}
