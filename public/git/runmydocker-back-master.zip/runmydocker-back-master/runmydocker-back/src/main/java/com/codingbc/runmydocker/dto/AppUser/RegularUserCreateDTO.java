package com.codingbc.runmydocker.dto.AppUser;

import com.codingbc.runmydocker.validators.constrains.PhoneValidator;
import javax.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import lombok.EqualsAndHashCode;


@EqualsAndHashCode(callSuper = true)
@Data
public class RegularUserCreateDTO extends UserCreateDTO {

  @NotBlank(message = "first name is require")
  private String firstName;

  @NotBlank(message = "last name is require")
  private String lastName;
  

  @NotBlank(message = "phone is require")
  @PhoneValidator(message = "Phone not valid or not match to permitted countries")
  private String phone;
}
