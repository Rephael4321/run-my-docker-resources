package com.codingbc.runmydocker.controllers;

import com.codingbc.runmydocker.dto.ApiResponse;
import com.codingbc.runmydocker.enums.FeatureFlags;
import com.codingbc.runmydocker.models.GlobalFeatureFlag;
import com.codingbc.runmydocker.models.UserFeatureFlag;
import com.codingbc.runmydocker.services.FeatureFlagService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/feature-flags")
public class FeatureFlagsController {

  private final FeatureFlagService featureFlagService;

  public FeatureFlagsController(FeatureFlagService featureFlagService) {
    this.featureFlagService = featureFlagService;
  }

  @GetMapping("/isEnable/{userId}")
  public ResponseEntity<ApiResponse<?>> isFeatureFlagEnableForUser(
      @PathVariable Long userId, @RequestParam FeatureFlags featureFlag) {
    boolean featureFlagEnabled = featureFlagService.isFeatureFlagEnabled(featureFlag, userId);
    ApiResponse<Boolean> apiResponse =
        ApiResponse.success(
            featureFlagEnabled,
            "",
            HttpStatus.OK,
            Map.of("userId", userId, "flagName", featureFlag, "isEnabled", featureFlagEnabled));

    return ResponseEntity.ok(apiResponse);
  }

  @GetMapping("/isEnable/global")
    public ResponseEntity<ApiResponse<?>> isFeatureFlagEnableForGlobal(
        @RequestParam FeatureFlags featureFlag) {
        boolean featureFlagEnabled = featureFlagService.isFeatureFlagEnabled(featureFlag, null);
        ApiResponse<Boolean> apiResponse =
            ApiResponse.success(
                featureFlagEnabled,
                "",
                HttpStatus.OK,
                Map.of("flagName", featureFlag, "isEnabled", featureFlagEnabled));

        return ResponseEntity.ok(apiResponse);
    }

  @PostMapping("/global")
  public ResponseEntity<ApiResponse<GlobalFeatureFlag>> setGlobalFeatureFlag(
      @RequestParam FeatureFlags flagName, @RequestParam boolean isEnabled) {
    GlobalFeatureFlag featureFlag = featureFlagService.setGlobalFeatureFlag(flagName, isEnabled);
    ApiResponse<GlobalFeatureFlag> apiResponse =
        ApiResponse.success(
            featureFlag,
            "Created",
            HttpStatus.CREATED,
            Map.of("flagName", flagName, "isEnabled", isEnabled));

    return ResponseEntity.ok(apiResponse);
  }

  @PostMapping("/user")
  public ResponseEntity<ApiResponse<UserFeatureFlag>> setUserFeatureFlag(
      @RequestParam Long userId,
      @RequestParam FeatureFlags flagName,
      @RequestParam boolean isEnabled) {
    UserFeatureFlag userFeatureFlag =
        featureFlagService.setUserFeatureFlag(userId, flagName, isEnabled);
    ApiResponse<UserFeatureFlag> apiResponse =
        ApiResponse.success(
            userFeatureFlag,
            "Created",
            HttpStatus.CREATED,
            Map.of("userId", userId, "flagName", flagName, "isEnabled", isEnabled));

    return ResponseEntity.ok(apiResponse);
  }
}
