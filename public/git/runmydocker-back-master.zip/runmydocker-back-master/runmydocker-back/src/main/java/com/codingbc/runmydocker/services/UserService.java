package com.codingbc.runmydocker.services;

import com.codingbc.runmydocker.dto.AppUser.*;
import com.codingbc.runmydocker.dto.auth.ChangePasswordRequest;
import com.codingbc.runmydocker.dto.auth.CompleteRegistrationRequest;
import com.codingbc.runmydocker.exceptions.BadRequest;
import com.codingbc.runmydocker.exceptions.ConflictError;
import com.codingbc.runmydocker.exceptions.GeneralError;
import com.codingbc.runmydocker.exceptions.NotFoundError;
import com.codingbc.runmydocker.mappers.User.IUserMapper;
import com.codingbc.runmydocker.models.ActivationCode;
import com.codingbc.runmydocker.models.User;
import com.codingbc.runmydocker.repositories.UserRepository;
import java.util.Map;
import java.util.Optional;

import lombok.extern.slf4j.Slf4j;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class UserService {

  private final PasswordEncoder passwordEncoder;
  private final UserRepository userRepository;
  private final IUserMapper userMapper;

  private final ActivationCodeService activationCodeService;

  public UserService(
      PasswordEncoder passwordEncoder,
      UserRepository userRepository,
      IUserMapper userMapper,
      ActivationCodeService activationCodeService) {
    this.passwordEncoder = passwordEncoder;
    this.userRepository = userRepository;
    this.userMapper = userMapper;
    this.activationCodeService = activationCodeService;
  }

  /**
   * Find user by username or throw 404
   *
   * @param username username
   * @return User
   * @throws NotFoundError if user not found
   */
  public User findByUsernameOr404(String username) {
    return userRepository
        .findByUsername(username)
        .orElseThrow(() -> new NotFoundError("User not found", Map.of("username", username)));
  }

  public UserOutDTO getUserByUsername(String username) {
    User user = findByUsernameOr404(username);
    return userMapper.fromUserToUserOutDTO(user);
  }

  public User findByIdOr404(Long userId) {
    return userRepository.findById(userId).orElseThrow(() -> new NotFoundError("User not found"));
  }

  /**
   * Create user
   *
   * @param userCreateDTO {@link UserCreateDTO} - RegularUserCreateDTO or OAuth2UserCreateDTO
   * @return User entity
   * @throws ConflictError if username exists
   */
  public User create(UserCreateDTO userCreateDTO) {
    checkUsernameExists(userCreateDTO.getUsername());
    User savedUser = createUser(userCreateDTO);
    associateUserWithActivationCode(savedUser);

    return userRepository.saveAndFlush(savedUser);
  }

  /**
   * Check if username exists
   *
   * @param username username
   * @throws ConflictError if username exists
   */
  private void checkUsernameExists(String username) {
    if (userRepository.existsByUsernameIgnoreCase(username)) {
      throw new ConflictError("Username already exists");
    }
  }

  /**
   * Create user from DTO
   *
   * @param dto DTO - RegularUserCreateDTO or OAuth2UserCreateDTO
   * @return User entity
   * @throws GeneralError if DTO type is invalid
   */
  private User createUser(UserCreateDTO dto) {
    User user;
    switch (dto.getClass().getSimpleName()) {
      case "RegularUserCreateDTO":
        user = userMapper.regularUserCreateDtoToUser((RegularUserCreateDTO) dto);
        user.setRegistrationCompleted(true);
        break;
      case "OAuth2UserCreateDTO":
        user = userMapper.OAuth2UserCreateDTOToUser((OAuth2UserCreateDTO) dto);
        break;
      default:
        throw new GeneralError("Invalid user type: " + dto.getClass().getSimpleName());
    }

    user.setPassword(passwordEncoder.encode(user.getPassword()));
    return userRepository.save(user);
  }

  /**
   * Associate user with activation code
   *
   * @param user User
   */
  public void associateUserWithActivationCode(User user) {
    ActivationCode activationCode = activationCodeService.generateActivationCode(user);
    user.addActivationCode(activationCode);
  }

  /**
   * Complete user registration
   *
   * @param userId User ID
   * @param request {@link CompleteRegistrationRequest}
   * @return User entity {@link User}
   */
  public User completeRegistration(Long userId, CompleteRegistrationRequest request) {
    User user = findByIdOr404(userId);

    user.setRegistrationCompleted(true);
    user.setLastName(request.getLastName());
    user.setFirstName(request.getFirstName());
    user.setPhone(request.getPhone());

    return userRepository.saveAndFlush(user);
  }

  /**
   * Change password
   *
   * @param changePasswordRequest {@link ChangePasswordRequest}
   * @return User entity
   * @throws NotFoundError User not found
   * @throws BadRequest User registered without password
   */
  public User changePassword(UserChangePasswordRequest changePasswordRequest) {
    String username = changePasswordRequest.getUsername();
    User user = findByUsernameOr404(username);
    if (user.getProviderId() != null) {
      throw new BadRequest("User registered without password", Map.of("username", username));
    }

    user.setPassword(passwordEncoder.encode(changePasswordRequest.getNewPassword()));
    return userRepository.saveAndFlush(user);
  }
}
