package com.codingbc.runmydocker.filters.logging;

import com.codingbc.runmydocker.models.RequestLog;
import com.codingbc.runmydocker.services.RequestsLogging.RequestLogsService;
import com.codingbc.runmydocker.util.JsonUtil;
import java.io.IOException;
import java.lang.reflect.Array;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.util.*;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import io.netty.util.internal.StringUtil;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.util.ContentCachingRequestWrapper;
import org.springframework.web.util.ContentCachingResponseWrapper;

@Profile("!dev")
@Component
@Slf4j
public class RequestResponseLoggingFilter extends OncePerRequestFilter {

  @Autowired private RequestLogsService requestLogsService;
  @Autowired private JsonUtil jsonUtil;

  /**
   * Can be overridden in subclasses for custom filtering control, returning {@code true} to avoid
   * filtering of the given request.
   *
   * <p>The default implementation always returns {@code false}.
   *
   * @param request current HTTP request
   * @return whether the given request should <i>not</i> be filtered
   * @throws ServletException in case of errors
   */
  @Override
  protected boolean shouldNotFilter(HttpServletRequest request) throws ServletException {
    return !request.getRequestURI().matches("/api/.*");
  }

  /**
   * Same contract as for {@code doFilter}, but guaranteed to be just invoked once per request
   * within a single request thread. See {@link #shouldNotFilterAsyncDispatch()} for details.
   *
   * <p>Provides HttpServletRequest and HttpServletResponse arguments instead of the default
   * ServletRequest and ServletResponse ones.
   *
   * @param request
   * @param response
   * @param filterChain
   */
  @Override
  protected void doFilterInternal(
      HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
      throws ServletException, IOException {

    UUID requestId = (UUID) request.getAttribute("requestId");
    String username = (String) request.getAttribute("username");
    ContentCachingRequestWrapper requestWrapper = new ContentCachingRequestWrapper(request);
    ContentCachingResponseWrapper responseWrapper = new ContentCachingResponseWrapper(response);
    filterChain.doFilter(requestWrapper, responseWrapper);
    if (request.getRequestURI().contains("/logs") || request.getRequestURI().contains("/api/migrations")) {
      responseWrapper.copyBodyToResponse();
      return;
    }

    logRequest(requestWrapper, requestId, username);
    logResponse(responseWrapper, requestId);
    responseWrapper.copyBodyToResponse();
  }

  private void logRequest(ContentCachingRequestWrapper request, UUID requestId, String username) {
    boolean isAuthRequest = request.getRequestURI().contains("/api/auth/");
    String requestBody = new String(request.getContentAsByteArray(), StandardCharsets.UTF_8);
    Map<String, Object> queryParams = getQueryStrings(request);

    RequestLog requestLog = new RequestLog();
    requestLog.setRequestUrl(request.getRequestURI());
    requestLog.setMethod(request.getMethod());
    requestLog.setClientIp(request.getRemoteAddr());
    requestLog.setTimestamp(LocalDateTime.now());
    requestLog.setRequestId(requestId);
    requestLog.setQueryParams(queryParams);
    requestLog.setRequestBody(jsonUtil.parseToMap(requestBody));
    requestLog.setUsername(isAuthRequest ? null : username);

    requestLogsService.save(requestLog);
    log.info("Request: [{}]", requestBody);
  }

  @NotNull
  private static Map<String, Object> getQueryStrings(ContentCachingRequestWrapper request) {
    if (request.getQueryString() == null) {
      return Map.of();
    }
    String[] queryStrings = request.getQueryString().split("&");
    Map<String, Object> queryParams = new HashMap<>();
    for (String queryString : queryStrings) {
      String[] queryParam = queryString.split("=");
      queryParams.put(queryParam[0], queryParam[1]);
    }
    return queryParams;
  }

  private void logResponse(ContentCachingResponseWrapper responseWrapper, UUID requestId) {
    String responseBody = new String(responseWrapper.getContentAsByteArray());
    RequestLog requestLog = requestLogsService.findByRequestId(requestId);
    log.info("Response: [{}]", responseBody);
    boolean isLogsRequest = requestLog.getRequestUrl().endsWith("/logs");

    if (StringUtil.isNullOrEmpty(responseBody)) {
      requestLog.setSuccess(false);
      requestLog.setStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
      requestLogsService.save(requestLog);

      return;
    }
    if (requestLog != null) {
      Map<String, Object> parsedBody = jsonUtil.parseToMap(responseBody);
      if (isLogsRequest) {
        requestLog.setResponseBody(Map.of("logs", "not shown"));
      } else {
        requestLog.setResponseBody(parsedBody);
      }
      requestLog.setSuccess(parsedBody.get("success").toString().equals("true"));
      requestLog.setStatusCode(responseWrapper.getStatus());
      requestLogsService.save(requestLog);
    }
  }
}
