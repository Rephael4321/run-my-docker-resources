package com.codingbc.runmydocker.controllers;

import com.codingbc.runmydocker.docs.swagger.UserOutDTOApiResponse;
import com.codingbc.runmydocker.dto.AppUser.RegularUserCreateDTO;
import com.codingbc.runmydocker.dto.AppUser.UserChangePasswordRequest;
import com.codingbc.runmydocker.dto.AppUser.UserOutDTO;
import com.codingbc.runmydocker.mappers.User.IUserMapper;
import com.codingbc.runmydocker.models.User;
import com.codingbc.runmydocker.services.UserService;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.context.annotation.Lazy;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import static com.codingbc.runmydocker.dto.ApiResponse.success;

@RestController
@RequestMapping("/api/users")
public class UserController {

  private static final String USERNAME_ATTRIBUTE = "username";

  private final UserService userService;
  private final IUserMapper userMapper;

  public UserController(@Lazy UserService appUserService, IUserMapper userMapper) {
    this.userService = appUserService;
    this.userMapper = userMapper;
  }

  @PostMapping("/create")
  @ApiResponses(
      value = {
        @ApiResponse(code = 201, message = "User created successfully"),
        @ApiResponse(code = 400, response = ApiResponse.class, message = "Validation error"),
        @ApiResponse(code = 400, response = ApiResponse.class, message = "malform request"),
        @ApiResponse(code = 409, response = ApiResponse.class, message = "User already exists")
      })
  public ResponseEntity<com.codingbc.runmydocker.dto.ApiResponse<UserOutDTO>> create(
      @RequestBody @Valid RegularUserCreateDTO request) {
    User user = userService.create(request);
    UserOutDTO userOutDTO = userMapper.fromUserToUserOutDTO(user);
    var apiResponse = success(userOutDTO, "User created successfully", HttpStatus.CREATED, null);
    return ResponseEntity.status(HttpStatus.CREATED).body(apiResponse);
  }

  @GetMapping("/search")
  public ResponseEntity<?> search(@RequestParam Long id) {
    User byIdOr404 = userService.findByIdOr404(id);
    return new ResponseEntity<>(byIdOr404, HttpStatus.OK);
  }

  @ApiOperation(value = "Get user by username from request", response = UserOutDTOApiResponse.class)
  @ApiResponses(
      value = {
        @ApiResponse(
            code = 404,
            message = "User not found",
            response = com.codingbc.runmydocker.dto.ApiResponse.class),
        @ApiResponse(
            code = 401,
            message = "Unauthorized",
            response = com.codingbc.runmydocker.dto.ApiResponse.class)
      })
  @GetMapping("/getUser")
  public ResponseEntity<com.codingbc.runmydocker.dto.ApiResponse<UserOutDTO>> getUser(
      HttpServletRequest request) {
    String username = request.getAttribute(USERNAME_ATTRIBUTE).toString();
    UserOutDTO userOutDTO = userService.getUserByUsername(username);
    var apiResponse = success(userOutDTO, "User found", HttpStatus.OK, null);
    return ResponseEntity.ok().body(apiResponse);
  }

  @GetMapping("/find")
  public ResponseEntity<com.codingbc.runmydocker.dto.ApiResponse<UserOutDTO>> findUser(
      @RequestParam String username) {
    User user = userService.findByUsernameOr404(username);
    UserOutDTO userOutDTO = userMapper.fromUserToUserOutDTO(user);
    var apiResponse = success(userOutDTO, "User found", HttpStatus.OK, null);

    return ResponseEntity.ok().body(apiResponse);
  }

  @PutMapping("/changePassword")
  @ApiOperation(value = "Change password from user profile")
  @ApiResponses(
      value = {
        @ApiResponse(
            code = 200,
            message = "Password changed successfully",
            response = com.codingbc.runmydocker.dto.ApiResponse.class),
        @ApiResponse(
            code = 404,
            message = "User not found",
            response = com.codingbc.runmydocker.dto.ApiResponse.class),
        @ApiResponse(
            code = 400,
            message = "Bad Request",
            response = com.codingbc.runmydocker.dto.ApiResponse.class)
      })
  public ResponseEntity<com.codingbc.runmydocker.dto.ApiResponse<UserOutDTO>> changePassword(
      @RequestBody UserChangePasswordRequest request, HttpServletRequest servletRequest) {
    String username = servletRequest.getAttribute(USERNAME_ATTRIBUTE).toString();
    request.setUsername(username);
    User user = userService.changePassword(request);
    UserOutDTO userOutDTO = userMapper.fromUserToUserOutDTO(user);
    var apiResponse = success(userOutDTO, "Password changed successfully", HttpStatus.OK, null);
    return ResponseEntity.ok().body(apiResponse);
  }
}
