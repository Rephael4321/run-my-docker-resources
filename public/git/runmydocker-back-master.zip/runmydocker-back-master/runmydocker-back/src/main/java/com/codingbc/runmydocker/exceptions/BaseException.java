package com.codingbc.runmydocker.exceptions;

import lombok.Getter;
import org.springframework.http.HttpStatus;

import java.time.LocalDateTime;
import java.util.Map;

public class BaseException extends RuntimeException {
    @Getter
    private final HttpStatus status;
    private final String message;
    @Getter
    private final Map<String, Object> additionalInfo;
    @Getter
    private final LocalDateTime timestamp;



    public BaseException(HttpStatus status, String message, Map<String, Object> additionalInfo) {
        super(message);
        this.status = status;
        this.message = message;
        this.additionalInfo = additionalInfo;
        this.timestamp = LocalDateTime.now();
    }

    @Override
    public String getMessage() {
        return message;
    }

}