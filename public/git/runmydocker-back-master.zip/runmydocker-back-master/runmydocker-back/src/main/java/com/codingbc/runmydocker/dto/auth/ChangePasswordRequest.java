package com.codingbc.runmydocker.dto.auth;

import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;

@Setter
@Getter
public class ChangePasswordRequest {
  @NotBlank private String code;
  @NotBlank private String uuid;
  @Email private String username;
  @NotBlank private String password;

  public ChangePasswordRequest() {}

  public ChangePasswordRequest(String code, String uuid, String username, String password) {
    this.code = code;
    this.uuid = uuid;
    this.username = username;
    this.password = password;
  }
}
