package com.codingbc.runmydocker.services.RequestsLogging;

import com.codingbc.runmydocker.models.RequestLog;
import java.util.UUID;

public interface IRequestLogsService {

  RequestLog save(RequestLog requestLog);

  RequestLog findByRequestId(UUID requestId);

  RequestLog update(RequestLog requestLog);
}
