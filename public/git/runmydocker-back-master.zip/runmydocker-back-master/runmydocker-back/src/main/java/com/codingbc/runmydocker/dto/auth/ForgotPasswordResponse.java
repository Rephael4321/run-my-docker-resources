package com.codingbc.runmydocker.dto.auth;

import lombok.Data;

@Data
public class ForgotPasswordResponse {
  private String uuid;

  public static ForgotPasswordResponse of(String uuid) {
    ForgotPasswordResponse response = new ForgotPasswordResponse();
    response.setUuid(uuid);
    return response;
  }
}
