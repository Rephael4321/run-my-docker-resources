/*
 * Copyright (c) 2024.
 */

package com.codingbc.runmydocker.builders;

import com.codingbc.runmydocker.enums.ContainerCreationStatus;
import com.codingbc.runmydocker.models.User;
import com.codingbc.runmydocker.models.UserApplication;

public final class UserApplicationBuilder {

  private final UserApplication userApplication;

  public UserApplicationBuilder() {
    userApplication = new UserApplication();
  }

  public UserApplicationBuilder(UserApplication other) {
    this.userApplication = other;
  }

  public static UserApplicationBuilder anUserApplication() {
    return new UserApplicationBuilder();
  }

  public UserApplicationBuilder withId(long id) {
    userApplication.setId(id);
    return this;
  }

  public UserApplicationBuilder withStatus(ContainerCreationStatus status) {
    userApplication.setStatus(status);
    return this;
  }

  public UserApplicationBuilder withPort(int port) {
    userApplication.setPort(port);
    return this;
  }

  public UserApplicationBuilder withDockerImage(String image) {
    userApplication.setDockerImage(image);
    return this;
  }

  public UserApplicationBuilder withContainerPort(int port) {
    userApplication.setContainerPort(port);
    return this;
  }

  public UserApplicationBuilder withUsername(String username) {
    userApplication.setUsername(username);
    return this;
  }

  public UserApplicationBuilder withContainerId(String containerId) {
    userApplication.setContainerId(containerId);
    return this;
  }

  public UserApplicationBuilder withAppName(String appName) {
    userApplication.setAppName(appName);
    return this;
  }

  public UserApplicationBuilder withMinikubeApp(Boolean minikubeApp) {
    userApplication.setMinikubeApp(minikubeApp);
    return this;
  }

  public UserApplicationBuilder withRemainingTime(int remainingTime) {
    userApplication.setRemainingTime(remainingTime);
    return this;
  }

  public UserApplicationBuilder withUser(User user) {
    userApplication.setUser(user);
    return this;
  }

  public UserApplication build() {
    return userApplication;
  }
}
