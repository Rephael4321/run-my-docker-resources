/*
 * Copyright (c) 2024.
 */

package com.codingbc.runmydocker.enums;

public enum ContainerStatus {
  CREATED("created"), RUNNING("running"), PAUSED("paused"), RESTARTING("restarting"), REMOVING(
      "removing"), EXITED("exited"), DEAD("dead");

  private final String status;

  ContainerStatus(String status) {
    this.status = status;
  }

  public String getStatus() {
    return this.status;
  }
}

