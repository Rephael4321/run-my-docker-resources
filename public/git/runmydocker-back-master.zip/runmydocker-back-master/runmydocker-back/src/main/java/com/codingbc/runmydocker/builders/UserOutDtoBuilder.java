package com.codingbc.runmydocker.builders;

import com.codingbc.runmydocker.dto.AppUser.UserOutDTO;
import com.codingbc.runmydocker.models.User;

public class UserOutDtoBuilder {
  private long id;
  private String firstName;
  private String lastName;
  private String username;
  private String phone;

  private boolean activated;

  public static UserOutDtoBuilder builder() {
    return new UserOutDtoBuilder();
  }

  public UserOutDtoBuilder withId(long id) {
    this.id = id;
    return this;
  }

  public UserOutDtoBuilder withFirstName(String firstName) {
    this.firstName = firstName;
    return this;
  }

  public UserOutDtoBuilder withLastName(String lastName) {
    this.lastName = lastName;
    return this;
  }

  public UserOutDtoBuilder withUsername(String username) {
    this.username = username;
    return this;
  }

  public UserOutDtoBuilder withPhone(String phone) {
    this.phone = phone;
    return this;
  }

  public UserOutDtoBuilder withActivated(boolean activated) {
    this.activated = activated;
    return this;
  }

  public UserOutDTO build() {
    UserOutDTO userOutDTO = new UserOutDTO();
    userOutDTO.setId(this.id);
    userOutDTO.setUsername(this.username);
    userOutDTO.setPhone(this.phone);
    userOutDTO.setFirstName(this.firstName);
    userOutDTO.setLastName(this.lastName);
    userOutDTO.setActivated(this.activated);

    return userOutDTO;
  }
}
