/*
 * Copyright (c) 2024.
 */

package com.codingbc.runmydocker.events.Docker;

import com.codingbc.runmydocker.models.UserApplication;
import com.codingbc.runmydocker.services.UserApplicationService;
import com.github.dockerjava.api.command.CreateContainerResponse;
import lombok.Getter;
import org.springframework.context.ApplicationEvent;

@Getter
public class ContainerCreatedEvent extends ApplicationEvent {
  private final CreateContainerResponse createContainerResponse;
  private final UserApplication application;

  public ContainerCreatedEvent(
      Object source, CreateContainerResponse createContainerResponse, UserApplication application) {
    super(source);
    this.createContainerResponse = createContainerResponse;
    this.application = application;
  }

}
