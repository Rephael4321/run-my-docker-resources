package com.codingbc.runmydocker.dto.UserApplication;

public enum ApplicationSearchKeys {
  ID("id"),
  DOCKER_IMAGE("dockerImage"),
  APP_NAME("appName"),
  MAPPING_PORT("mappingPort"),
  USERNAME("username"),
  CREATED_AT("createdAt"),
  UPDATED_AT("updatedAt"),
  IS_RUNNING("isRunning"),
  REMAINING_TIME("remainingTime"),
  STATUS_INFO("statusInfo");

  private final String key;

  ApplicationSearchKeys(String key) {
    this.key = key;
  }

  public String getKey() {
    return key;
  }
}
