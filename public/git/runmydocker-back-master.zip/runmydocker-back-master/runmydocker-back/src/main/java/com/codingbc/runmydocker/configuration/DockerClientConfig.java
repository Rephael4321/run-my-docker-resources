/*
 * Copyright (c) 2024.
 */

package com.codingbc.runmydocker.configuration;

import com.github.dockerjava.api.DockerClient;
import com.github.dockerjava.core.DefaultDockerClientConfig;
import com.github.dockerjava.core.DockerClientBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DockerClientConfig {
  @Bean
  DockerClient dockerClient() {
    String dockerHost = System.getenv("DOCKER_HOST");
    if (dockerHost == null || dockerHost.isEmpty()) {
      return DockerClientBuilder.getInstance().build();
    }

    //    return DockerClientBuilder.getInstance(dockerHost).build();
    DefaultDockerClientConfig dockerClientConfig =
        DefaultDockerClientConfig.createDefaultConfigBuilder().withDockerHost(dockerHost).build();

    return DockerClientBuilder.getInstance(dockerClientConfig).build();
  }
}
