/*
 * Copyright (c) 2024.
 */

package com.codingbc.runmydocker.commands.UserApplication;

public interface UserAppCmd {
  void execute();

}
