package com.codingbc.runmydocker.services.sms;

public interface ISmsService {
  boolean send(String phone, String text);
}
