package com.codingbc.runmydocker.repositories;

import com.codingbc.runmydocker.models.UserFeatureFlag;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


import java.util.Optional;


public interface UserFeatureFlagRepository extends JpaRepository<UserFeatureFlag, Long> {
    Optional<UserFeatureFlag> findByUserIdAndFlagName(Long userId, String flagName);
}