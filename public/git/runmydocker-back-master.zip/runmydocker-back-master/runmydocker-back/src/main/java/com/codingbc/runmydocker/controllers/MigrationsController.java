package com.codingbc.runmydocker.controllers;

import com.codingbc.runmydocker.dto.migrations.OldUserDTO;
import com.codingbc.runmydocker.models.migrations.UserApplicationToMigrate;
import com.codingbc.runmydocker.services.migrations.JsonService;
import com.codingbc.runmydocker.services.migrations.MigrationsService;
import com.github.dockerjava.api.DockerClient;
import com.github.dockerjava.api.model.Container;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("api/migrations")
public class MigrationsController {
  private final MigrationsService migrationsService;
  private final DockerClient dockerClient;

  public MigrationsController(MigrationsService migrationsService, DockerClient dockerClient) {
    this.migrationsService = migrationsService;
    this.dockerClient = dockerClient;
  }

  @PostMapping("users/migrate")
  public ResponseEntity<?> uploadUsersForMigration(@RequestParam("file") MultipartFile file) {
    if (file.isEmpty()) {
      return ResponseEntity.badRequest().body("File is empty");
    }
    try {

      return ResponseEntity.ok(migrationsService.migrateUsers(file));
    } catch (Exception e) {
      System.out.println(e.getMessage());
      return ResponseEntity.badRequest().body("Error while parsing file");
    }
  }

  @PostMapping("containers/migrate")
  public ResponseEntity<?> migrateContainersData(@RequestParam("file") MultipartFile file) {
    if (file.isEmpty()) {
      return ResponseEntity.badRequest().body("File is empty");
    }
    try {

      return ResponseEntity.ok(migrationsService.migrateContainersData(file));
    } catch (Exception e) {
      System.out.println(e.getMessage());
      return ResponseEntity.badRequest().body("Error while parsing file");
    }
  }

  @GetMapping("containers")
  public ResponseEntity<?> migrateContainerFromDB() {
    migrationsService.migrateDockerContainersFromDb();
    return ResponseEntity.noContent().build();
  }

  @PostMapping("containers")
  public ResponseEntity<?> migrateContainerToDB(
      @RequestBody UserApplicationToMigrate userApplicationToMigrate) {
    migrationsService.migrateContainer(userApplicationToMigrate);
    return ResponseEntity.noContent().build();
  }

  @GetMapping("find-containers")
  public ResponseEntity<?> findContainers() {
    String[] names = {
      "chat",
      "ModernBackend",
      "Modern_Backend",
      "Eureka-server",
      "telegram-bot",
      "chatbot3",
      "NotesAppDocker",
      "brachalink",
      "tiny",
      "chatbot",
      "eduard-spring",
      "myfxbook-parser",
      "sara-basicspring",
      "eduard-chatbot",
      "chat2",
      "basic-spring-v2",
      "eran-chatbot",
      "tinyurl",
      "basic-spring",
      "text-trivia",
      "raz-tinyurl",
      "shohamd-tinyurl",
      "searchengine",
      "MohamedSearchEngineV2",
      "triel",
      "edenr-chatbot",
      "calanittest",
      "calanittest1",
      "calanittest2",
      "calanittest3",
      "calanittest4",
      "test",
      "test1",
      "runmydocker-back",
      "test0",
      "test2",
      "testt",
      "java-docker",
      "test2123",
      "test21234",
      "test212345678",
      "test201",
      "test202",
      "test203",
      "test204",
      "test206",
      "1234",
      "test283781",
      "test286251",
      "test279090",
      "test220246",
      "test265241",
      "test272027",
      "test278210",
      "test250081",
      "test28548",
      "test228274",
      "test260019",
      "demo58344",
      "demo16162",
      "demo17294",
      "demo3868",
      "demo38484",
      "demo68033",
      "demo953",
      "demo95032",
      "demo75049",
      "demo54454",
      "demo87917",
      "demo6104",
      "demo70726",
      "demo26291",
      "demo76628",
      "demo86768",
      "demo62166",
      "demo92610",
      "demo34020",
      "demo80338",
      "demo98955",
      "demo55944",
      "demo92015",
      "demo47370",
      "cartcrafter2",
      "demo74667",
      "noam-chatbot",
      "demo95395",
      "noaa-tinyurl",
      "barak-chatbot",
      "tatiana-chatbot",
      "yarden-chatbot",
      "nitsnats-chatbot",
      "gali-chatbot",
      "nitsnats-tinyurl",
      "idok-searchengine",
      "dvirh-chatbot",
      "dvirh-spring",
      "idok-tinyurl",
      "idok-basicspring",
      "pl-racism",
      "gali-sentiment",
      "gali-tinyurl",
      "gali-searchengine",
      "pokemonApi",
      "niv-chatbot1234",
      "yardent-basic-spring",
      "alonr-student-management-spring",
      "michelle-basicSpring",
      "jfjfj",
      "kffk",
      "idok-chatbotapp",
      "studentsManagement",
      "nnn",
      "Harel-sentimentanalysis",
      "Harel-tinyurl",
      "Harel-basicspring",
      "elidor-logintask",
      "nivniv",
      "test-scrapper11",
      "testest",
      "node.js",
      "testing-1",
      "testing-2",
      "yarin-tinyurl",
      "ofek-basic",
      "react-app",
      "yaring-basicspring",
      "yaring-searchengine",
      "roee-tinyurl1",
      "yarin-chatbot",
      "roee-tinyurl",
      "mailing-service",
      "michelle-student-manage",
      "students",
      "basicspring-moti",
      "searchengine-moti",
      "orel-chatbot",
      "yaring-quiz",
      "smart-agent-fastapi2",
      "gil-chatbot",
      "gil-tinyurl",
      "forter",
      "smart-agent-server",
      "andreym-chatbot",
      "andreym-tinyurl",
      "lpm-stations-orel",
      "andreym-basicspring",
      "harely-chatbot",
      "eli-basic-spring",
      "michelle-tiny",
      "eli-chatbot",
      "achinoam-basic",
      "achinoam1-basuc",
      "sentiment",
      "yair-tinyurl",
      "eli-searchengine",
      "identifier",
      "linkdin-scraper",
      "pantrypal",
      "imdb-chatbot",
      "sportsappchatbot",
      "flight-simulator-code-interpreter",
      "achinoam-chatbot",
      "gal-chatbot",
      "ilanv-searchengine",
      "searchengigne102",
      "tinyurl003",
      "backend",
      "myback",
      "maps-api",
      "amitg-chatbot",
      "gal-searchengine",
      "roei-tinyurl",
      "ilanv145-basic",
      "noamha-chatbot",
      "efratf-chatbot",
      "todo-list",
      "noamha-chatbot1",
      "ilanv-tinyurl",
      "danielshapchatbot",
      "test-avi",
      "danir-chatbot",
      "danie-tinyurl",
      "tedfkdsd",
      "lirov-chatbot",
      "daniel-searchengine",
      "nivv2",
      "myemployees",
      "daniel-sentimentanalysis",
      "starbucks",
      "starbucks-demo",
      "achinoam-tinturl",
      "paradisevacations",
      "jobinterviewai",
      "tinyurl-aryoz",
      "warehouse-management-order",
      "recipesuggestor-bot",
      "chatbotmishel",
      "niv-todo",
      "talentplease-tablesapi",
      "bar-chatbot",
      "yardena-chatbot",
      "netanelw-basicspring2",
      "net-spring",
      "nadav-chatbot",
      "bars-tinyurl",
      "bars-sentiment",
      "eladt-chatbot2",
      "bars-basicspring",
      "chat-ai-db",
      "chat-ai-gge",
      "bars-searchengine",
      "chat-ai-db-v2",
      "eladten-tinyurl2",
      "receipt-scanner",
      "apache-analytics",
      "efratperetz-chatbot",
      "talentplease-tablesapi1",
      "efratperetz-tinyurl1",
      "efratperetz-tinyurl",
      "efratperetz-searchengine",
      "lilach-chatbot",
      "eladt-searchengine",
      "tehilanatan-basic-spring",
      "asafb-chatbot-002-003",
      "trip-planner",
      "asaf-tinyurl-001",
      "vmfc-api-run",
      "lilach-tinyurl",
      "sentimentmishel",
      "searchmishel",
      "tinyurlmishelbentsur",
      "vidtube",
      "aviv-gpt",
      "aviv-gpt2",
      "roni-chatbot",
      "roni-tinyurl",
      "tinyurl-lidormor",
      "chatbot0011",
      "smartcalendar",
      "dashboard",
      "chatbot-007",
      "cheap-trips",
      "tmoshel-basic",
      "names",
      "student-information-managment",
      "yaakovg-searchengine002",
      "trivia-game-ai",
      "yaakovg-tinyurl",
      "yaakovg-basic-spring",
      "my-chatbot",
      "ariel-chatbot",
      "tmoshel-tinyurl",
      "keren-chatbot",
      "arielb-basic-spring",
      "tmoshel-chatbot",
      "avinatan",
      "quizgame",
      "guy-chatbot",
      "guy-searchengine",
      "tinyurlnew",
      "amit-tiny",
      "amit-chatbot",
      "tinyurl-003",
      "md-security22",
      "accesscontrolfacerecog",
      "socialmedia",
      "amit-searchengine",
      "ticketbot-012",
      "students-server",
      "currency",
      "tinyurl2",
      "nirsh-chatbot",
      "ben-searchengine-1",
      "ben-sentiment",
      "ben-chatbot",
      "omer-basic",
      "bussiness-app",
      "bussiness",
      "test-scrapper38",
      "ask-ai",
      "basic-spring-nir",
      "nirsh-search-engine",
      "fastapi",
      "basic-spring-eldad",
      "cvgenerator",
      "nirk-chatbot",
      "search-engine",
      "matanswisa01-basic-spring",
      "nirk-tinyurl",
      "searchengine-knir",
      "miryam-tinyurl",
      "miryam-chatbot",
      "test-app-natan",
      "scraping-service",
      "qweqwe",
      "cellxpert-nx-project",
      "kofsfle",
      "tinybar3",
      "procv",
      "bar-chatbot3",
      "reshex-basicspring",
      "reshex-tinyurl",
      "reshex-chatbot",
      "nirsh-tinyurl",
      "abc",
      "welcome-with-ui",
      "bbb",
      "schoolsystem",
      "schooldudasystem",
      "natan-guidde",
      "guidde-demo-1",
      "romand-chatbot",
      "moti-basic-flask",
      "moti-basic-flask--",
      "realestate-tracker2",
      "tracker-realestate",
      "dudaschoolproject",
      "spring-boot",
      "real-estate-tracker",
      "guidde-deploy",
      "miryam-enginesearch",
      "pupil-lesson-generator",
      "j-redis",
      "newsai",
      "shopping-receipt",
      "hhkjhh",
      "testprivateassistant",
      "elecen-leaddapp",
      "travelad",
      "bsacicet",
      "tzion-heart-rate",
    };
    List<String> namesList = Arrays.asList(names);
    List<String> containers =
        dockerClient.listContainersCmd().withShowAll(true).exec().stream()
            .map(Container::getNames)
            .flatMap(Arrays::stream)
            .map(name -> name.replace("/", ""))
            .collect(Collectors.toList());
    List<String> containersToRename =
        namesList.stream().filter(name -> containers.contains(name)).collect(Collectors.toList());

    List<String> unfoundContainers =
        namesList.stream().filter(name -> !containers.contains(name)).collect(Collectors.toList());
    //    // rename containers

        for (String containerName : containersToRename) {
          try {
            dockerClient.renameContainerCmd(containerName).withName(containerName +
     "-old").exec();
          } catch (Exception e) {
            System.out.println("Error while renaming container " + containerName);
          }
          }

    return ResponseEntity.ok(
        Map.of("containers", containersToRename, "unfoundContainers", unfoundContainers));
  }
}
