package com.codingbc.runmydocker.services.migrations;

import com.codingbc.runmydocker.dto.migrations.ContainerInfo;
import com.codingbc.runmydocker.dto.migrations.OldUserDTO;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@Service
public class JsonService {
  private final ObjectMapper objectMapper;

  public JsonService(ObjectMapper objectMapper) {
    this.objectMapper = objectMapper;
  }

  public List<OldUserDTO> parseOldUsers(MultipartFile file) throws IOException {
    return objectMapper.readValue(
        file.getInputStream(),
        objectMapper.getTypeFactory().constructCollectionType(List.class, OldUserDTO.class));
  }

  public List<ContainerInfo> parseContainers(MultipartFile file) throws IOException {
    return objectMapper.readValue(
        file.getInputStream(),
        objectMapper.getTypeFactory().constructCollectionType(List.class, ContainerInfo.class));
  }
}
