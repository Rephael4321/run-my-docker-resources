package com.codingbc.runmydocker.models;

import com.codingbc.runmydocker.BaseEntity;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import java.util.UUID;

@Entity
@Getter
@Setter
@Table(
    name = "user_feature_flags",
    uniqueConstraints = {@UniqueConstraint(columnNames = {"user_id", "flag_name"})})
public class UserFeatureFlag extends BaseEntity {

  @Column(nullable = false, name = "user_id")
  private long userId;

  @Column(nullable = false, name = "flag_name")
  private String flagName;

  @Column(nullable = false)
  private Boolean isEnabled;
}
