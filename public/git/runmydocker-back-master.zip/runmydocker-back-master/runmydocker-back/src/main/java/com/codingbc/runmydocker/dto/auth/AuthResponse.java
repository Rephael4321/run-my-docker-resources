package com.codingbc.runmydocker.dto.auth;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class AuthResponse {
  @JsonProperty("jwtToken")
  private String token;
}
