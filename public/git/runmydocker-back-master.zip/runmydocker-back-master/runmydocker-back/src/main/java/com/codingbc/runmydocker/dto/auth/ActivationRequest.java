package com.codingbc.runmydocker.dto.auth;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;

import lombok.*;

@Getter
@Setter
public class ActivationRequest {
  @NotBlank private String code;
  @NotBlank private String uuid;
  @NotBlank @Email private String username;

  public ActivationRequest() {

  }

  public ActivationRequest(String code, String uuid, String username) {
    this.code = code;
    this.uuid = uuid;
    this.username = username;
  }
}
