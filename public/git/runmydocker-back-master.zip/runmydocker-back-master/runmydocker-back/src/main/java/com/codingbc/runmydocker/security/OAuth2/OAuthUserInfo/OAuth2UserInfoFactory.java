/*
 * Copyright (c) 2024.
 */

package com.codingbc.runmydocker.security.OAuth2.OAuthUserInfo;

import com.codingbc.runmydocker.exceptions.ApiError;
import com.codingbc.runmydocker.exceptions.GeneralError;
import java.util.Map;

public class OAuth2UserInfoFactory {

  public static OAuth2UserInfo getUserInfo(String registrationId, Map<String, Object> attrs) {
    if (registrationId.equalsIgnoreCase(eRegistrationId.GOOGLE.getValue())) {
      return new GoogleOAuth2UserInfo(attrs);
    } else {
      throw new GeneralError(String.format("Sorry, Login with %s is not supported", registrationId));
    }
  }

}
