/*
 * Copyright (c) 2024.
 */

package com.codingbc.runmydocker.dto.UserApplication;

import com.codingbc.runmydocker.models.UserApplication;
import lombok.Data;

@Data
public class ApplicationCreateResponse {
  private Long id;
  private String appName;
  private String containerId;
  private String dockerImage;
  private boolean isRunning;
  private int remainingTime;

  public static ApplicationCreateResponse toApplicationCreateResponse(
      UserApplication userApplication) {
    if (userApplication == null) return null;

    ApplicationCreateResponse response = new ApplicationCreateResponse();
    response.setId(userApplication.getId());
    response.setAppName(userApplication.getAppName());
    response.setContainerId(userApplication.getContainerId());
    response.setDockerImage(userApplication.getDockerImage());
    response.setRunning(userApplication.isRunning());
    response.setRemainingTime(userApplication.getRemainingTime());

    return response;
  }
}
