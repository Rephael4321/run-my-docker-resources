/*
 * Copyright (c) 2024.
 */

package com.codingbc.runmydocker.dto.UserApplication;

import lombok.Data;

@Data
public class NewContainerData {
  String image;
  String containerName;
  int port;
  int containerPort;
}
