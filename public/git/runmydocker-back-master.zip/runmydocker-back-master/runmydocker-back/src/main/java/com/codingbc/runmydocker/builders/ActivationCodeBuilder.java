package com.codingbc.runmydocker.builders;

import com.codingbc.runmydocker.models.ActivationCode;
import com.codingbc.runmydocker.models.User;
import java.time.LocalDateTime;

public final class ActivationCodeBuilder {

  private ActivationCode activationCode;

  public ActivationCodeBuilder() {
    activationCode = new ActivationCode();
  }

  public ActivationCodeBuilder(ActivationCode other) {
    this.activationCode = other;
  }

  public static ActivationCodeBuilder anActivationCode() {
    return new ActivationCodeBuilder();
  }

  public ActivationCodeBuilder withId(long id) {
    activationCode.setId(id);
    return this;
  }

  public ActivationCodeBuilder withUsed(boolean used) {
    activationCode.setUsed(used);
    return this;
  }

  public ActivationCodeBuilder withCode(String code) {
    activationCode.setCode(code);
    return this;
  }

  public ActivationCodeBuilder withExpirationTime(LocalDateTime expirationTime) {
    activationCode.setExpirationTime(expirationTime);
    return this;
  }

  public ActivationCodeBuilder withUuidToken(String uuidToken) {
    activationCode.setUuidToken(uuidToken);
    return this;
  }

  public ActivationCodeBuilder withUser(User user) {
    activationCode.setUser(user);
    return this;
  }

  public ActivationCodeBuilder but() {
    return anActivationCode()
        .withId(activationCode.getId())
        .withCode(activationCode.getCode())
        .withExpirationTime(activationCode.getExpirationTime())
        .withUuidToken(activationCode.getUuidToken())
        .withUser(activationCode.getUser());
  }

  public ActivationCode build() {
    return activationCode;
  }
}
