package com.codingbc.runmydocker.util;

import com.codingbc.runmydocker.enums.ContainerCreationStatus;
import com.codingbc.runmydocker.enums.ContainerStatus;
import com.codingbc.runmydocker.exceptions.BadRequest;
import com.codingbc.runmydocker.models.UserApplication;
import com.codingbc.runmydocker.services.DockerService;
import com.github.dockerjava.api.command.InspectContainerResponse;
import com.github.dockerjava.api.exception.NotFoundException;
import java.util.Map;
import java.util.Objects;

public class AppActionsValidationUtils {

  public static void validateAppCanStart(
      UserApplication userApplication, DockerService dockerService) {
    boolean hasNoTimeToRun = userApplication.getRemainingTime() <= 0;
    boolean isNotWithCreatedStatus = userApplication.getStatus() != ContainerCreationStatus.CREATED;
    boolean applicationRunning = userApplication.isRunning();
    if (hasNoTimeToRun) {
      throw new BadRequest(
          "Application has no remaining time to run",
          Map.of("time", userApplication.getRemainingTime()));
    }
    if (isNotWithCreatedStatus) {
      throw new BadRequest(
          "Application can't be started", Map.of("status", userApplication.getStatus()));
    }
    if (applicationRunning) {
      throw new BadRequest("Application is already running");
    }
    validateContainerStatus(userApplication, dockerService, ContainerStatus.EXITED);
  }

  public static void validateAppCanStop(
      UserApplication userApplication, DockerService dockerService) {
    boolean isNotWithCreatedStatus = userApplication.getStatus() != ContainerCreationStatus.CREATED;
    boolean applicationNotRunning = !userApplication.isRunning();

    if (isNotWithCreatedStatus) {
      throw new BadRequest(
              "Application can't be started", Map.of("status", userApplication.getStatus()));
    }

    if (applicationNotRunning) {
      throw new BadRequest("Application is not running");
    }

    validateContainerStatus(userApplication, dockerService, ContainerStatus.RUNNING);
  }

  public static void validateAppCanBeDeleted(
      UserApplication userApplication, DockerService dockerService) {
    boolean isNotWithCreatedStatus = userApplication.getStatus() != ContainerCreationStatus.CREATED;
    boolean isNotUnhealthy = userApplication.getStatus() != ContainerCreationStatus.UNHEALTHY;
    boolean applicationRunning = userApplication.isRunning();

    if (isNotWithCreatedStatus && isNotUnhealthy) {
      throw new BadRequest("Application status is not created and container is not unhealthy");
    }

    if (applicationRunning) {
      throw new BadRequest("Application is running. Stop it first");
    }
    validateContainerStatus(userApplication, dockerService, ContainerStatus.EXITED);
  }

  public static void validateAppCanChangeVersion(
      UserApplication userApplication, DockerService dockerService) {
    validateAppCanBeDeleted(userApplication, dockerService);
  }

  public static void validateContainerExists(String containerName, DockerService dockerService)
      throws NotFoundException {
    dockerService
        .isContainerExists(containerName)
        .orElseThrow(() -> new NotFoundException("Container not found: " + containerName));
  }

  private static void validateContainerStatus(
      UserApplication userApplication,
      DockerService dockerService,
      ContainerStatus expectedStatus) {
    validateContainerExists(userApplication.getAppName(), dockerService);
    InspectContainerResponse inspectContainerResponse =
        dockerService.inspectDocker(userApplication.getAppName());
    String containerStatus = inspectContainerResponse.getState().getStatus();
    boolean isCreatedStatus = Objects.equals(containerStatus, ContainerStatus.CREATED.getStatus());
    boolean isStatusesMatch = Objects.equals(containerStatus, expectedStatus.getStatus());

    if (!isStatusesMatch && !isCreatedStatus) {
      throw new BadRequest("Container status is not " + expectedStatus.getStatus());
    }
  }
}
