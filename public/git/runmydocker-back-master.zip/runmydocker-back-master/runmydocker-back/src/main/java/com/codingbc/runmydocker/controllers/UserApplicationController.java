/*
 * Copyright (c) 2024.
 */

package com.codingbc.runmydocker.controllers;

import com.codingbc.runmydocker.docs.swagger.*;
import com.codingbc.runmydocker.dto.ApiResponse;
import com.codingbc.runmydocker.dto.UserApplication.*;

import com.codingbc.runmydocker.mappers.UserApplication.IUserApplicationMapper;
import com.codingbc.runmydocker.models.UserApplication;
import com.codingbc.runmydocker.services.UserApplicationService;
import com.codingbc.runmydocker.services.ValidationService;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponses;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;

import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.function.ServerRequest;

@RestController
@RequestMapping("/api/userApplications")
public class UserApplicationController {

        private final UserApplicationService userApplicationService;
        private final IUserApplicationMapper userApplicationMapper;
        private final ValidationService validationService;

        public UserApplicationController(
                        UserApplicationService userApplicationService,
                        IUserApplicationMapper userApplicationMapper,
                        ValidationService validationService) {
                this.userApplicationService = userApplicationService;

                this.userApplicationMapper = userApplicationMapper;
                this.validationService = validationService;
        }

        @PostMapping("/create")
        @ApiOperation(value = "Create new application")
        @ApiResponses(value = {
                        @io.swagger.annotations.ApiResponse(code = 201, message = "App created"),
                        @io.swagger.annotations.ApiResponse(code = 400, message = "User reached app limit | Validation error", response = ApiResponse.class),
                        @io.swagger.annotations.ApiResponse(code = 401, message = "Unauthorized", response = ApiResponse.class),
                        @io.swagger.annotations.ApiResponse(code = 409, message = "AppName is taken", response = ApiResponse.class),
                        @io.swagger.annotations.ApiResponse(code = 500, message = "Server error", response = ApiResponse.class),
                        @io.swagger.annotations.ApiResponse(code = 404, message = "Image | User not found", response = ApiResponse.class)
        })
        public ResponseEntity<ApiResponse<NewApplicationResponse>> createApplication(
                        @RequestBody UserApplicationCreateDTO userApplicationCreateDTO, HttpServletRequest request) {
                String username = request.getAttribute("username").toString();
                userApplicationCreateDTO.setUsername(username);
                UserApplication userApplication = userApplicationService.create(userApplicationCreateDTO);
                NewApplicationResponse newApplicationResponse = userApplicationMapper
                                .toNewApplicationResponse(userApplication);
                ApiResponse<NewApplicationResponse> apiResponse = ApiResponse.success(newApplicationResponse,
                                "app created",
                                HttpStatus.CREATED, null);

                return new ResponseEntity<>(apiResponse, HttpStatus.CREATED);
        }

        @PutMapping("/{appId}/changeVersion")
        @ApiOperation(value = "Change application version")
        public ResponseEntity<?> changeVersions(
                        @PathVariable Long appId,
                        @RequestBody ChangeVersionRequest changeVersionRequest,
                        HttpServletRequest request) {
                String username = request.getAttribute("username").toString();
                changeVersionRequest.setUsername(username);
                userApplicationService.changeVersion(appId, changeVersionRequest);
                return ResponseEntity.noContent().build();
        }

        @ApiOperation(value = "Get application by id")
        @ApiResponses(value = {
                        @io.swagger.annotations.ApiResponse(code = 200, message = "Application found"),
                        @io.swagger.annotations.ApiResponse(code = 401, message = "Unauthorized", response = ApiResponse.class),
                        @io.swagger.annotations.ApiResponse(code = 404, message = "Application not found", response = ApiResponse.class)
        })
        @GetMapping("/byId")
        public ResponseEntity<ApiResponse<UserApplicationOut>> getApplicationById(@RequestParam Long id) {
                UserApplication application = userApplicationService.getById(id);
                UserApplicationOut userApplicationOut = userApplicationMapper.toUserApplicationOut(application);
                ApiResponse<UserApplicationOut> apiResponse = ApiResponse.success(userApplicationOut,
                                "Application found",
                                HttpStatus.OK, null);
                return new ResponseEntity<>(apiResponse, HttpStatus.OK);
        }

        @ApiOperation(value = "Start application")
        @ApiResponses(value = {
                        @io.swagger.annotations.ApiResponse(code = 200, message = "Application started"),
                        @io.swagger.annotations.ApiResponse(code = 401, message = "Unauthorized", response = ApiResponse.class),
                        @io.swagger.annotations.ApiResponse(code = 404, message = "Application not found", response = ApiResponse.class),
                        @io.swagger.annotations.ApiResponse(code = 400, message = "Application can not be started", response = ApiResponse.class)
        })
        @PostMapping("/{appId}/start")
        public ResponseEntity<ApiResponse<ExecutionResponse>> startApp(
                        @PathVariable(name = "appId") Long appId,
                        @RequestBody ApplicationActionRequest request,
                        HttpServletRequest servletRequest) {
                String username = servletRequest.getAttribute("username").toString();
                request.setUsername(username);
                validationService.validateAppId(appId, request.getAppId());

                ExecutionResponse executionResponse = userApplicationService.startApp(request);
                ApiResponse<ExecutionResponse> apiResponse = ApiResponse.success(executionResponse,
                                "Application started",
                                HttpStatus.OK, null);

                return ResponseEntity.ok(apiResponse);
        }

        @ApiOperation(value = "Stop application")
        @ApiResponses(value = {
                        @io.swagger.annotations.ApiResponse(code = 200, message = "Application stopped"),
                        @io.swagger.annotations.ApiResponse(code = 401, message = "Unauthorized", response = ApiResponse.class),
                        @io.swagger.annotations.ApiResponse(code = 404, message = "Application not found", response = ApiResponse.class),
                        @io.swagger.annotations.ApiResponse(code = 400, message = "Application can not be stopped", response = ApiResponse.class)
        })
        @PostMapping("/{appId}/stop")
        public ResponseEntity<ApiResponse<ExecutionResponse>> stopApp(
                        @PathVariable(name = "appId") Long appId,
                        @RequestBody ApplicationActionRequest request,
                        HttpServletRequest servletRequest) {
                String username = servletRequest.getAttribute("username").toString();
                request.setUsername(username);
                validationService.validateAppId(appId, request.getAppId());

                ExecutionResponse executionResponse = userApplicationService.stopApp(request);
                ApiResponse<ExecutionResponse> apiResponse = ApiResponse.success(executionResponse,
                                "Application stopped",
                                HttpStatus.OK, null);

                return ResponseEntity.ok(apiResponse);
        }

        @ApiOperation(value = "Delete application")
        @ApiResponses(value = {
                        @io.swagger.annotations.ApiResponse(code = 200, message = "Application deleted"),
                        @io.swagger.annotations.ApiResponse(code = 401, message = "Unauthorized", response = ApiResponse.class),
                        @io.swagger.annotations.ApiResponse(code = 404, message = "Application not found", response = ApiResponse.class),
                        @io.swagger.annotations.ApiResponse(code = 400, message = "Application can not be deleted", response = ApiResponse.class)
        })
        @DeleteMapping("/{appId}/delete")
        public ResponseEntity<ApiResponse<ExecutionResponse>> deleteApp(
                        @PathVariable(name = "appId") Long appId,
                        @RequestBody ApplicationActionRequest request,
                        HttpServletRequest servletRequest) {
                String username = servletRequest.getAttribute("username").toString();
                request.setUsername(username);
                validationService.validateAppId(appId, request.getAppId());

                ExecutionResponse executionResponse = userApplicationService.deleteUserApplication(request);
                ApiResponse<ExecutionResponse> apiResponse = ApiResponse.success(executionResponse,
                                "Application Deleted",
                                HttpStatus.OK, null);

                return ResponseEntity.ok(apiResponse);
        }

        @ApiOperation(value = "Get all user applications")
        @ApiResponses(value = {
                        @io.swagger.annotations.ApiResponse(code = 200, message = "Applications found"),
                        @io.swagger.annotations.ApiResponse(code = 401, message = "Unauthorized", response = ApiResponse.class),
                        @io.swagger.annotations.ApiResponse(code = 404, message = "User not found", response = ApiResponse.class)
        })
        @GetMapping
        public ResponseEntity<ApiResponse<List<UserApplicationOut>>> getUserApplications(
                        HttpServletRequest servletRequest) {
                String username = servletRequest.getAttribute("username").toString();
                var allUserApplication = userApplicationService.getAllUserApplication(username);
                String responseMessage = allUserApplication.isEmpty() ? "No applications found" : "Applications found";

                ApiResponse<List<UserApplicationOut>> apiResponse = new ApiResponse<>(true, HttpStatus.OK,
                                allUserApplication,
                                responseMessage, null);

                return ResponseEntity.ok(apiResponse);
        }

        @ApiOperation(value = "Get application logs")
        @ApiResponses(value = {
                        @io.swagger.annotations.ApiResponse(code = 200, message = "Application logs found"),
                        @io.swagger.annotations.ApiResponse(code = 401, message = "Unauthorized", response = ApiResponse.class),
                        @io.swagger.annotations.ApiResponse(code = 404, message = "Application not found", response = ApiResponse.class)
        })
        @GetMapping("/{appId}/logs")
        public ResponseEntity<ApiResponse<String>> getAppLogs(@PathVariable(name = "appId") Long appId) {
                String applicationLogs = userApplicationService.getApplicationLogs(appId);

                ApiResponse<String> apiResponse = ApiResponse.success(applicationLogs, "Application logs found",
                                HttpStatus.OK,
                                null);
                return ResponseEntity.ok(apiResponse);
        }

        @ApiOperation(value = "Get application by name")
        @ApiResponses(value = {
                        @io.swagger.annotations.ApiResponse(code = 200, message = "Application found"),
                        @io.swagger.annotations.ApiResponse(code = 401, message = "Unauthorized", response = ApiResponse.class),
                        @io.swagger.annotations.ApiResponse(code = 404, message = "Application not found", response = ApiResponse.class)
        })
        @GetMapping("/byName")
        public ResponseEntity<ApiResponse<UserApplicationOut>> getApplicationByName(
                        @RequestParam String appName) {
                UserApplication application = userApplicationService.findByAppName(appName);
                UserApplicationOut userApplicationOut = userApplicationMapper.toUserApplicationOut(application);
                ApiResponse<UserApplicationOut> apiResponse = ApiResponse.success(userApplicationOut,
                                "Application found",
                                HttpStatus.OK, null);
                return new ResponseEntity<>(apiResponse, HttpStatus.OK);
        }

        @GetMapping("/logs/{appId}")
        public ResponseEntity<Resource> downloadAppLogs(@PathVariable(name = "appId") Long appId) {
                try {
                        byte[] logs = userApplicationService.getLogsForFile(appId);
                        ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(logs);
                        InputStreamResource resource = new InputStreamResource(byteArrayInputStream);

                        HttpHeaders headers = new HttpHeaders();
                        headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=application-logs.txt");

                        return ResponseEntity.ok()
                                        .headers(headers)
                                        .contentLength(logs.length)
                                        .contentType(MediaType.APPLICATION_OCTET_STREAM)
                                        .body(resource);
                } catch (InterruptedException e) {
                        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
                }
        }
}
