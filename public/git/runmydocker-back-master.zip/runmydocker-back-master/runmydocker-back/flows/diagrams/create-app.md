## Create App Flow

1. **User Request to Create App**
    - The user sends a request to create a new app.

2. **Find User by ID**
    - Locate the user using their ID.
    - **If user is not found:** Throw a `404 Not Found` error.

3. **Validate Create App Request**
    - **User App Limit Validation:**
        - Check if the user has reached their app limit.
        - **If the limit is reached:** Throw a `400 Bad Request` error.
    - **App Name Validation:**
        - Check if the app name already exists.
            - **If it exists:** Throw a `409 Conflict` error.
        - Check if the app name is valid.
            - **If invalid:** Throw a `400 Bad Request` error.
    - **Docker Image Validation:**
        - Verify if the image exists on Docker Hub.
            - **If the image does not exist:** Throw a `404 Not Found` error.

4. **Generate a Unique Port**
    - Generate a unique port number for the app.

5. **Create App Entity**
    - Create an app entity and save it to the database.

6. **Publish Event: `create-container-event`**
    - Publish an event to trigger the container creation asynchronously.

---

## Handling `create-container-event`

1. **Check If Docker Image Exists Locally**
    - If the image is not available locally:
        - Pull the image from Docker Hub asynchronously.
        - **If pull fails:**
            - Update the app status to `failed`.
        - **If pull succeeds:**
            - Update the app status to `creating`.

2. **Create Docker Container**
    - Attempt to create the Docker container.
    - **If container creation fails:**
        - Update the app status to `failed`.
    - **If container creation succeeds:**
        - Publish an event: `container-created-event`.
        - Update the app status to `pending` and set the container ID.

3. **Perform Container Health Check**
    - Start the app and check its health asynchronously:
        - Start the container.
        - Wait for **45 seconds**.
        - Check if the app is running:
            - **If the app is not running:**
                - Update the app status to `failed`.
                - Set the app's `running` flag to `false` and log an error message.
            - **If the app is running:**
                - Update the app status to `created`.
                - Set the app's `running` flag to `true`.




```plantuml
@startuml
title Create App Flow

start
:User Request to Create App;
:Find User by ID;
if (User Found?) then (true)
  :Validate Create App Request;
  :User App Limit Validation;
  if (Limit Reached?) then (true)
    :400 Bad Request;
    stop
  else (false)
    :App Name Validation;
    if (App Name Exists?) then (true)
      :409 Conflict;
      stop
    else (false)
      if (Invalid App Name?) then (true)
        :400 Bad Request;
        stop
      else (false)
        :Docker Image Validation;
        if (Image Not Found?) then (true)
          :404 Not Found;
          stop
        else (false)
          :Generate a Unique Port;
          :Create App Entity;
          :Publish Event: create-container-event;
          :Check If Docker Image Exists Locally;
          if (Image Not Local?) then (true)
            :Pull Image Asynchronously;
            if (Pull Failed?) then (true)
              :Update App Status to Failed;
              stop
            else (false)
              :Update App Status to Creating;
            endif
          endif
          :Create Docker Container;
          if (Container Creation Failed?) then (true)
            :Update App Status to Failed;
            stop
          else (false)
            :Publish Event: container-created-event;
            :Update App Status to Pending;
            :Perform Container Health Check;
            :Start Container;
            :Wait for 45 Seconds;
            :Check If App is Running;
            if (Not Running?) then (true)
              :Update Status to Failed;
              stop
            else (false)
              :Update Status to Created;
              stop
            endif
          endif
        endif
      endif
    endif
  endif
else (false)
  :404 Not Found;
  stop
endif

@enduml
```
