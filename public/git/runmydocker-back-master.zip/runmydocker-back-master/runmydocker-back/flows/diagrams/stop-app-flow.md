```plantuml
@startuml
title Stop app flow

start
:User requests to stop app;

if (Is App exists by id+name?) then (true)
  if (App is already stopped?) then (true)
    :Throw 400 (Bad Request);
    stop
  else (false)
    if (App status != CREATED ?) then (true)
      :Throw 400 (Bad Request);
      stop
    else (false)
      :Check if app has mapped container by app-name;
      if (No mapped container?) then (true)
        :Throw 404 (Not Found);
        stop
      else (false)
        if (Container is running?) then (true)
          :Stop the container;
          :Update app status to running=false;
          :Update DB: set running to false, update last time used to current time;
          :End with ExecutionResponse {message, action, status};
          stop
        else (false)
          :Throw 400 (Bad Request);
          stop
        endif
      endif
    endif
  endif
else (false)
  :Throw 404 (Not Found);
  stop
endif

@enduml
```