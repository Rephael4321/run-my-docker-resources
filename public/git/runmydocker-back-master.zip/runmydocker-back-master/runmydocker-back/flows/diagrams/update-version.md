``` plantuml
@startuml
title /{appId}/changeVersion Endpoint Flow

start
:Endpoint: /{appId}/changeVersion;
:Validate appId;

if (appId match with body) then (Yes)
  :changeVersion;
  :Find Application by appId and name;

  if (Application found?) then (Yes)
    :Check if Docker images are the same;
    if (Images are the same?) then (Yes)
      :400 Bad Request;
      stop
    else (No)
      :Check App Status;

      if (App Status: Failed?) then (Yes)
        :Update app with new version info
        (Docker image, container port);
        :Publish Event: create-container-event;
        :204 No Content;
        stop
      else (No)
        if (App Status: Running?) then (Yes)
          :400 Bad Request;
          stop
        else (No)
          :Update app with new version info
          (Docker image, container port);
          :Remove old Docker container;
          :Publish Event: container-removed-for-update-event;
          :Update app container ID to null;
          :Publish Event: create-container-event;
          :204 No Content;
          stop
        endif
      endif
    endif
  else (No)
    :404 Not Found;
    stop
  endif
else (No)
  :400 Bad Request;
  stop
endif

@enduml
```
