## Flows

### Update version flow

1. change version request`
2. validation if appId match with the body appId and path variable appId, if
   not `return 400 (Bad Request)`.
3. excute app-cmd - changeVersion:
    - find if app exist by appId and app name, if not `throw 404 (Not Found)`.
    - check if the docker images are the same, if yes throw `400 - (Bad request)`.
    - check if app is with `status: failed`, if yes:
      (in this case user app in db has no mapped container in docker)
        - update new version info(docker image, the container port).
        - publish event: `create-container-event`. This event will create a new
          container asynchrounously.
        - end the flow with `204 (no-content)`.
    - (in this case we have mapped container in docker)
    - check if app marked as running, if yes:
        - throw `400 - (Bad request)` with message `App is running, stop it first`.
        - end the flow.
    - update new version info(docker image, the container port).
    - remove the old docker container.
    - publish event: `container-removed-for-update-event`.
        - update the user app with container id as null.
        - publish event: `create-container-event`. This event will create a new
          container asynchrounously.
    - end the flow with `204 (no-content)`.

diagrampath: flows/diagrams/update-version.md

```plantuml
@startuml
title /{appId}/changeVersion Endpoint Flow

start
:Endpoint: /{appId}/changeVersion;
:Validate appId;

if (appId match with body) then (Yes)
  :Execute Command: app-cmd - changeVersion;
  :Find Application by appId and name;

  if (Application found?) then (Yes)
    :Check if Docker images are the same;
    if (Images are the same?) then (Yes)
      :400 Bad Request - Images are identical;
      stop
    else (No)
      :Check App Status;

      if (App Status: Failed?) then (Yes)
        :Update app with new version info
        (Docker image, container port);
        :Publish Event: create-container-event;
        :204 No Content;
        stop
      else (No)
        if (App Status: Running?) then (Yes)
          :400 Bad Request - App is running, stop it first;
          stop
        else (No)
          :Update app with new version info
          (Docker image, container port);
          :Remove old Docker container;
          :Publish Event: container-removed-for-update-event;
          :Update app container ID to null;
          :Publish Event: create-container-event;
          :204 No Content;
          stop
        endif
      endif
    endif
  else (No)
    :404 Not Found;
    stop
  endif
else (No)
  :400 Bad Request - appId mismatch;
  stop
endif

@enduml
```

## Start app flow

1. user request to start app.
2. find add by appId and app name, if not `throw 404 (Not Found)`.
3. if app has no reamaining time to run, `throw 400 (Bad Request)`.
4. if app is already running, `throw 400 (Bad Request)`.
5. if app status is not `created`, `throw 400 (Bad Request)`.
6. check if app has mapped container by `app-name`
    - if not: throw `404 (Not Found)`.
    - if yes:
      -chech container status, if container is not running:
        - start the container.
        - update app status to `running`.
        - update db:
            - set running to true.
            - update last time used to current time.
7. end with `ExecutionResponse {message, action, status}`.

```plantuml
@startuml
title Start app flow

start
:User requests to start app;

if (Is App exists by id+name?) then (Yes)
  :Check if app has remaining time to run;
  if (App has remaining time to run?) then (Yes)
    :Throw 400 (Bad Request);
    stop
  else (No)
    if (App is running?) then (Yes)
      :Throw 400 (Bad Request);
      stop
    else (No)
      if (App status != CREATED ?) then (Yes)
        :Throw 400 (Bad Request);
        stop
      else (No)
        :Check if app has mapped container by app-name;
        if (Container not found?) then (Yes)
          :Throw 404 (Not Found);
          stop
        else (No)
          if (Container is running?) then (No)
            :Start the container;
            :Update DB: set running to true, update last time used to current time;
            :End with 200 (OK);
            stop
          else (Yes)
            :Throw 400 (Bad Request);
            stop
          endif
        endif
      endif
    endif
  endif
else (No)
  :Throw 404 (Not Found);
  stop
endif

@enduml
```

## Stop app flow

1. user request to stop app.
2. find add by appId and app name, if not `throw 404 (Not Found)`.
3. if app is already stopped, `throw 400 (Bad Request)`.
4. if app status is not `created`, `throw 400 (Bad Request)`.
5. check if app has mapped container by `app-name`
    - if not: throw `404 (Not Found)`.
    - if yes:
      -chech container status, if container is running:
        - stop the container.
        - update app status to `running=false`.
        - update db:
            - set running to false.
            - update last time used to current time.
6. end with `ExecutionResponse {message, action, status}`.

```plantuml
@startuml
title Stop app flow

start
:User requests to stop app;

if (Is App exists by id+name?) then (true)
  if (App is already stopped?) then (true)
    :Throw 400 (Bad Request);
    stop
  else (false)
    if (App status != CREATED ?) then (true)
      :Throw 400 (Bad Request);
      stop
    else (false)
      :Check if app has mapped container by app-name;
      if (No mapped container?) then (true)
        :Throw 404 (Not Found);
        stop
      else (false)
        if (Container is running?) then (true)
          :Stop the container;
          :Update app status to running=false;
          :Update DB: set running to false, update last time used to current time;
          :End with ExecutionResponse {message, action, status};
          stop
        else (false)
          :Throw 400 (Bad Request);
          stop
        endif
      endif
    endif
  endif
else (false)
  :Throw 404 (Not Found);
  stop
endif

@enduml
```

## Delete app flow

1. find app by appId and app name, if not `throw 404 (Not Found)`.
2. check if app is with failed status, if yes:
    - delete app from db.
3. if app is not with failed status:
    - find app by appId and app name, if not `throw 404 (Not Found)`.
    - check if app status different from `created`, if yes:
        - throw `400 (Bad Request)`.
          check if app marked as running, if yes:
        - throw `400 (Bad Request)` with message.
    - check if app has mapped container by `app-name`
    - if not: throw `404 (Not Found)`.
    - if yes:
        - validate container is not running:
        - not running:
            - remove the container.
            - delete app from db.
            - running:
            - throw `400 (Bad Request)`

```plantuml
@startuml
title Delete app flow

start
:Find app by appId and app name;

if (App found?) then (true)
  :Check if app status is FAILED;
  if (App status is FAILED?) then (true)
    :Delete app from DB;
    stop
  else (false)
    :Check if app status is CREATED;
    if (App status is not CREATED?) then (true)
      :Throw 400 (Bad Request);
      stop
    else (false)
      :Check if app is running;
      if (App is running?) then (true)
        :Throw 400 (Bad Request);
        stop
      else (false)
        :Check if app has mapped container by app-name;
        if (Container found?) then (true)
          :Validate container is not running;
          if (Container is running?) then (true)
            :Throw 400 (Bad Request);
            stop
          else (false)
            :Remove the container;
            :Delete app from DB;
            stop
          endif
        else (false)
          :Throw 404 (Not Found);
          stop
        endif
      endif
    endif
  endif
else (false)
  :Throw 404 (Not Found);
  stop
endif

@enduml
```

## register regular user flow

1. user request to register.
2. validate user not exist by email:
    - if exist: throw `409 (Bad Request)`.
3. convert user data to user entity.
4. hash user password.
5. save user to db.
6. create activation code.
7. add activation code to user entity. (update user in db);
8. trigger event `user-registered-event`.
   8.1. send sms with activation code.
9. return response with user and uuid

```plantuml
@startuml
title Register Regular User Flow

start
:User requests to register;

:Validate user does not exist by email;
if (User exists?) then (true)
  :Throw 409 (Bad Request);
  stop
else (false)
  :Convert user data to user entity;
  :set setRegistrationCompleted to true;
  :Hash user password;
  :Save user to DB;
  :Create activation code;
  :Add activation code to user entity;
  :Update user in DB;
  :Trigger event: user-registered-event;
  :Send SMS with activation code;
  :Return created(201) with user and uuid;
  stop
endif

@enduml
```

## activate user flow

1. find user by email. if not `throw 404 (Not Found)`.
2. check if user is already activated, if yes:
    - throw `500 (General Error)`.
3. search for activation code by user id code and uuid:
    - if not found: throw `404 (Not Found)`.
    - if found:
        - check if code is expired or used:
            - throw `400 (Bad Request)`.
            - if yes:
                - throw `500 (General Error)`.
                  if not:
                - update user (activateed = true).
                - update activation code (used = true).
                - update user in db -> will update user and activation code.
                  return `200(ok)` response {message, username, jwtToken}.

```plantuml
@startuml
title Activate User Flow

start
:Find user by email;

if (User found?) then (true)
  :Check if user is already activated;
  if (User is activated?) then (true)
    :Throw 500 (General Error);
    stop
  else (false)
    :Search for activation code by user id, code, and uuid;
    if (Activation code found?) then (true)
      :Check if code is expired or used;
      if (Code is expired or used?) then (true)
        :Throw 400 (Bad Request);
        stop
      else (false)
        :Update user (activated = true);
        :Update activation code (used = true);
        :Update user in DB;
        :Return 200 (OK) response {message, username, jwtToken};
        stop
      endif
    else (false)
      :Throw 404 (Not Found);
      stop
    endif
  endif
else (false)
  :Throw 404 (Not Found);
  stop
endif

@enduml
```

## resend activation code flow

1. find user by email. if not `throw 404 (Not Found)`.
2. create activation code and add it to user.
3. send sms with activation code.
4. return OK response with user and uuid

```plantuml
@startuml
title Resend Activation Code Flow

start
:Find user by email;

if (User found?) then (true)
  :Create activation code;
  :Add activation code to user;
  :Send SMS with activation code;
  :Return OK response with user and UUID;
  stop
else (false)
  :Throw 404 (Not Found);
  stop
endif

@enduml
```

## complete registration flow

1. user request to complete registration.
2. check if user id in request is the same as the user id in path variable.
3. if not: throw `500 (General Error)`.
4. find user by id.
    - if not: throw `404 (Not Found)`.
    - if found:
        - updateUser(registrationCompleted = true, lastname, firstname, phone).
5. publish event `user-registered-event`(will send sms with activation code).
6. return OK response with user and uuid.

```plantuml
@startuml
title Complete Registration Flow

start
:User requests to complete registration;

:Check if user id in request is the same as the user id in path variable;
if (User id matches?) then (true)
  :Find user by id;
  if (User found?) then (true)
    :Update user (registrationCompleted = true, lastname, firstname, phone);
    :Publish event: user-registered-event;
    note right
  sends SMS with activation code
end note
    :Return OK response with user and UUID;
    stop
  else (false)
    :Throw 404 (Not Found);
    stop
  endif
else (false)
  :Throw 500 (General Error);
  note right
needs to be 403 Forbidden
end note
  stop
endif

@enduml
```




## Create App Flow

1. **User Request to Create App**
    - The user sends a request to create a new app.

2. **Find User by ID**
    - Locate the user using their ID.
    - **If user is not found:** Throw a `404 Not Found` error.

3. **Validate Create App Request**
    - **User App Limit Validation:**
        - Check if the user has reached their app limit.
        - **If the limit is reached:** Throw a `400 Bad Request` error.
    - **App Name Validation:**
        - Check if the app name already exists.
            - **If it exists:** Throw a `409 Conflict` error.
        - Check if the app name is valid.
            - **If invalid:** Throw a `400 Bad Request` error.
    - **Docker Image Validation:**
        - Verify if the image exists on Docker Hub.
            - **If the image does not exist:** Throw a `404 Not Found` error.

4. **Generate a Unique Port**
    - Generate a unique port number for the app.

5. **Create App Entity**
    - Create an app entity and save it to the database.

6. **Publish Event: `create-container-event`**
    - Publish an event to trigger the container creation asynchronously.

---

## Handling `create-container-event`

1. **Check If Docker Image Exists Locally**
    - If the image is not available locally:
        - Pull the image from Docker Hub asynchronously.
        - **If pull fails:**
            - Update the app status to `failed`.
        - **If pull succeeds:**
            - Update the app status to `creating`.

2. **Create Docker Container**
    - Attempt to create the Docker container.
    - **If container creation fails:**
        - Update the app status to `failed`.
    - **If container creation succeeds:**
        - Publish an event: `container-created-event`.
        - Update the app status to `pending` and set the container ID.

3. **Perform Container Health Check**
    - Start the app and check its health asynchronously:
        - Start the container.
        - Wait for **45 seconds**.
        - Check if the app is running:
            - **If the app is not running:**
                - Update the app status to `failed`.
                - Set the app's `running` flag to `false` and log an error message.
            - **If the app is running:**
                - Update the app status to `created`.
                - Set the app's `running` flag to `true`.
  
 
    

```plantuml
@startuml
title Create App Flow

start
:User Request to Create App;
:Find User by ID;
if (User Found?) then (true)
  :Validate Create App Request;
  :User App Limit Validation;
  if (Limit Reached?) then (true)
    :400 Bad Request;
    stop
  else (false)
    :App Name Validation;
    if (App Name Exists?) then (true)
      :409 Conflict;
      stop
    else (false)
      if (Invalid App Name?) then (true)
        :400 Bad Request;
        stop
      else (false)
        :Docker Image Validation;
        if (Image Not Found?) then (true)
          :404 Not Found;
          stop
        else (false)
          :Generate a Unique Port;
          :Create App Entity;
          :Publish Event: create-container-event;
          :Check If Docker Image Exists Locally;
          if (Image Not Local?) then (true)
            :Pull Image Asynchronously;
            if (Pull Failed?) then (true)
              :Update App Status to Failed;
              stop
            else (false)
              :Update App Status to Creating;
            endif
          endif
          :Create Docker Container;
          if (Container Creation Failed?) then (true)
            :Update App Status to Failed;
            stop
          else (false)
            :Publish Event: container-created-event;
            :Update App Status to Pending;
            :Perform Container Health Check;
            :Start Container;
            :Wait for 45 Seconds;
            :Check If App is Running;
            if (Not Running?) then (true)
              :Update Status to Failed;
              stop
            else (false)
              :Update Status to Created;
              stop
            endif
          endif
        endif
      endif
    endif
  endif
else (false)
  :404 Not Found;
  stop
endif

@enduml
```

