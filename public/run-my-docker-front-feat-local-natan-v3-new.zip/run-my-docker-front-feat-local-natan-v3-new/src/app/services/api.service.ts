import {Injectable} from '@angular/core';
import {environment} from '../../environments/environment';
import {HttpClient} from '@angular/common/http';
import {firstValueFrom, map} from 'rxjs';
import {AppStausChangeRequest, IAppContainerRequest, IAppContainerResponse} from '../interfaces/AppContainer';
import {GetUserAppsApiResponse, UserApp} from "../interfaces/v3/user-applications.interface";
import {BaseApiResponse} from "../interfaces/v3/base-api.interface";

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  serverURL = environment.serverURL;

  ENDPOINTS = {
    // deleteApp: "/api/userApplication/deleteApp",
    // getAllUserApps: "/api/userApplication/getUserApplications",
    // // getApp: "/api/userApplication/getApp",
    // getContainerLogs: "/api/userApplication/{appId}/getAppLogs",
    // createNewContainer: "/api/userApplication/newApp",
    // startApp: "/api/userApplication/startApp",
    // stopApp: "/api/userApplication/stopApp",
    // updateAppContainer: '/api/userApplication/{appId}/changeImage'
    deleteApp: "/api/userApplications/{appId}/delete",
    getAllUserApps: "/api/userApplications",
    getAppByAppName: "/api/userApplications/byName?appName={appName}",
    getContainerLogs: "/api/userApplications/{appId}/logs",
    downloadLogs: "/api/userApplications/logs/{appId}",
    createNewContainer: "/api/userApplications/create",
    startApp: "/api/userApplications/{appId}/start",
    stopApp: "/api/userApplications/{appId}/stop",
    updateAppContainer: '/api/userApplications/{appId}/changeImage'
  }

  constructor(private httpClient: HttpClient) {
  }

  getAllUserApps = async () => {
    const URL = this.serverURL + this.ENDPOINTS.getAllUserApps;
    const apps = await firstValueFrom(
      this.httpClient.get<GetUserAppsApiResponse>(URL)
        .pipe(map(res => res.data))
    )

    return apps;
  }

  getApp = async (appName: string) => {
    const URL = this.serverURL + this.ENDPOINTS.getAppByAppName.replace('{appName}', appName);
    const app = await firstValueFrom(this.httpClient.get<BaseApiResponse<UserApp>>(URL)
      .pipe(map(res => res.data)))
    return app;
  }

  getContainerLogs = async (appId: number) => {
    const URL = this.serverURL + this.ENDPOINTS.getContainerLogs.replace('{appId}', appId.toString());
    const response = await firstValueFrom(this.httpClient.get<BaseApiResponse<string>>(URL, {responseType: 'json'}))
    return response.data;

  }

  createNewAppContainer = async (newApp: IAppContainerRequest) => {
    const URL = this.serverURL + this.ENDPOINTS.createNewContainer;
    const res = await firstValueFrom(this.httpClient.post(URL, newApp))
  }

  updateAppContainer = async (updatedApp: { appId: number, dockerImage: string, mappingPort: string }) => {
    const URL = this.serverURL + this.ENDPOINTS.updateAppContainer.replace('{appId}', updatedApp.appId.toString());
    const res = await firstValueFrom(this.httpClient.put<IAppContainerResponse>(URL, updatedApp))
    return res;
  }

  startApp = async (app: AppStausChangeRequest) => {
    const URL = this.serverURL + this.ENDPOINTS.startApp.replace('{appId}', app.appId.toString());
    const res = await firstValueFrom(this.httpClient.post(URL, app))
  }

  stopApp = async (app: AppStausChangeRequest) => {
    const URL = this.serverURL + this.ENDPOINTS.stopApp.replace('{appId}', app.appId.toString());
    const res = await firstValueFrom(this.httpClient.post(URL, app))
  }

  deleteApp = async (appToDelete: { appName: string, appId: number }) => {
    const URL = this.serverURL + this.ENDPOINTS.deleteApp.replace('{appId}', appToDelete.appId.toString());
    await firstValueFrom(this.httpClient.delete(URL, {body: appToDelete}))
  }


  downloadLogs = async (appId: number) => {
    const URL = this.serverURL + this.ENDPOINTS.downloadLogs.replace('{appId}', appId.toString());
    const res =   await firstValueFrom(this.httpClient.get(URL, {responseType: 'blob', observe: 'response'}))
    return res.body;

  }


}
