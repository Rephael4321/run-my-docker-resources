import {HttpClient} from '@angular/common/http';
import {Injectable} from '@angular/core';
import {environment} from '../../environments/environment';
import {UserCredentials} from '../interfaces/UserCredentials';
import {BehaviorSubject, firstValueFrom, tap} from 'rxjs';
import {
  IForgotPasswordResponse,
  ISocialRegistration,
  IRegistrationResponse,
  IUserProfileRequest,
  IUserProfileResponse
} from '../interfaces/UserProfile';
import {storageService} from '../utils/localStorageHelper';
import {ActivationApiResponse, LoginApiResponse, RegistrationApiResponse} from "../interfaces/v3/auth.interface";
import {GetUserApiResponse, User} from "../interfaces/v3/user.interface";
import {BaseApiResponse} from "../interfaces/v3/base-api.interface";


@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private serverURL = environment.serverURL;

  private ENDPOINTS = {
    activateUser: "/api/auth/activate",
    login: "/api/auth/login",
    register: "/api/auth/register",
    completeGithubRegistration: "/api/auth/completeRegistration/",
    resendCode: "/api/auth/resendCode",
    forgotPassword: "/api/auth/forgotPassword",
    changePassword: "/api/auth/changePassword",
    getUser: "/api/users/getUser",
    deleteUser: "/api/users/deleteUser/",
    resetPassword: "/api/users/resetPassword",
    changePasswordFromProfile: "/api/users/changePassword",


  }

  private unactivatedUser: User | null = null;

  private user = new BehaviorSubject<User | null>(null);

  get $user() {
    return this.user.asObservable();
  }

  constructor(private httpClient: HttpClient) {
  }

  logout = async () => {
    storageService.deleteAll();
    this.user.next(null);
  }

  login = async (userCredentials: UserCredentials) => {
    const URL = this.serverURL + this.ENDPOINTS.login;
    const res = await firstValueFrom(this.httpClient.post<LoginApiResponse>(URL, userCredentials));
    storageService.set("token", res.data.jwtToken);
    storageService.set("username", userCredentials.username);
    await this.getUser();
  }

  forgotPassword = async (username: string) => {
    const param = `?username=${username}`;
    const URL = this.serverURL + this.ENDPOINTS.forgotPassword + param;
    const res = await firstValueFrom(this.httpClient.get<BaseApiResponse<{ uuid: string }>>(URL));
    // storageService.set("code", res.code);
    storageService.set("uuidToken", res.data.uuid);
    storageService.set("username", username);
  }

  setNewPassword = async (newPassword: string, code: string) => {
    const username = storageService.get('username');
    const uuid = storageService.get('uuidToken');
    const reqBody = {password: newPassword, code, username, uuid}
    const URL = this.serverURL + this.ENDPOINTS.changePassword;
    await firstValueFrom(this.httpClient.put<BaseApiResponse<null>>(URL, reqBody));
  }

  register = async (userRequest: IUserProfileRequest) => {
    console.log("[register] userRequest", userRequest);
    const URL = this.serverURL + this.ENDPOINTS.register;
    const {data: {uuid, user}} = await firstValueFrom(this.httpClient.post<RegistrationApiResponse>(URL, userRequest));

    storageService.set('uuid', uuid);
    storageService.set('username', user.username);
    this.unactivatedUser = user;
  }

  completeSocialRegistration = async (userRequest: ISocialRegistration) => {
    const URL = `${this.serverURL}${this.ENDPOINTS.completeGithubRegistration}${userRequest.id}`;
    const {data: {uuid, user}} = await firstValueFrom(this.httpClient.put<RegistrationApiResponse>(URL, userRequest));

    storageService.set('uuid', uuid);
    storageService.set('username', user.username);
    this.unactivatedUser = user;
  }

  getUser = async () => {
    const URL = this.serverURL + this.ENDPOINTS.getUser;
    const {data: user} = await firstValueFrom(this.httpClient.get<GetUserApiResponse>(URL))
    this.user.next(user);
  }

  deleteUser = async () => {
    const userId = this.user.value ? this.user.value.id : 0;
    const URL = this.serverURL + this.ENDPOINTS.deleteUser + userId;
    await firstValueFrom(this.httpClient.delete(URL))
  }

  activateUser = async (code: string) => {
    const uuid = storageService.get("uuid");
    const username = storageService.get("username");
    const param = `?username=${username}`;
    const URL = this.serverURL + this.ENDPOINTS.activateUser + param;
    const res = await firstValueFrom(this.httpClient.put<ActivationApiResponse>(URL, {code, uuid, username}))
    storageService.deleteAll();
    storageService.set('token', res.data.jwtToken);
    this.user.next(this.unactivatedUser);
    this.unactivatedUser = null;
  }

  resendCode = async () => {
    const username = storageService.get('username');
    const param = `?username=${username}`;
    const URL = this.serverURL + this.ENDPOINTS.resendCode;
    const {data: response} = await firstValueFrom(this.httpClient.get<RegistrationApiResponse>(URL + param))
    storageService.set('uuid', response.uuid);
  }

  resetPassword = async (password: string) => {
    const URL = this.serverURL + this.ENDPOINTS.changePasswordFromProfile;
    await firstValueFrom(this.httpClient.put(URL, {password}))
  }


}
