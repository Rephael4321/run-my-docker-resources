import { environment } from "../../environments/environment";

let key: CryptoKey | null = null;


export async function encryptData(data: any): Promise<number[]> {

  if(!key) key = await generateKey();

  const encoder = new TextEncoder();
  const dataBuffer = encoder.encode(JSON.stringify(data));

  try {
    const encryptedData = await crypto.subtle.encrypt({ name: 'AES-GCM', iv: crypto.getRandomValues(new Uint8Array(12)) }, key, dataBuffer);
    const encryptedArray = new Uint8Array(encryptedData);
    return Array.from(encryptedArray);
  } catch (error) {
    console.error('Error encrypting data:', error);
    throw error;
  }
}

export async function decryptData(encryptedData: number[] ): Promise<any> {

  if(!key) key = await generateKey();

  const encryptedArray = new Uint8Array(encryptedData);

  try {
    const decryptedData = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: encryptedArray.slice(0, 12) }, key, encryptedArray.slice(12));
    const decoder = new TextDecoder();
    return JSON.parse(decoder.decode(decryptedData));
  } catch (error) {
    console.error('Error decrypting data:', error);
    throw error;
  }
}


const generateKey = async (): Promise<CryptoKey> => {
  const secretKeyHex = environment.encryptionSecretKey as string;
  const secretKeyBytes = new TextEncoder().encode(secretKeyHex);
  return await crypto.subtle.importKey('raw', secretKeyBytes, { name: 'AES-GCM' }, false, ['encrypt', 'decrypt']);
}
