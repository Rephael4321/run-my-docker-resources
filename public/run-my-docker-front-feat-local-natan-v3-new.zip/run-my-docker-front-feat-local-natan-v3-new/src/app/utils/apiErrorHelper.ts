import {ApiErrorResponse} from "../interfaces/v3/base-api.interface";


export const apiErrorHelper = (err: ApiErrorResponse) => {
  console.log("Error is: ", err);
  if (err.code === 401) {
    return "Invalid username or password";
  }
  return err.message;
}
