export const logs = `
(  .   ____          _            __ _ _
) /\\ / ___'_ __ _ _(_)_ __  __ _ \\ \\ \\ \\
*( ( )\\___ | '_ | '_| | '_ \\/ _\` | \\ \\ \\ \\
+ \\/  ___)| |_)| | | | | || (_| |  ) ) ) )
*  '  |____| .__|_| |_|_| |\\__, | / / / /
) ==========|_|==============|___/=/_/_/_/
+ :: Spring Boot ::                (v2.5.2)

�2023-12-26 10:14:58.598  INFO 1 --- [           main] com.handson.chatbot.ChatbotApplication   : Starting ChatbotApplication v0.0.1-SNAPSHOT using Java 11.0.13 on 0d525eb65a68 with PID 1 (/usr/src/chatbot.jar started by root in /)
�2023-12-26 10:14:58.600  INFO 1 --- [           main] com.handson.chatbot.ChatbotApplication   : No active profile set, falling back to default profiles: default
�2023-12-26 10:14:59.470  INFO 1 --- [           main] o.s.b.w.embedded.tomcat.TomcatWebServer  : Tomcat initialized with port(s): 8081 (http)
{2023-12-26 10:14:59.478  INFO 1 --- [           main] o.apache.catalina.core.StandardService   : Starting service [Tomcat]
�2023-12-26 10:14:59.479  INFO 1 --- [           main] org.apache.catalina.core.StandardEngine  : Starting Servlet engine: [Apache Tomcat/9.0.48]
�2023-12-26 10:14:59.520  INFO 1 --- [           main] o.a.c.c.C.[Tomcat].[localhost].[/]       : Initializing Spring embedded WebApplicationContext
�2023-12-26 10:14:59.521  INFO 1 --- [           main] w.s.c.ServletWebServerApplicationContext : Root WebApplicationContext: initialization completed in 875 ms
�2023-12-26 10:15:00.155  INFO 1 --- [           main] o.s.b.w.embedded.tomcat.TomcatWebServer  : Tomcat started on port(s): 8081 (http) with context path ''
s2023-12-26 10:15:00.156  INFO 1 --- [           main] d.s.w.p.DocumentationPluginsBootstrapper : Context refreshed
�2023-12-26 10:15:00.186  INFO 1 --- [           main] d.s.w.p.DocumentationPluginsBootstrapper : Found 1 custom documentation plugin(s)
�2023-12-26 10:15:00.205  INFO 1 --- [           main] s.d.s.w.s.ApiListingReferenceScanner     : Scanning for api listing references
�2023-12-26 10:15:00.360  INFO 1 --- [           main] com.handson.chatbot.ChatbotApplication   : Started ChatbotApplication in 2.101 seconds (JVM running for 2.4)
�2023-12-26 10:15:03.371  INFO 1 --- [nio-8081-exec-1] o.a.c.c.C.[Tomcat].[localhost].[/]       : Initializing Spring DispatcherServlet 'dispatcherServlet'
�2023-12-26 10:15:03.371  INFO 1 --- [nio-8081-exec-1] o.s.web.servlet.DispatcherServlet        : Initializing Servlet 'dispatcherServlet'
�2023-12-26 10:15:03.372  INFO 1 --- [nio-8081-exec-1] o.s.web.servlet.DispatcherServlet        : Completed initialization in 1 ms

(  .   ____          _            __ _ _
) /\\ / ___'_ __ _ _(_)_ __  __ _ \\ \\ \\ \\
*( ( )\\___ | '_ | '_| | '_ \\/ _\` | \\ \\ \\ \\
+ \\/  ___)| |_)| | | | | || (_| |  ) ) ) )
*  '  |____| .__|_| |_|_| |\\__, | / / / /
) ==========|_|==============|___/=/_/_/_/
+ :: Spring Boot ::                (v2.5.2)

�2023-12-27 07:08:01.134  INFO 1 --- [           main] com.handson.chatbot.ChatbotApplication   : Starting ChatbotApplication v0.0.1-SNAPSHOT using Java 11.0.13 on 0d525eb65a68 with PID 1 (/usr/src/chatbot.jar started by root in /)
�2023-12-27 07:08:01.136  INFO 1 --- [           main] com.handson.chatbot.ChatbotApplication   : No active profile set, falling back to default profiles: default
�2023-12-27 07:08:02.025  INFO 1 --- [           main] o.s.b.w.embedded.tomcat.TomcatWebServer  : Tomcat initialized with port(s): 8081 (http)
{2023-12-27 07:08:02.033  INFO 1 --- [           main] o.apache.catalina.core.StandardService   : Starting service [Tomcat]
�2023-12-27 07:08:02.034  INFO 1 --- [           main] org.apache.catalina.core.StandardEngine  : Starting Servlet engine: [Apache Tomcat/9.0.48]
�2023-12-27 07:08:02.078  INFO 1 --- [           main] o.a.c.c.C.[Tomcat].[localhost].[/]       : Initializing Spring embedded WebApplicationContext
�2023-12-27 07:08:02.078  INFO 1 --- [           main] w.s.c.ServletWebServerApplicationContext : Root WebApplicationContext: initialization completed in 899 ms
�2023-12-27 07:08:02.689  INFO 1 --- [           main] o.s.b.w.embedded.tomcat.TomcatWebServer  : Tomcat started on port(s): 8081 (http) with context path ''
s2023-12-27 07:08:02.690  INFO 1 --- [           main] d.s.w.p.DocumentationPluginsBootstrapper : Context refreshed
�2023-12-27 07:08:02.724  INFO 1 --- [           main] d.s.w.p.DocumentationPluginsBootstrapper : Found 1 custom documentation plugin(s)
�2023-12-27 07:08:02.738  INFO 1 --- [           main] s.d.s.w.s.ApiListingReferenceScanner     : Scanning for api listing references
�2023-12-27 07:08:02.892  INFO 1 --- [           main] com.handson.chatbot.ChatbotApplication   : Started ChatbotApplication in 2.105 seconds (JVM running for 2.412)
�2023-12-27 07:08:30.553  INFO 1 --- [nio-8081-exec-4] o.a.c.c.C.[Tomcat].[localhost].[/]       : Initializing Spring DispatcherServlet 'dispatcherServlet'
�2023-12-27 07:08:30.553  INFO 1 --- [nio-8081-exec-4] o.s.web.servlet.DispatcherServlet        : Initializing Servlet 'dispatcherServlet'
�2023-12-27 07:08:30.554  INFO 1 --- [nio-8081-exec-4] o.s.web.servlet.DispatcherServlet        : Completed initialization in 1 ms

(  .   ____          _            __ _ _
) /\\ / ___'_ __ _ _(_)_ __  __ _ \\ \\ \\ \\
*( ( )\\___ | '_ | '_| | '_ \\/ _\` | \\ \\ \\ \\
+ \\/  ___)| |_)| | | | | || (_| |  ) ) ) )
*  '  |____| .__|_| |_|_| |\\__, | / / / /
) ==========|_|==============|___/=/_/_/_/
+ :: Spring Boot ::                (v2.5.2)

�2023-12-27 11:39:18.655  INFO 1 --- [           main] com.handson.chatbot.ChatbotApplication   : Starting ChatbotApplication v0.0.1-SNAPSHOT using Java 11.0.13 on 0d525eb65a68 with PID 1 (/usr/src/chatbot.jar started by root in /)
�2023-12-27 11:39:18.657  INFO 1 --- [           main] com.handson.chatbot.ChatbotApplication   : No active profile set, falling back to default profiles: default
�2023-12-27 11:39:19.510  INFO 1 --- [           main] o.s.b.w.embedded.tomcat.TomcatWebServer  : Tomcat initialized with port(s): 8081 (http)
{2023-12-27 11:39:19.518  INFO 1 --- [           main] o.apache.catalina.core.StandardService   : Starting service [Tomcat]
�2023-12-27 11:39:19.519  INFO 1 --- [           main] org.apache.catalina.core.StandardEngine  : Starting Servlet engine: [Apache Tomcat/9.0.48]
�2023-12-27 11:39:19.561  INFO 1 --- [           main] o.a.c.c.C.[Tomcat].[localhost].[/]       : Initializing Spring embedded WebApplicationContext
�2023-12-27 11:39:19.562  INFO 1 --- [           main] w.s.c.ServletWebServerApplicationContext : Root WebApplicationContext: initialization completed in 853 ms
�2023-12-27 11:39:20.177  INFO 1 --- [           main] o.s.b.w.embedded.tomcat.TomcatWebServer  : Tomcat started on port(s): 8081 (http) with context path ''
s2023-12-27 11:39:20.178  INFO 1 --- [           main] d.s.w.p.DocumentationPluginsBootstrapper : Context refreshed
�2023-12-27 11:39:20.190  INFO 1 --- [           main] d.s.w.p.DocumentationPluginsBootstrapper : Found 1 custom documentation plugin(s)
�2023-12-27 11:39:20.228  INFO 1 --- [           main] s.d.s.w.s.ApiListingReferenceScanner     : Scanning for api listing references
�2023-12-27 11:39:20.364  INFO 1 --- [           main] com.handson.chatbot.ChatbotApplication   : Started ChatbotApplication in 2.063 seconds (JVM running for 2.357)
�2023-12-27 11:39:22.903  INFO 1 --- [nio-8081-exec-1] o.a.c.c.C.[Tomcat].[localhost].[/]       : Initializing Spring DispatcherServlet 'dispatcherServlet'
�2023-12-27 11:39:22.904  INFO 1 --- [nio-8081-exec-1] o.s.web.servlet.DispatcherServlet        : Initializing Servlet 'dispatcherServlet'
�2023-12-27 11:39:22.904  INFO 1 --- [nio-8081-exec-1] o.s.web.servlet.DispatcherServlet        : Completed initialization in 0 ms

(  .   ____          _            __ _ _
) /\\ / ___'_ __ _ _(_)_ __  __ _ \\ \\ \\ \\
*( ( )\\___ | '_ | '_| | '_ \\/ _\` | \\ \\ \\ \\
+ \\/  ___)| |_)| | | | | || (_| |  ) ) ) )
*  '  |____| .__|_| |_|_| |\\__, | / / / /
) ==========|_|==============|___/=/_/_/_/
+ :: Spring Boot ::                (v2.5.2)

�2024-01-01 14:52:01.485  INFO 1 --- [           main] com.handson.chatbot.ChatbotApplication   : Starting ChatbotApplication v0.0.1-SNAPSHOT using Java 11.0.13 on 0d525eb65a68 with PID 1 (/usr/src/chatbot.jar started by root in /)
�2024-01-01 14:52:01.489  INFO 1 --- [           main] com.handson.chatbot.ChatbotApplication   : No active profile set, falling back to default profiles: default
�2024-01-01 14:52:02.389  INFO 1 --- [           main] o.s.b.w.embedded.tomcat.TomcatWebServer  : Tomcat initialized with port(s): 8081 (http)
{2024-01-01 14:52:02.398  INFO 1 --- [           main] o.apache.catalina.core.StandardService   : Starting service [Tomcat]
�2024-01-01 14:52:02.399  INFO 1 --- [           main] org.apache.catalina.core.StandardEngine  : Starting Servlet engine: [Apache Tomcat/9.0.48]
�2024-01-01 14:52:02.`

