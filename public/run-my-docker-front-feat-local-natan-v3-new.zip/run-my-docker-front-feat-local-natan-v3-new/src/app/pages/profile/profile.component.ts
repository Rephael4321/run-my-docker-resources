import {Component, OnDestroy, OnInit} from '@angular/core';
import {AuthService} from '../../services/auth.service';
import {IUserProfileResponse, IUserUpdateRequest} from '../../interfaces/UserProfile';
import {Subscription} from 'rxjs';
import {CommonModule} from '@angular/common';
import {ButtonComponent} from '../../components/button/button.component';
import {FormBuilder, FormGroup, ReactiveFormsModule, Validators} from '@angular/forms';
import {REGEX} from '../../utils/regex';
import {BackBtnComponent} from '../../components/back-btn/back-btn.component';
import {SuccessAlertComponent} from '../../components/success-alert/success-alert.component';
import {ErrorAlertComponent} from '../../components/error-alert/error-alert.component';
import {RouterLink} from '@angular/router';
import {User} from "../../interfaces/v3/user.interface";

@Component({
  selector: 'app-profile',
  standalone: true,
  imports: [
    BackBtnComponent,
    CommonModule,
    ButtonComponent,
    ReactiveFormsModule,
    SuccessAlertComponent,
    ErrorAlertComponent,
    RouterLink
  ],
  templateUrl: './profile.component.html',
  styleUrl: './profile.component.scss'
})
export class ProfileComponent implements OnInit, OnDestroy {

  user: User | null = null;
  userSub!: Subscription;
  updateForm!: FormGroup;
  successMessage = '';
  errorMessage = '';
  isLoading = false;

  formFields = [
    {
      label: "Change password:",
      defaultValue: "",
      type: "text",
      name: "password"
    },
    {
      label: "Confirm password:",
      defaultValue: "",
      type: "text",
      name: "confirmPassword"
    }
  ]

  constructor(private authService: AuthService,
              private fb: FormBuilder) {
  }

  ngOnInit(): void {
    this.userSub = this.authService.$user.subscribe(user => {
      this.user = user;
      this.setInitForm()
    })
  }

  setInitForm() {

    const phone = this.globalPhoneToNormal(this.user?.phone);

    let nnfb = this.fb.nonNullable;

    this.updateForm = nnfb.group({
      password: ["", [
        Validators.required,
        Validators.minLength(5),
      ]],
      confirmPassword: ["", [
        Validators.required,
        Validators.minLength(5),
      ]],
    })
  }

  globalPhoneToNormal(globalPhone: string | undefined) {
    if (globalPhone) return '0' + globalPhone.slice(5);
    return '';
  }


  async handleSaveChanges() {

    if (this.updateForm.invalid) return;

    const {password, confirmPassword} = this.updateForm.value;

    if (password !== confirmPassword) {
      this.errorMessage = 'Passwords dont match';
      return;
    }

    this.errorMessage = '';
    this.successMessage = '';
    this.isLoading = true;

    try {

      await this.authService.resetPassword(password);

      this.successMessage = 'Your details upadated successfully!'

    } catch (err:any) {
      const { error} = err;
      if (error.message) {
        this.errorMessage = error.message;
      } else {
        this.errorMessage = 'Oops... Your details couldn\'t be updated at the moment.'
      }
    } finally {
      this.isLoading = false;
    }

  }

  ngOnDestroy(): void {
    this.userSub.unsubscribe();
  }

}
