import {Component, EventEmitter, Input, Output} from '@angular/core';
import {IAppContainerResponse} from '../../../interfaces/AppContainer';
import {MinutesToTimePipe} from '../../../pipes/minutes-to-time.pipe';
import {MatIconModule} from '@angular/material/icon';
import {CommonModule} from '@angular/common';
import {RouterLink} from '@angular/router';
import {SpinnerComponent} from '../../../components/spinner/spinner.component';
import {MatTooltipModule} from '@angular/material/tooltip';
import {UserApp} from "../../../interfaces/v3/user-applications.interface";
import {User} from "../../../interfaces/v3/user.interface";
import {MatCheckboxModule} from "@angular/material/checkbox";

@Component({
  selector: 'app-containers-table',
  standalone: true,
  imports: [
    MinutesToTimePipe,
    MatIconModule,
    CommonModule,
    RouterLink,
    SpinnerComponent,
    MatTooltipModule,
    MatCheckboxModule,
  ],
  templateUrl: './containers-table.component.html',
  styleUrl: './containers-table.component.scss'
})
export class ContainersTableComponent {

  changingAppName: string = '';


  @Input() userContainers!: UserApp[];
  @Input() isStatusChangeLoading!: boolean;
  @Output() statusChangeClicked = new EventEmitter<UserApp>();
  @Output() deleteBtnClicked = new EventEmitter<UserApp>();

  constructor() {
  }

  onDeleteBtnClick = (app: UserApp) => {
    this.deleteBtnClicked.emit(app)
  }

  onStatusChangeClick = (app: UserApp) => {
    this.changingAppName = app.appName;
    this.statusChangeClicked.emit(app)
  }

  tableRowTrackBy(index: number, app: UserApp) {
    return app.id
  }

  showError(error: string): void {
    alert(error);
  }

  formatStatus(appStatus: string): string {
    let status = appStatus || 'UNKNOWN'

    if (status.includes("_")) {
      status = status.replace(/_/g, " ")
    }

    return status.toLowerCase();

  }


  getStatusIcon(status: string): string {
    switch (status) {
      case 'CREATED':
        return 'check_circle_outline';
      case 'FAILED':
        return 'error_outline';
      case 'UNHEALTHY':
        return 'warning_amber';
      case 'IN_PROGRESS':
        return 'hourglass_empty';
      default:
        return '';
    }
  }

  getStatusTooltip(status: string): string {
    switch (status) {
      case 'CREATED':
        return 'Container is created';
      case 'FAILED':
        return 'Container failed to create';
      case 'UNHEALTHY':
        return 'Container is unhealthy';
      case 'IN_PROGRESS':
        return 'Container creation in progress';
      default:
        return '';
    }
  }

  getStatusIconClass(status: string): string {
    switch (status) {
      case 'CREATED':
        return 'container-created';
      case 'FAILED':
        return 'container-failed';
      case 'UNHEALTHY':
        return 'container-warning';
      case 'IN_PROGRESS':
        return 'container-in-progress';
      default:
        return '';
    }
  }

  isAppIsWithInProgressStatus(app: UserApp): boolean {
    return app.statusInfo?.status === 'IN_PROGRESS';
  }

}
