import { Component, EventEmitter, Input, Output } from '@angular/core';
import { FormControl, ReactiveFormsModule, Validators } from '@angular/forms';
import { AuthService } from '../../../services/auth.service';
import { REGEX } from '../../../utils/regex';
import { ButtonComponent } from '../../../components/button/button.component';
import { NgFor, NgIf } from '@angular/common';
import { UserCredentials } from '../../../interfaces/UserCredentials';
import { errorHelper } from '../../../utils/errorHelper';

@Component({
  selector: 'app-verification-step',
  standalone: true,
  imports: [ButtonComponent, ReactiveFormsModule, NgFor, NgIf ],
  templateUrl: './verification-step.component.html',
  styleUrl: './verification-step.component.scss'
})
export class VerificationStepComponent {

  title = "Verification Code"
  subtitle = "We have sent the code verification to your phone number"
  didntReceiveText = "Didn't receive it?"
  btnText = "continue";
  inputError = "";
  verificationInput!: FormControl;
  isResendingCode = false;
  isLoading = false;
  @Input() credentials!:UserCredentials;
  @Output() onCompletion = new EventEmitter();

  constructor(private authService:AuthService){}

  ngOnInit(): void {
    this.verificationInput = new FormControl("", [
      Validators.pattern(REGEX.verificationCode),
      Validators.required
    ])
  }

  async handleSendCode(){
    if(this.verificationInput.invalid) return;

    try{
      this.isLoading = true;
      this.inputError = "";
      const activationCode = this.verificationInput.value;
      await this.authService.activateUser(activationCode);
      this.onCompletion.emit();
    }
    catch(err){
      this.inputError = errorHelper(err);
    }
    finally{ this.isLoading = false }

  }

  async handleResendCode(){
    try{
      this.isResendingCode = true;
      await this.authService.resendCode();
    }
    catch(err){
      this.inputError = errorHelper(err);
    }
    finally{ this.isResendingCode = false }
  }

}
