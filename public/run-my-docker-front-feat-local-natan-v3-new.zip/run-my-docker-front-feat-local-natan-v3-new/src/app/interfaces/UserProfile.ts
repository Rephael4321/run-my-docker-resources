interface IUserProfile{
  firstName: string,
  lastName: string,
  phone: string,
  username: string // email
}

export interface IUserProfileRequest extends IUserProfile{
  password: string
}

export interface IUserProfileResponse extends IUserProfile{
  id: number
  createdat:string
  activated: boolean
}

export interface IUserUpdateRequest{
  password: string,
  phone: string,
}

export interface IRegistrationResponse{
  user: IUserProfileResponse
  uuid:string
}

export interface IForgotPasswordResponse{
  code: string,
  uuidToken: string
}

export interface ISocialRegistration{
  id: string,
  firstName: string
  lastName: string
  phone: string
}
