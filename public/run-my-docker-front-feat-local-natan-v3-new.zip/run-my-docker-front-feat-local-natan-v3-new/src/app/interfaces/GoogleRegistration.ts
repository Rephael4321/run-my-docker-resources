interface IGoogleRegistration{
  firstName: string,
  lastName: string,
  phone: string,
  username: string
}

export interface IGoogleRegistrationRequest extends IGoogleRegistration{
  password: string
}

export interface IGoogleRegistrationResponse extends IGoogleRegistration{
  createdat: string, // date format
  id: number,
  userApplicationsCount: number,
}

export interface IGoogleLogin{
  email: string,
  tokenId: string
}
