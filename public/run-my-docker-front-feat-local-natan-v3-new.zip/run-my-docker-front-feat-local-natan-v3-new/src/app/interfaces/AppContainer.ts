interface IAppContainer{
  appName: string
  dockerImage: string
  username: string
}

export interface IAppContainerRequest extends IAppContainer{
  portMap: string
}

export interface IAppContainerResponse extends IAppContainer{
  port: number
  containerId: string
  mappingPort: string
  createdAt: string
  updatedAt: string
  remainingTime: number
  id: number
  running: boolean
}

export type AppStausChangeRequest = {
  appId: number,
  appName: string
}
