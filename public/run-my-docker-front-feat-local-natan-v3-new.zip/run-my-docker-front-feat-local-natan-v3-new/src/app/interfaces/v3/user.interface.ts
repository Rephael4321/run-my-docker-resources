import {BaseApiResponse} from "./base-api.interface";

export type User = {
  firstName: string,
  lastName: string,
  id: number,
  isActivated: boolean,
  phone: string,
  username: string,
}

export type GetUserApiResponse = BaseApiResponse<User>
