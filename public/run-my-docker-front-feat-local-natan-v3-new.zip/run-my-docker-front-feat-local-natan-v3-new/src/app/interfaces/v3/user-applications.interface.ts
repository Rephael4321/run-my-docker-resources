import {BaseApiResponse} from "./base-api.interface";

export type UserApp = {
  appName: string;
  createdAt: string;
  dockerImage: string;
  id: number;
  mappingPort: string;
  remainingTime: number;
  running: boolean;
  statusInfo: {
    error: string;
    status: string;
  };
  updatedAt: string;
  username: string;
};

export type GetUserAppsApiResponse = BaseApiResponse<UserApp[]>;

