import {BaseApiResponse} from "./base-api.interface";
import {User} from "./user.interface";

export interface LoginResponse {
  jwtToken: string;
}

export type LoginApiResponse = BaseApiResponse<LoginResponse>

export interface RegisterRequest {
  firstName: string,
  lastName: string,
  phone: string,
  username: string,
  password: string
}

export interface RegistrationResponse {
  user: User,
  uuid: string
}

export type RegistrationApiResponse = BaseApiResponse<RegistrationResponse>

export type ActivationResponse = {
  jwtToken: string
  message: string
  username: string
}

export type ActivationApiResponse = BaseApiResponse<ActivationResponse>



