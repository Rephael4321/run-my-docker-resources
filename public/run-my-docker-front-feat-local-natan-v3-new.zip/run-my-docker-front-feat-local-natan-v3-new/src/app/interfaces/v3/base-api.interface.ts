export interface BaseApiResponse<T> {
  code: number;
  data: T;
  extraInfo: Record<string, unknown>;
  message: string;
  success: boolean;
}

export interface ApiErrorResponse {
  code: number;
  data: Record<string, unknown>;
  extraInfo: Record<string, unknown>;
  message: string;
  success: boolean;
}



