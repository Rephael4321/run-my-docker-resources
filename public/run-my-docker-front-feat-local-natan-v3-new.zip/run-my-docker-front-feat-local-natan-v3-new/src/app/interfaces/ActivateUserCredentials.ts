export type ActivateUserCredetials = {
  code: string
}

