import { NgClass, NgIf } from '@angular/common';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { SpinnerComponent } from '../spinner/spinner.component';

@Component({
  selector: 'app-button',
  standalone: true,
  imports: [ NgClass, SpinnerComponent, NgIf ],
  templateUrl: './button.component.html',
  styleUrl: './button.component.scss'
})
export class ButtonComponent implements OnInit{

  @Input() text: string = "";
  @Input() color?: "blue" | "white" = "blue";
  @Input() size?: "sm" | "lg" = "lg";
  @Input() isDisabled?: boolean;
  @Input() isLoading?: boolean;
  @Input() btnType?: "button" | "submit" = "button";
  @Output() onClick = new EventEmitter();
  className = "";

  constructor(){}

  ngOnInit(){
    this.setInitClassName();
  }

  setInitClassName(){
    const padding = this.size === 'lg'? 'py-3 px-5': 'px-2'
    const color = this.color === 'blue'? 'blue-linear-btn': 'white-btn';
    this.className = `custom-btn px-2 ${color} btn-${this.size} ${padding}`;
  }

  handleClick(){
    this.onClick.emit();
  }
}
