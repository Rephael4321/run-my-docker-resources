import { Component, Input } from '@angular/core';
import { RouterLink } from '@angular/router';
import {environment} from "../../../environments/environment.development";

@Component({
  selector: 'app-google-btn',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './google-btn.component.html',
  styleUrl: './google-btn.component.scss'
})
export class GoogleBtnComponent {
  @Input() baseUrl: string = environment.serverURL;
  googleLoginLink = `${this.baseUrl}/oauth2/authorize/google?redirect_uri=${this.baseUrl}/google`;
  // googleLoginLink = 'https://backend.runmydocker.com/oauth2/authorize/google?redirect_uri=https://backend.runmydocker.com/google';
  githubLoginLink = "https://backend.runmydocker.com/oauth2/authorize/github?redirect_uri=https://backend.runmydocker.com/github";
}
