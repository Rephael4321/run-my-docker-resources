import { Component, OnDestroy, OnInit } from '@angular/core';
import {MatMenuModule} from '@angular/material/menu';
import {MatButtonModule} from '@angular/material/button';
import {MatIconModule} from '@angular/material/icon'
import { ActivatedRoute, NavigationEnd, Router, RouterLink } from '@angular/router';
import { NgIf } from '@angular/common';
import { AuthService } from '../../services/auth.service';
import { Subscription } from 'rxjs';
import { IUserProfileResponse } from '../../interfaces/UserProfile';
import {User} from "../../interfaces/v3/user.interface";

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [RouterLink, NgIf, MatIconModule, MatButtonModule, MatMenuModule],
  templateUrl: './navbar.component.html',
  styleUrl: './navbar.component.scss'
})
export class NavbarComponent implements OnInit, OnDestroy{

  userSub!:Subscription;
  user: User | null = null;
  currentRoute: string = '/';

  constructor(private authService:AuthService,
    private router: Router,
    private route: ActivatedRoute){}

  ngOnInit(): void {
    this.userSub = this.authService.$user.subscribe(user => this.user = user)

    this.router.events.subscribe(event => {
        if(event instanceof NavigationEnd){
          this.currentRoute = event.url;
        }
     });
  }

  handleLogout(){
    this.authService.logout();
    this.router.navigate(['login'])
  }

  ngOnDestroy(): void {
    this.userSub.unsubscribe()
  }

}
