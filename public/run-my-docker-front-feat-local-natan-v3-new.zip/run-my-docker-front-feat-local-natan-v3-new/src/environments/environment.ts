export const environment = {
  production: true,
  serverURL: "https://backend.runmydocker.com",
  encryptionSecretKey: "life-is-a-#$%^@"
};
