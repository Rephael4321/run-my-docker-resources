export const environment = {
  production: false,
  serverURL: "http://localhost:8081",
  encryptionSecretKey: "life-is-a-#$%^@"
};
